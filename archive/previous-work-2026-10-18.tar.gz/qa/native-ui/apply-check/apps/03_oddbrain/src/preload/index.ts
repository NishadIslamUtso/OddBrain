import { contextBridge, ipcRenderer } from 'electron'
import type {
  CloudModelsAnswer,
  CloudTestAnswer,
  CloudView,
} from '../shared/lib/providers'
import type { Permissions } from '../shared/lib/permissions'
import type { ApprovalMode, EngineAvailability, EngineEvent, EngineId, EngineModelEntry, EngineSettings } from '../shared/lib/engine'
import type { HouseRules } from '../shared/lib/houseRules'
import type { Project } from '../shared/lib/projects'
import type {
  AdoptInput,
  ItemAnswer,
  ListAnswer,
  ReadAnswer,
  RemoveAnswer,
  SaveInput,
} from '../main/artifacts/store'

/**
 * The only bridge between the window and the machine.
 *
 * Every API added here gets an explicit, narrow shape: no raw `ipcRenderer`, so
 * the renderer can only call the functions named below and never an arbitrary
 * channel. Each one returns a value or a plain sentence — nothing here throws at
 * the interface, because a failed folder choice is not an exception, it is an
 * answer.
 */
/** The engine, exactly as the window may touch it: ask, task, answer, watch. */
const engineApi = {
  /** The chosen engine, whether it is working, and what it last said. */
  read: (): Promise<{ engine: EngineSettings; running: boolean; history: EngineEvent[] }> =>
    ipcRenderer.invoke('engine:read'),
  /** Choose which engine thinks inside the app. */
  pick: (id: EngineId): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('engine:pick', id),
  /** The brains this engine can use, as its own door reports them. */
  models: (): Promise<{ ok: boolean; models: EngineModelEntry[]; error?: string }> =>
    ipcRenderer.invoke('engine:models'),
  /** What engines are really installed on this machine. */
  detect: (): Promise<EngineAvailability[]> => ipcRenderer.invoke('engine:detect'),
  /** Bring a brain home; progress arrives through onPullEvent. */
  pull: (name: string): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('engine:pull', name),
  /** Take a brain off this machine. */
  deleteModel: (name: string): Promise<{ ok: boolean; answer: string }> =>
    ipcRenderer.invoke('engine:model-delete', name),
  /** The rulebook, as it stands (blanks already filled from the defaults). */
  readHouseRules: (): Promise<{ rules: HouseRules; defaults: HouseRules }> =>
    ipcRenderer.invoke('houserules:read'),
  /** Save the rulebook and deploy it to every engine's global file. */
  writeHouseRules: (rules: HouseRules): Promise<{ ok: boolean; written: string[] }> =>
    ipcRenderer.invoke('houserules:write', rules),
  /** Pull progress ticks, in the same shape `parsePullLine` produces. */
  onPullEvent: (listener: (tick: unknown) => void): (() => void) => {
    const channel = 'engine:pull-event'
    const wrapped = (_event: unknown, tick: unknown): void => listener(tick)
    ipcRenderer.on(channel, wrapped)
    return () => ipcRenderer.removeListener(channel, wrapped)
  },
  /** Pick which brain the engine thinks with (provider brains say which door). */
  setModel: (model: string, provider?: 'anthropic'): Promise<{ ok: boolean; answer: string }> =>
    ipcRenderer.invoke('engine:model', model, provider),
  /** Set the throttle: how much the engine may do before asking. */
  setApproval: (mode: ApprovalMode): Promise<{ ok: boolean; answer: string }> =>
    ipcRenderer.invoke('engine:approval', mode),
  setThinking: (mode: 'default' | 'extended'): Promise<{ ok: boolean; answer: string }> =>
    ipcRenderer.invoke('engine:thinking', mode),
  memory: {
    list: (): Promise<{ ok: boolean; folder?: string; files?: Array<{ name: string; path: string; updated: string; content: string; clipped: boolean }> }> =>
      ipcRenderer.invoke('memory:list'),
    remove: (name: string): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('memory:remove', name),
  },
  journal: {
    list: (): Promise<{ ok: boolean; entries: Array<{ at: string; prompt: string; answer: string; sessionId: string | null; usage: string; workspace: string }> }> =>
      ipcRenderer.invoke('journal:list'),
    append: (entry: { at: string; prompt: string; answer: string; sessionId: string | null; usage: string; workspace: string }): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('journal:append', entry),
    clear: (): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('journal:clear'),
  },
  /** "Open a folder": choose where the engine works. */
  pickWorkspace: (): Promise<{ ok: boolean; answer: string }> =>
    ipcRenderer.invoke('engine:pick-workspace'),
  /** Hand the engine a task. Events arrive through `onEvent` from then on. */
  send: (prompt: string, cwd: string, pictures?: Array<{ mime: string; data: string }>): Promise<{ ok: boolean; answer: string }> =>
    ipcRenderer.invoke('engine:send', prompt, cwd, pictures),
  /** What the app kept before allowed writes, and the way back. */
  checkpoints: {
    list: (): Promise<{ ok: boolean; checkpoints: Array<{ copy: string; original: string; at: string }> }> =>
      ipcRenderer.invoke('engine:checkpoints:list'),
    restore: (copy: string, original?: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('engine:checkpoint:restore', copy, original),
  },
  watch: {
    start: (folder: string): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('watch:start', folder),
    stop: (): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('watch:stop'),
    status: (): Promise<{ folder: string; active: boolean }> => ipcRenderer.invoke('watch:status'),
    onEvent: (listener: (tick: { folder: string; names: string[]; at: number }) => void): (() => void) => {
      const hear = (_event: unknown, tick: { folder: string; names: string[]; at: number }): void => listener(tick)
      ipcRenderer.on('watch:event', hear)
      return () => ipcRenderer.removeListener('watch:event', hear)
    },
  },
  hooks: {
    list: (): Promise<{ ok: boolean; hooks: Array<{ id: string; name: string; event: string; command: string }> }> =>
      ipcRenderer.invoke('hooks:list'),
    save: (hook: unknown): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('hooks:save', hook),
    remove: (id: string): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('hooks:remove', id),
    test: (command: string): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('hooks:test', command),
  },
  battle: {
    record: (entry: { prompt: string; winner: string; loser: string; tie: boolean; blind: boolean }): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('battle:record', entry),
    ledger: (): Promise<{ ok: boolean; entries: Array<{ prompt: string; winner: string; loser: string; tie: boolean; at: string }> }> =>
      ipcRenderer.invoke('battle:ledger'),
  },
  repoMap: (): Promise<{ ok: boolean; answer?: string; map?: string; files?: number; dirs?: number; truncated?: boolean; root?: string }> =>
    ipcRenderer.invoke('repo:map'),
  compact: {
    save: (input: { brief: string; workspace: string; at: string }): Promise<{ ok: boolean; answer: string; file?: string }> =>
      ipcRenderer.invoke('compact:save', input),
  },
  fresh: (): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('engine:fresh'),
  recipes: {
    list: (): Promise<{ ok: boolean; recipes: Array<{ name: string; description?: string; parameters: Array<{ name: string; description?: string; default?: string }>; body: string }>; broken: Array<{ file: string; answer: string }> }> =>
      ipcRenderer.invoke('recipes:list'),
    save: (recipe: unknown): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('recipes:save', recipe),
    remove: (name: string): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('recipes:remove', name),
  },
  downloads: {
    start: (engine: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('engine:download:start', engine),
    status: (): Promise<Record<string, { engine: string; endpoint: string; sha256: string; at: string } | undefined>> =>
      ipcRenderer.invoke('engine:download:status'),
    run: (engine: string): Promise<{ ok: boolean; answer: string; command?: string[] }> =>
      ipcRenderer.invoke('engine:download:run', engine),
    execute: (engine: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('engine:download:execute', engine),
    remove: (engine: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('engine:download:remove', engine),
    serveStart: (): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('engine:download:serve-start'),
    serveStop: (): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('engine:download:serve-stop'),
    serveStatus: (): Promise<{ ok: boolean; answer: string; running: boolean }> => ipcRenderer.invoke('engine:download:serve-status'),
    onEvent: (listener: (tick: { engine: string; got: number; total: number | null; phase: string; answer?: string }) => void): (() => void) => {
      const channel = (_outer: unknown, tick: { engine: string; got: number; total: number | null; phase: string; answer?: string }): void => listener(tick)
      ipcRenderer.on('engine:download-event', channel)
      return () => ipcRenderer.removeListener('engine:download-event', channel)
    },
  },
  extensionPair: {
    get: (): Promise<{ token: string }> => ipcRenderer.invoke('extension-pair:get'),
    rotate: (): Promise<{ ok: boolean; token: string }> => ipcRenderer.invoke('extension-pair:rotate'),
  },
  /** Answer one of the engine's permission cards. */
  answer: (requestId: string, allow: boolean): Promise<{ ok: boolean }> =>
    ipcRenderer.invoke('engine:answer', requestId, allow),
  /** Make the engine stop. */
  stop: (): Promise<{ ok: boolean }> => ipcRenderer.invoke('engine:stop'),
  /** Watch the engine live. Returns the unsubscribe function. */
  onEvent: (listener: (event: EngineEvent) => void): (() => void) => {
    const channel = (_outer: unknown, event: EngineEvent): void => listener(event)
    ipcRenderer.on('engine:event', channel)
    return () => ipcRenderer.removeListener('engine:event', channel)
  },
}

const api = {
  app: {
    previewHtml: (): Promise<{ ok: boolean; html?: string; error?: string }> => ipcRenderer.invoke('app:preview-html'),
    claimLaunch: (): Promise<boolean> => ipcRenderer.invoke('app:claim-launch'),
    /** Which build is running. Used by the About panel and bug reports. */
    version: process.env['npm_package_version'] ?? '0.1.0',
    platform: process.platform,
    /** Open the vault folder in the file manager — the owner's own folder. */
    openVaultFolder: (): Promise<{ ok: boolean }> => ipcRenderer.invoke('vault:open-folder'),
    flags: {
      get: (): Promise<{ loginItem: boolean; warmRuntime: boolean }> => ipcRenderer.invoke('app:flags:get'),
      set: (patch: { loginItem?: boolean; warmRuntime?: boolean }): Promise<{ loginItem: boolean; warmRuntime: boolean }> =>
        ipcRenderer.invoke('app:flags:set', patch),
    },
    /** Open a https://github.com link in the person's browser. */
    openExternal: (url: string): Promise<{ ok: boolean }> => ipcRenderer.invoke('app:open-external', url),
    /** The native menu talks to the window through these channels. */
    onMenu: (channel: string, callback: () => void): (() => void) => {
      const listener = (): void => callback()
      ipcRenderer.on(String(channel), listener)
      return () => ipcRenderer.removeListener(String(channel), listener)
    },
  },
  projects: {
    read: (): Promise<Project[]> => ipcRenderer.invoke('projects:read'),
    write: (projects: Project[]): Promise<{ ok: boolean; projects: Project[] }> =>
      ipcRenderer.invoke('projects:write', projects),
    blank: (name: string): Promise<Project> => ipcRenderer.invoke('projects:new', name),
  },
  engine: {
    setWorkspace: (folder: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('engine:workspace-set', folder),
    sessions: (): Promise<Array<{ workspace: string; sessionId: string }>> => ipcRenderer.invoke('engine:sessions'),
    boardRead: (): Promise<unknown> => ipcRenderer.invoke('sessions:board-read'),
    boardWrite: (board: unknown): Promise<{ ok: boolean }> => ipcRenderer.invoke('sessions:board-write', board),
    pickFiles: (): Promise<string[]> => ipcRenderer.invoke('sessions:pick-files'),
    forgetSession: (workspace: string): Promise<{ ok: boolean }> => ipcRenderer.invoke('engine:sessions-forget', workspace),
    openFolder: (folder: string): Promise<{ ok: boolean }> => ipcRenderer.invoke('app:open-folder', folder),
    checkpoints: {
      list: (): Promise<{ ok: boolean; checkpoints: Array<{ copy: string; original: string; at: string }> }> =>
        ipcRenderer.invoke('engine:checkpoints:list'),
      restore: (copy: string, original?: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('engine:checkpoint:restore', copy, original),
    },
  },
  houseRules: {
    read: (): Promise<{ rules: HouseRules; defaults: HouseRules }> => ipcRenderer.invoke('houserules:read'),
    write: (rules: HouseRules): Promise<{ ok: boolean; written: string[] }> =>
      ipcRenderer.invoke('houserules:write', rules),
  },
  settings: {
    /** What the app has been told to do, as the main process holds it. */
    read: (): Promise<{
      vaultPath: string
      cloud: { baseUrl: string; model: string }
      permissions: Permissions
    }> => ipcRenderer.invoke('settings:read'),
    /**
     * Save a change. The main process decides whether it is possible and says
     * what happened; the renderer is told the result rather than assuming one.
     */
    update: (
      patch: { vaultPath?: string; cloud?: { baseUrl?: string; model?: string }; permissions?: Permissions }
    ): Promise<{
      ok: boolean
      error?: string
      settings?: { vaultPath: string; cloud: { baseUrl: string; model: string }; permissions: Permissions }
      status?: { ok: boolean; available: boolean; vault: string; error?: string; counts?: { files: number; entities: number } }
    }> => ipcRenderer.invoke('settings:update', patch),
  },
  /**
   * Online providers. The key is handed over once and never comes back: what the
   * interface can ask is which providers are enabled, which models they offer,
   * and whether one of them answers — never the key itself.
   */
  cloud: {
    /** The providers and whether a key is saved for each. Never the key. */
    providers: (): Promise<CloudView> => ipcRenderer.invoke('cloud:providers'),
    /** Every model the saved keys can reach, with each provider's own problem. */
    models: (): Promise<CloudModelsAnswer> => ipcRenderer.invoke('cloud:models'),
    /** Save a key. It is sealed by the machine's keychain, or held for this run. */
    saveKey: (id: string, key: string): Promise<CloudView> =>
      ipcRenderer.invoke('cloud:save-key', id, key),
    /** Take a key away. Nothing else about that provider is touched. */
    clearKey: (id: string): Promise<CloudView> => ipcRenderer.invoke('cloud:clear-key', id),
    /** Ask one provider for its model list, which is what the Test button does. */
    test: (id: string): Promise<CloudTestAnswer> => ipcRenderer.invoke('cloud:test', id),
  },
  skills: {
    /** Install one skill from the app's own catalog, into every engine. */
    installCatalog: (name: string): Promise<{ ok: boolean; answer: string; written?: string[] }> =>
      ipcRenderer.invoke('skills:install-catalog', name),
    /** The skills the engine folder really holds — the export list. */
    scan: (): Promise<Array<{ name: string; description: string; body: string; source: string }>> =>
      ipcRenderer.invoke('skills:scan'),
  },
  mods: {
    installFromFile: (): Promise<{ ok: boolean; answer: string; pack?: unknown; prompts?: Array<{ name: string; body: string }>; themes?: Array<{ name: string; appearance: Record<string, string> }>; folder?: string }> =>
      ipcRenderer.invoke('mods:install-from-file'),
    list: (): Promise<Array<{ pack: unknown; folder: string; installedAt: string }>> => ipcRenderer.invoke('mods:list'),
    remove: (id: string): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('mods:remove', id),
    indexAdd: (kind: string, locator: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('mods:index-add', { kind, locator }),
    indexList: (): Promise<Array<{ kind: 'folder' | 'url'; locator: string; addedAt: string }>> =>
      ipcRenderer.invoke('mods:index-list'),
    indexRemove: (locator: string): Promise<{ ok: boolean }> => ipcRenderer.invoke('mods:index-remove', locator),
    indexBrowse: (kind: string, locator: string): Promise<unknown> =>
      ipcRenderer.invoke('mods:index-browse', { kind, locator }),
    indexInstall: (kind: string, locator: string, id: string): Promise<{ ok: boolean; answer: string; written?: string[]; folder?: string }> =>
      ipcRenderer.invoke('mods:index-install', { kind, locator, id }),
    exportPack: (payload: { name: string; description: string; author: string; skills: string[]; theme: Record<string, string> | null }): Promise<{ ok: boolean; answer: string; folder?: string; index?: string }> =>
      ipcRenderer.invoke('mods:export', payload),
    installStarter: (): Promise<{ ok: boolean; answer: string; folder?: string; written?: string[] }> =>
      ipcRenderer.invoke('mods:install-starter'),
    communityIndex: (): Promise<{ ok: boolean; path?: string }> =>
      ipcRenderer.invoke('mods:community-index'),
  },
  mcp: {
    /** The one MCP server list, and which engine configs it was deployed to. */
    read: (): Promise<{ servers: Array<{ name: string; command?: string; args?: string[]; url?: string }> }> =>
      ipcRenderer.invoke('mcp:read'),
    write: (
      servers: Array<{ name: string; command?: string; args?: string[]; url?: string }>,
    ): Promise<{ ok: boolean; written: string[] }> => ipcRenderer.invoke('mcp:write', { servers }),
  },
  structure: {
    /** What a folder is, and exactly what a structure apply would add. */
    inspect: (
      root: string
    ): Promise<{ ok: boolean; kind?: string; present?: string[]; missing?: string[]; differing?: string[]; error?: string }> =>
      ipcRenderer.invoke('structure:inspect', root),
    /** Add every missing structure file; existing files are never rewritten. */
    apply: (
      root: string,
      options?: { refresh?: boolean }
    ): Promise<{ ok: boolean; kind?: string; written?: string[]; refreshed?: string[]; skipped?: string[]; differing?: string[]; error?: string }> =>
      ipcRenderer.invoke('structure:apply', root, options),
    /** Settle a conflict: keep mine, use the new one, keep both, or combine. */
    resolve: (root: string, original: string, added: string, action: 'mine' | 'new' | 'both' | 'combine'): Promise<{ ok: boolean; error?: string }> =>
      ipcRenderer.invoke('structure:resolve', root, original, added, action),
    /** Every [[link]] in the vault, resolved and counted: dead and ambiguous reported. */
    linkCheck: (): Promise<{ files: number; checked: number; dead: Array<{ from: string; target: string }>; ambiguous: Array<{ from: string; target: string; matches: string[] }>; edges: Array<{ from: string; to: string }>; error?: string }> =>
      ipcRenderer.invoke('vault:link-check'),
  },
  vault: {
    /** The operating system's folder picker. null when the person closed it. */
    chooseFolder: (): Promise<string | null> => ipcRenderer.invoke('vault:choose-folder'),
    /** His default: Documents\OddBrain\Brain, created on this press. */
    useDefault: (): Promise<{ ok: boolean; path?: string; written?: string[]; conflicts?: Array<{ original: string; added: string }>; error?: string }> =>
      ipcRenderer.invoke('vault:use-default'),
    /** A finished turn, written into the vault as a handoff document. */
    saveHandoff: (name: string, markdown: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('vault:save-handoff', { name, markdown }),
    /** A timestamped portable copy of the vault, written to the exports folder. */
    exportCopy: (): Promise<{ ok: boolean; answer: string }> => ipcRenderer.invoke('vault:export-copy'),
    /** The open conversation, captured into the vault as a capsule. */
    captureChat: (title: string, markdown: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('vault:capture-chat', { title, markdown }),
  },
  extension: {
    /**
     * Whether the browser extension can reach this app, and at what address. A
     * port that is open is a fact the interface shows rather than something to
     * discover from an extension that quietly stopped working.
     */
    status: (): Promise<{ ok: boolean; listening: boolean; port: number; url: string; error: string }> =>
      ipcRenderer.invoke('extension:status'),
  },
  /**
   * The artifact library, on disk in this user's own app-data folder.
   *
   * Every call answers rather than throws: a library that cannot be read says
   * so in a sentence the screen can show, because an exception here would be a
   * blank grid with no explanation.
   */
  /** The quick-ask door: open the small window, or move its global hotkey. */
  quick: {
    open: (): Promise<{ ok: boolean }> => ipcRenderer.invoke('quick:open'),
    shortcut: (enabled: boolean): Promise<{ ok: boolean; enabled: boolean }> => ipcRenderer.invoke('quick:shortcut', { enabled }),
  },

  /** An artifact outside the chat: its own window, or a PDF in the vault. */
  artifactWindow: {
    popout: (html: string, title: string): Promise<{ ok: boolean }> =>
      ipcRenderer.invoke('artifact:popout', { html, title }),
    savePdf: (html: string, name: string): Promise<{ ok: boolean; answer: string }> =>
      ipcRenderer.invoke('artifact:pdf', { html, name }),
  },

  artifacts: {
    list: (): Promise<ListAnswer> => ipcRenderer.invoke('artifacts:list'),
    /** One document. `version` is 1-based, the number the chips show. */
    read: (id: string, version?: number): Promise<ReadAnswer> => ipcRenderer.invoke('artifacts:read', id, version),
    /** Create, or append a version to an existing artifact. */
    save: (input: SaveInput): Promise<ItemAnswer> => ipcRenderer.invoke('artifacts:save', input),
    rename: (id: string, title: string): Promise<ItemAnswer> => ipcRenderer.invoke('artifacts:rename', id, title),
    duplicate: (id: string): Promise<ItemAnswer> => ipcRenderer.invoke('artifacts:duplicate', id),
    /** Put an older version back — by appending it, never by truncating. */
    restore: (id: string, version: number): Promise<ItemAnswer> => ipcRenderer.invoke('artifacts:restore', id, version),
    /** Take it out of the library; the folder moves to the library's trash. */
    remove: (id: string): Promise<RemoveAnswer> => ipcRenderer.invoke('artifacts:remove', id),
    /** Write artifacts found in saved conversations in, once each. */
    adopt: (records: AdoptInput[]): Promise<{ ok: true; adopted: number; skipped: number; refused: number }> =>
      ipcRenderer.invoke('artifacts:adopt', records),
    /** The operating system's file picker, for a page or a drawing to bring in. */
    import: (): Promise<{ ok: boolean; item?: unknown; error?: string; canceled?: boolean }> =>
      ipcRenderer.invoke('artifacts:import'),
  },
}

contextBridge.exposeInMainWorld('api', api)
contextBridge.exposeInMainWorld('engineApi', engineApi)

export type Api = typeof api
