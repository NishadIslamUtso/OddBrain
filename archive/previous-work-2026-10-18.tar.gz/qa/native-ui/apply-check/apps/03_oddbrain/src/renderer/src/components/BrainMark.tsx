import { useId, type SVGProps } from 'react'

/**
 * BrainMark — the OddBrain logo.
 *
 * THE mark, replaced 2026-10-15 with the owner's own export: the distinguished
 * butt-brain (his words: "use this only"). The previous smiling-brain artwork
 * was purged everywhere — this component, the favicon and the desktop icon all
 * render from the same drawing now (`resources/icon.svg` is the canonical
 * file; `scripts/render-icons.mjs` turns it into the install icons).
 *
 * Rendered inline so it needs no network request, which matters for an app
 * that has to open offline.
 *
 * Every id is namespaced per instance. The artwork is built from <use> and
 * clipPath references, so two copies of the logo on one page would otherwise
 * steal each other's shapes — the sidebar mark would silently clip the one in
 * the settings header.
 */
/** Only used if a React version ever returns an id that sanitises to nothing. */
let markCount = 0

type BrainMarkProps = {
  size?: number
  title?: string
} & SVGProps<SVGSVGElement>

export default function BrainMark({ size = 20, className = '', title = 'OddBrain', ...rest }: BrainMarkProps) {
  // React's useId has changed shape between versions — React 19 returns ids
  // wrapped in punctuation, older ones return `:r0:`. Punctuation is legal in an
  // id attribute but NOT safe inside `url(#…)` references, which is how this
  // artwork points at its own body, clip paths and lens tint. If those
  // references miss, the mark renders in pieces — a pink blob with no glasses.
  // So the id is stripped to letters and digits, which are safe in every
  // reference context. The fallback covers a useId that sanitises to nothing.
  const raw = useId().replace(/[^a-zA-Z0-9]/g, '')
  const uid = raw || `bm${markCount++}`
  const id = (name: string) => `${uid}-${name}`
  const body = id('body-shape')
  const bodyClip = id('body-clip')
  const leftLens = id('left-lens')
  const rightLens = id('right-lens')
  const leftLensClip = id('left-lens-clip')
  const rightLensClip = id('right-lens-clip')
  const lensTint = id('lens-tint')

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 740 740"
      fill="none"
      role="img"
      aria-label={title}
      className={className}
      {...rest}
    >
      <title>{title}</title>
      <desc>
        A pink cartoon brain with a pronounced two-cheek butt silhouette, winding brain wrinkles,
        tailored black sunglasses and a small smug smirk, arms at its sides, purple shoes.
      </desc>
      <defs>
        <path
          id={body}
          d="M356 148 C322 120 281 112 242 120 C169 131 107 178 80 246 C40 344 59 438 119 482 C178 526 280 530 330 483 C341 473 351 459 356 447 C362 463 372 479 386 489 C440 531 529 518 580 471 C637 419 649 333 618 252 C593 185 540 137 476 122 C432 112 391 121 356 148Z"
        />
        <clipPath id={bodyClip}>
          <use href={`#${body}`} />
        </clipPath>
        <path
          id={leftLens}
          d="M236 234 C263 230 316 230 342 235 L333 282 C331 296 319 304 303 305 L282 305 C265 304 253 296 248 282Z"
        />
        <path
          id={rightLens}
          d="M412 234 C439 230 489 230 521 234 L511 282 C506 296 494 304 478 305 L456 305 C440 304 427 296 423 282Z"
        />
        <clipPath id={leftLensClip}>
          <use href={`#${leftLens}`} />
        </clipPath>
        <clipPath id={rightLensClip}>
          <use href={`#${rightLens}`} />
        </clipPath>
        <linearGradient id={lensTint} x1="0" y1="230" x2="0" y2="307" gradientUnits="userSpaceOnUse">
          <stop stopColor="#343E48" />
          <stop offset="1" stopColor="#20272E" />
        </linearGradient>
      </defs>

      {/* Quiet, upright stance: no suit, tie, or other outfit. */}
      <g stroke="#393A35" strokeWidth="23" strokeLinecap="round">
        <path d="M259 481 C267 514 260 548 250 574" />
        <path d="M418 480 C432 513 424 550 414 574" />
      </g>
      <g>
        <path d="M580 358 C617 384 637 418 636 455" stroke="#393A35" strokeWidth="20" strokeLinecap="round" />
        <path
          d="M637 444 C649 445 657 454 661 467 C667 482 660 498 647 503 C634 508 621 501 620 487 L618 479 C611 481 607 476 611 469 C617 455 626 445 637 444Z"
          fill="#393A35"
          stroke="#2B2D29"
          strokeWidth="1.5"
          strokeLinejoin="round"
        />
      </g>

      <g>
        <use href={`#${body}`} fill="#FF98A5" />
        <g clipPath={`url(#${bodyClip})`}>
          <use href={`#${body}`} transform="translate(0 -12)" fill="#FFAFB8" />

          {/* The long central cleft preserves the unmistakable butt shape. */}
          <g strokeLinecap="round">
            <path d="M356 148 C338 172 333 198 342 234" stroke="#EF7F8C" strokeWidth="10" />
            <path d="M367 366 C382 391 375 420 356 447" stroke="#EA7787" strokeWidth="11" />
            <path d="M357 368 C369 392 364 417 350 438" stroke="#FF9DAA" strokeWidth="5" />
          </g>

          {/* Winding, branching sulci across both cheeks, rather than a smooth peach. */}
          <g stroke="#EE818D" strokeWidth="8.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M231 158 C248 148 269 150 279 164 C287 175 284 190 274 195 C262 201 258 210 262 222" />
            <path d="M305 168 C315 178 313 194 303 201" />
            <path d="M202 184 C176 184 158 203 160 226 C144 219 130 224 120 236 C109 249 111 266 115 279" />
            <path d="M218 199 C199 195 186 208 187 223 C189 239 180 251 165 251" />
            <path d="M159 272 C145 264 130 272 128 286 C126 299 130 309 119 317 C106 327 102 340 110 354" />
            <path d="M182 296 C171 289 159 294 153 304 C147 315 153 327 165 332 C180 339 184 352 174 365" />
            <path d="M109 385 C98 396 103 413 116 419" />
            <path d="M201 356 C217 352 231 363 232 377 C232 391 245 400 259 396 C275 391 289 399 291 413" />
            <path d="M172 391 C155 386 143 397 146 412 C150 429 167 432 181 427 C192 423 204 429 204 442" />
            <path d="M230 429 C219 440 223 458 239 463 C256 470 273 461 275 447 C277 433 294 429 306 438" />
            <path d="M315 371 C299 376 297 392 309 403 C322 414 325 428 317 441" />
            <path d="M175 466 C184 481 198 486 215 483" />
            <path d="M289 477 C306 471 319 460 327 448" />
            <path d="M397 176 C396 160 412 151 426 156 C439 160 442 175 452 181 C462 186 473 182 477 171" />
            <path d="M494 159 C508 165 515 178 511 191 C508 202 514 214 526 217" />
            <path d="M550 198 C545 212 551 225 564 231 C579 238 583 251 578 265" />
            <path d="M586 278 C601 285 605 301 597 316 C591 327 579 329 574 342 C569 356 575 366 585 373" />
            <path d="M546 318 C528 317 518 331 525 345 C532 359 525 372 511 374" />
            <path d="M570 399 C555 392 538 400 536 415 C535 430 520 437 507 430" />
            <path d="M451 360 C435 355 422 366 424 380 C426 395 442 399 455 393 C469 387 483 394 484 408" />
            <path d="M413 414 C424 422 423 436 435 443 C448 450 463 446 469 436 C477 423 490 423 501 430" />
            <path d="M420 475 C438 481 455 474 458 460" />
            <path d="M485 477 C501 477 516 469 523 458" />
          </g>
        </g>
      </g>

      {/* Dark, angular sunglasses: opaque lenses, discreet hardware, no visible eyes. */}
      <g transform="rotate(-6 379 267)">
        <g stroke="#222625" strokeLinecap="round">
          <path d="M225 234 L184 235" strokeWidth="15" />
          <path d="M533 235 L557 243" strokeWidth="13" />
          <path d="M355 239 C369 231 385 231 400 239" strokeWidth="13" />
        </g>
        <g fill="#222625">
          <path d="M224 222 C260 215 321 215 351 222 C359 224 362 230 360 240 L350 285 C347 307 329 319 305 320 L280 320 C255 319 238 307 233 287 L218 241 C215 232 216 225 224 222Z" />
          <path d="M404 222 C434 215 493 215 529 222 C537 224 543 230 540 241 L525 287 C520 307 503 319 479 320 L454 320 C428 319 411 307 405 285 L395 240 C393 230 396 224 404 222Z" />
        </g>
        <g fill={`url(#${lensTint})`}>
          <use href={`#${leftLens}`} />
          <use href={`#${rightLens}`} />
        </g>
        <g fill="#B2C3D1">
          <g clipPath={`url(#${leftLensClip})`}>
            <path d="M278 224 L300 224 L248 314 L226 314Z" opacity="0.23" />
            <path d="M311 224 L318 224 L266 314 L259 314Z" opacity="0.12" />
          </g>
          <g clipPath={`url(#${rightLensClip})`}>
            <path d="M454 224 L476 224 L424 314 L402 314Z" opacity="0.23" />
            <path d="M487 224 L494 224 L442 314 L435 314Z" opacity="0.12" />
          </g>
        </g>
        <g stroke="#515750" strokeWidth="2.5" strokeLinecap="round" opacity="0.7">
          <path d="M242 224 C270 221 314 222 335 225" />
          <path d="M414 225 C442 221 485 221 513 224" />
        </g>
        <g fill="#A8B0AE">
          <rect x="225" y="230" width="7" height="3.5" rx="1.75" />
          <rect x="525" y="230" width="7" height="3.5" rx="1.75" />
        </g>
      </g>

      {/* A restrained asymmetric smile, not a big cartoon grin. */}
      <g stroke="#3C3836" strokeLinecap="round">
        <path d="M349 342 C366 350 389 347 408 334" strokeWidth="6.5" />
        <path d="M406 331 C411 333 414 337 414 341" strokeWidth="4.5" />
      </g>

      <g>
        <path d="M151 358 C139 385 127 419 120 461" stroke="#393A35" strokeWidth="21" strokeLinecap="round" />
        <path
          d="M120 450 C109 451 99 458 94 471 C87 487 94 502 107 508 C120 515 135 507 139 494 L142 486 C149 491 156 487 152 479 C149 467 135 453 120 450Z"
          fill="#393A35"
          stroke="#2B2D29"
          strokeWidth="1.5"
          strokeLinejoin="round"
        />
      </g>

      <g>
        <g>
          <path d="M232 570 L270 570 L270 592 L227 592Z" fill="#F2EFF8" />
          <path d="M228 583 C239 588 256 589 270 582 C287 582 309 596 322 611 C330 620 334 630 331 636 C305 647 252 647 225 638 C214 634 216 623 220 608Z" fill="#8C6AA7" />
          <path d="M219 622 C244 635 299 639 333 628 L332 637 C328 646 292 648 262 646 C236 645 216 640 219 622Z" fill="#383333" />
          <path d="M294 590 C287 596 281 602 278 608" stroke="#F5F2F9" strokeWidth="8" strokeLinecap="round" />
        </g>
        <g>
          <path d="M396 570 L434 570 L434 592 L391 592Z" fill="#F2EFF8" />
          <path d="M392 583 C404 588 421 589 435 582 C452 583 474 596 487 612 C495 621 499 631 496 637 C470 647 417 647 390 638 C379 634 381 623 385 608Z" fill="#8C6AA7" />
          <path d="M384 622 C409 635 464 639 498 628 L497 637 C493 646 457 648 427 646 C401 645 381 640 384 622Z" fill="#383333" />
          <path d="M459 590 C452 596 446 602 443 608" stroke="#F5F2F9" strokeWidth="8" strokeLinecap="round" />
        </g>
      </g>
    </svg>
  )
}
