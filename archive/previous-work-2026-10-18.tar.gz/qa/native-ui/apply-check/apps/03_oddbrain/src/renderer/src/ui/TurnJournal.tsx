import { useEffect, useState } from 'react'
import { trapDialogFocus } from './focus'
import { X } from 'lucide-react'
import { useEngine } from '../state/engine'
/** Actual engine records, never generated activity. */
export default function TurnJournal() {
  const engine = useEngine(), [open, setOpen] = useState(false)
  useEffect(() => { const show = (): void => setOpen(true); window.addEventListener('app:show-journal', show); return () => window.removeEventListener('app:show-journal', show) }, [])
  useEffect(() => { if (!open) return; const close = (e: KeyboardEvent): void => { if (e.key === 'Escape') { e.stopPropagation(); setOpen(false) } }; window.addEventListener('keydown', close, true); return () => window.removeEventListener('keydown', close, true) }, [open])
  if (!open) return null
  return <div className="ob-modal-backdrop" onPointerDown={e => { if (e.target === e.currentTarget) setOpen(false) }}><section className="ob-journal" role="dialog" aria-modal="true" onKeyDown={trapDialogFocus} aria-label="Turn journal"><header><h2>Turn journal</h2><button type="button" className="ob-icon-button" aria-label="Close journal" onClick={() => setOpen(false)} autoFocus><X size={16} /></button></header>{engine.journal.length ? <ol>{engine.journal.map((entry, index) => <li key={`${entry.at}-${index}`}><time>{new Date(entry.at).toLocaleString()}</time><h3>{entry.prompt}</h3><p>{entry.answer || 'No answer was recorded.'}</p>{entry.usage ? <small>{entry.usage}</small> : null}</li>)}</ol> : <p>No turns recorded yet.</p>}</section></div>
}
