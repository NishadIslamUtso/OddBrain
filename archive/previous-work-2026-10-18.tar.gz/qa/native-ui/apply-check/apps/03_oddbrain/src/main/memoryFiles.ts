/**
 * The memory folder's reader: what the engine wrote, listed for the owner.
 * Reads only inside the vault's memory folder — the path is validated
 * against tricks before anything opens — and deletes are exactly one file,
 * never a glob.
 */
import { lstat, readFile, realpath, readdir, rm } from 'node:fs/promises'
import { join, sep } from 'node:path'
import { MEMORY_DIR, MEMORY_READ_CAP, safeMemoryRelative, type MemoryFile } from '../shared/lib/memory'

export type MemoryListAnswer = {
  ok: boolean
  answer?: string
  folder?: string
  files?: MemoryFile[]
}

export function createMemoryManager(vaultRoot: () => string) {
  const folder = (): string => join(vaultRoot(), MEMORY_DIR)

  const list = async (): Promise<MemoryListAnswer> => {
    let names: string[]
    try {
      names = (await readdir(folder())).filter(entry => entry.endsWith('.md')).sort()
    } catch {
      // No folder yet: the engine has remembered nothing. That is honest.
      return { ok: true, folder: folder(), files: [] }
    }
    const files: MemoryFile[] = []
    for (const name of names) {
      const full = join(folder(), name)
      try {
        // A symlink inside the memory folder is NOT memory — it can point
        // anywhere on the disk, so listing follows only real files (the vault
        // service makes the same refusal with the same reasoning).
        const info = await lstat(full)
        if (info.isSymbolicLink()) continue
        const raw = await readFile(full, 'utf8')
        files.push({
          name,
          path: `${MEMORY_DIR}/${name}`,
          updated: info.mtime.toISOString(),
          content: raw.length > MEMORY_READ_CAP ? raw.slice(0, MEMORY_READ_CAP) : raw,
          clipped: raw.length > MEMORY_READ_CAP,
        })
      } catch {
        continue
      }
    }
    return { ok: true, folder: folder(), files }
  }

  /**
   * The real folder, resolved: the final containment check. The name guard is
   * lexical; this one is the filesystem's own truth — a symlink that slipped
   * in resolves to somewhere else and is refused before it is read or removed.
   */
  const realFolder = async (): Promise<string> => realpath(folder())

  const contained = async (full: string): Promise<boolean> => {
    const realFile = await realpath(full)
    return realFile === (await realFolder()) || realFile.startsWith(`${await realFolder()}${sep}`)
  }

  const remove = async (name: string): Promise<{ ok: boolean; answer: string }> => {
    const checked = safeMemoryRelative(name)
    if (!checked.ok) return checked
    const full = join(vaultRoot(), checked.rel)
    try {
      if (!(await contained(full))) return { ok: false, answer: 'That path is not really inside the memory folder.' }
      await rm(full, { force: false })
      return { ok: true, answer: `Removed ${checked.rel}. The lines are gone; nothing was kept in secret.` }
    } catch (failure) {
      const code = (failure as NodeJS.ErrnoException).code
      if (code === 'ENOENT') return { ok: false, answer: 'That memory file does not exist.' }
      return { ok: false, answer: `Could not remove: ${(failure as Error).message}` }
    }
  }

  const read = async (name: string): Promise<{ ok: boolean; content?: string; answer?: string }> => {
    const checked = safeMemoryRelative(name)
    if (!checked.ok) return checked
    const full = join(vaultRoot(), checked.rel)
    try {
      if (!(await contained(full))) return { ok: false, answer: 'That path is not really inside the memory folder.' }
      return { ok: true, content: await readFile(full, 'utf8') }
    } catch (failure) {
      const code = (failure as NodeJS.ErrnoException).code
      if (code === 'ENOENT') return { ok: false, answer: 'That memory file does not exist yet.' }
      return { ok: false, answer: `Could not read: ${(failure as Error).message}` }
    }
  }

  return { list, remove, read }
}

export type MemoryManager = ReturnType<typeof createMemoryManager>
