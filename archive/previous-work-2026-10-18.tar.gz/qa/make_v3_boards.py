from pathlib import Path
import json,html
r=Path('/home/user/oddbrain-motion')
new=[x for x in json.loads((r/'manifest.json').read_text())['motions'] if x['volume']==3]
css='''<style>*{box-sizing:border-box}body{margin:0;padding:18px;display:grid;grid-template-columns:repeat(4,1fr);gap:12px;background:#eae5ed;font-family:Arial;color:#665170}.cell{background:#fffdf8;border-radius:12px;padding:8px 12px 16px}.art{height:267px;--play-state:paused}.art>svg{width:100%;height:100%}h3{font-size:12px;margin:4px 0 6px}p{font-size:10px;margin:0;color:#937ba0}</style>'''
s='<!doctype html><meta charset="utf-8">'+css
for x in new:
 s+=f'<article class="cell" data-id="{x["id"]}" data-duration="{x["duration"]}" data-loop="{x["loop"]}"><div class="art">{(r/x["file"]).read_text()}</div><h3>{x["index"]} · {html.escape(x["name"])}</h3><p>{x["id"]} · {x["duration"]}s {"loop" if x["loop"] else "one-shot"}</p></article>'
Path('/home/user/qa/v3-board.html').write_text(s)
