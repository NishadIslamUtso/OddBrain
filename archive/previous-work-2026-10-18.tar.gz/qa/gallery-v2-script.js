
'use strict';
const D=JSON.parse(document.getElementById('motion-data').textContent);
const TOTAL=D.motions.length, WORD_COUNT=Object.keys(D.statusMap).length;
const $=id=>document.getElementById(id);
const $$=s=>Array.from(document.querySelectorAll(s));
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=id=>`<svg class="icon" aria-hidden="true"><use href="#i-${id}"/></svg>`;
const normalize=s=>s.normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
const normalizedMap=new Map(Object.entries(D.statusMap).map(([w,m])=>[normalize(w),{word:w,id:m}]));
const compactMeta={id:'loader-eye-roll',index:D.motions.length+1,name:'Little brain. Big loading energy.',category:'Utility',duration:1.2,loop:true,energy:'low',description:'A simplified little brain with raised glasses and two continuously orbiting pupils. Designed for 24–64px loading indicators.',defaultWord:'Befuddling',words:['Befuddling','Puzzling','Flummoxing','Discombobulating']};
const byId=new Map(D.motions.map(x=>[x.id,x]));byId.set(compactMeta.id,compactMeta);
let counter=0,currentId='shoe-skateboard',currentWord='Skateboarding',paused=false,speed=1,category='New',query='',previewsRunning=true,currentCodeTab='react',toastTimer;
const visibleCards=new Set();
function makeMarkup(id){const s=D.artwork[id];const p=s.match(/<svg[^>]*\bid="([^"]+)"/)[1];return s.split(p).join(p+'-view'+(++counter)).replace('role="img"','aria-hidden="true" focusable="false"').replace(/ aria-labelledby="[^"]*"/,'');}
function mount(id,node){node.innerHTML=makeMarkup(id);}
function toast(message){$('toast').textContent=message;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),2600);}
function resetTimeline(){const e=$('timeline-fill');e.style.animation='none';void e.offsetWidth;e.style.animation='';}
function updatePlayback(){const stage=$('stage');stage.style.setProperty('--play-state',paused?'paused':'running');stage.style.setProperty('--duration-scale',String(1/speed));stage.style.setProperty('--cycle',`${byId.get(currentId).duration/speed}s`);$('toggle-play').setAttribute('aria-label',paused?'Play motion':'Pause motion');$('toggle-play').setAttribute('aria-pressed',String(paused));$('toggle-play').innerHTML=icon(paused?'play':'pause');$('timeline-time').textContent=`${(byId.get(currentId).duration/speed).toFixed(1)}s`;}
function choose(id,word,scroll=false){const c=byId.get(id);if(!c)return;currentId=id;currentWord=word||c.defaultWord;paused=false;mount(id,$('hero-art'));$('hero-art').classList.toggle('is-compact',id==='loader-eye-roll');$('stage').classList.toggle('one-shot',!c.loop);$('stage-word').textContent=currentWord+'…';$('motion-category').textContent=c.category;$('motion-counter').textContent=id==='loader-eye-roll'?'UTILITY / 96 PX':String(c.index).padStart(2,'0')+' / '+TOTAL;$('motion-name').textContent=c.name;$('motion-description').textContent=c.description+'.';if(c.description.endsWith('.'))$('motion-description').textContent=c.description;$('motion-badges').innerHTML=(c.volume===2?'<span class="badge">NEW / VOL 02</span>':'')+`<span class="badge">${c.loop?'Loop':'One-shot'}</span><span class="badge">${c.duration.toFixed(1)} s</span><span class="badge">${c.energy} energy</span>`;$('alias-chips').innerHTML=c.words.slice(0,4).map(w=>`<button class="alias-chip" data-word="${esc(w)}">${esc(w)}</button>`).join('');if(!c.words.length)$('alias-chips').innerHTML='<span class="alias-chip">Welcome screen</span><span class="alias-chip">App startup</span>';$('word-feedback').textContent=c.words.length?`${c.words.length} word${c.words.length===1?'':'s'} ${c.words.length===1?'maps':'map'} to this ${c.loop?'loop':'entrance'}.`:'A one-time hello. Use Replay to run it again.';$$('.motion-card').forEach(n=>n.setAttribute('aria-pressed',String(n.dataset.id===id)));$$('.shortcut').forEach(n=>n.classList.toggle('active',n.dataset.select===id));updatePlayback();resetTimeline();updateCode();updateTakeControls();if(scroll)$('playground').scrollIntoView({behavior:'smooth',block:'start'});}
function move(delta){let i=D.motions.findIndex(c=>c.id===currentId);if(i<0)i=0;choose(D.motions[(i+delta+D.motions.length)%D.motions.length].id);}
$('previous-motion').onclick=()=>move(-1);$('next-motion').onclick=()=>move(1);$('toggle-play').onclick=()=>{paused=!paused;updatePlayback();};$('replay-motion').onclick=()=>{mount(currentId,$('hero-art'));paused=false;updatePlayback();resetTimeline();};$('shuffle-motion').onclick=()=>{const choices=D.motions.filter(c=>c.id!==currentId);choose(choices[Math.floor(Math.random()*choices.length)].id);};$('speed-select').onchange=e=>{speed=Number(e.target.value);updatePlayback();resetTimeline();};
$$('.swatch').forEach(b=>b.onclick=()=>{$('stage').dataset.bg=b.dataset.bg;$$('.swatch').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));});
$$('[data-select]').forEach(b=>b.onclick=()=>choose(b.dataset.select,undefined,window.scrollY>$('playground').offsetTop+200));
$('all-statuses').innerHTML=Object.keys(D.statusMap).map(w=>`<option value="${esc(w)}"></option>`).join('');
$('word-form').onsubmit=e=>{e.preventDefault();const value=$('word-input').value.trim();if(!value)return;const match=normalizedMap.get(normalize(value));if(match){choose(match.id,match.word);}else{choose('think',value.replace(/[.…]+$/g,''));$('word-feedback').textContent='A new word! Using calm thought as the fallback.';} };$('alias-chips').onclick=e=>{const b=e.target.closest('[data-word]');if(b){const word=b.dataset.word;$('word-input').value=word;$('stage-word').textContent=word+'…';currentWord=word;updateCode();updateTakeControls();}};
function takePool(){const match=normalizedMap.get(normalize(currentWord));return match?(D.variantMap[match.word]||[match.id]):['think'];}
function updateTakeControls(){
 const pool=takePool(),index=pool.indexOf(currentId),available=pool.length>1&&index>=0&&currentId!=='loader-eye-roll'&&currentId!=='assemble';
 $('another-take').hidden=!available;
 if(available){$('take-label').textContent=`Another take · ${index+1}/${pool.length}`;$('word-feedback').textContent=`Take ${index+1} of ${pool.length} for “${currentWord}”. Original default stays unchanged.`;}
}
$('another-take').onclick=()=>{const pool=takePool(),i=pool.indexOf(currentId);choose(pool[(i+1)%pool.length],currentWord);};
const io=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting)visibleCards.add(e.target);else visibleCards.delete(e.target);e.target.style.setProperty('--play-state',e.isIntersecting&&previewsRunning?'running':'paused');});},{rootMargin:'80px',threshold:.05});
function renderFilters(){
 const categories=['New','All','Thinking','Making','Dancing','Cooking','Mischief','Travel','Magic','Special'];
 $('filters').innerHTML=categories.map(c=>{
  const count=c==='All'?TOTAL:c==='New'?D.motions.filter(m=>m.volume===2).length:D.motions.filter(m=>m.category===c).length;
  return `<button class="filter" data-filter="${c}" aria-pressed="${category===c}">${c==='New'?'✳ New':c}<span class="filter-count">${count}</span></button>`;
 }).join('')+`<button class="preview-switch" id="preview-switch" aria-label="${previewsRunning?'Pause':'Play'} gallery previews">${icon(previewsRunning?'pause':'play')}<span>${previewsRunning?'Pause previews':'Play previews'}</span></button>`;
}
function renderGrid(){io.disconnect();visibleCards.clear();const q=normalize(query);const result=D.motions.filter(c=>(category==='All'||(category==='New'?c.volume===2:c.category===category))&&(!q||normalize([c.name,c.id,c.category,...c.words,...(c.suggestedFor||[])].join(' ')).includes(q)));$('library-count').textContent=result.length+' motion'+(result.length===1?'':'s');$('motion-grid').innerHTML=result.length?result.map(c=>`<button class="motion-card" data-id="${c.id}" data-category="${c.category}" aria-label="Preview ${esc(c.name)}" aria-pressed="${c.id===currentId}"><div class="card-art"><span class="card-index">${String(c.index).padStart(2,'0')}</span>${c.volume===2?'<span class="card-new">NEW</span>':''}<span class="energy-dots" title="${c.energy} energy"><i class="on"></i><i class="${c.energy!=='low'?'on':''}"></i><i class="${c.energy==='high'?'on':''}"></i></span><div class="svg-slot" aria-hidden="true">${makeMarkup(c.id)}</div><span class="card-kind">${c.loop?'Loop':'Entrance'}</span></div><div class="card-caption"><div><h3 class="card-title">${esc(c.name)}</h3><p class="card-subtitle">${esc(c.defaultWord)}${c.words.length>1?`<span>+${c.words.length-1} words</span>`:''}</p></div><svg class="icon card-arrow" aria-hidden="true"><use href="#i-arrow"/></svg></div></button>`).join(''):'<div class="no-results"><strong>No brainwaves found.</strong>Try a thinking word, a mood, or another category.<br><button id="reset-filter">Show every motion</button></div>';$$('.motion-card').forEach(n=>io.observe(n));}
$('filters').onclick=e=>{const f=e.target.closest('[data-filter]');if(f){category=f.dataset.filter;renderFilters();renderGrid();return;}if(e.target.closest('#preview-switch')){previewsRunning=!previewsRunning;visibleCards.forEach(n=>n.style.setProperty('--play-state',previewsRunning?'running':'paused'));renderFilters();}};$('library-search').oninput=e=>{query=e.target.value;renderGrid();};$('motion-grid').onclick=e=>{const c=e.target.closest('.motion-card');if(c)choose(c.dataset.id,undefined,true);if(e.target.closest('#reset-filter')){category='All';query='';$('library-search').value='';renderFilters();renderGrid();}};
mount('loader-eye-roll',$('chat-loader'));mount('assemble',$('entrance-art'));
$$('[data-loader-size]').forEach(b=>b.onclick=()=>{const n=Number(b.dataset.loaderSize);$('chat-loader').style.width=n+'px';$('chat-loader').style.height=n+'px';$$('[data-loader-size]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));});
const entranceObserver=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){mount('assemble',$('entrance-art'));$('entrance-art').style.setProperty('--play-state','running');entranceObserver.disconnect();}},{threshold:.35});entranceObserver.observe($('entrance-art'));
$('replay-entrance').onclick=()=>{mount('assemble',$('entrance-art'));$('entrance-art').style.setProperty('--play-state','running');};
function download(filename,body,type){const blob=body instanceof Blob?body:new Blob([body],{type:type||'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);}
function exportSVG(id){let source=D.artwork[id];if(id===currentId&&speed!==1)source=source.replace(/(<svg\b[^>]*)(>)/,`$1 style="--duration-scale:${1/speed}"$2`);download('oddbrain-'+id+'.svg',source,'image/svg+xml');toast('SVG exported. Time to cause a little trouble.');}
$('export-svg').onclick=()=>exportSVG(currentId);$('download-loader').onclick=()=>exportSVG('loader-eye-roll');$('download-entrance').onclick=()=>exportSVG('assemble');
async function copyText(text){try{if(!navigator.clipboard)throw new Error('Clipboard not available');await navigator.clipboard.writeText(text);toast('Copied. Ready for your app.');}catch{const d=$('copy-dialog');$('copy-text').value=text;if(d.showModal)d.showModal();else d.setAttribute('open','');$('copy-text').focus();$('copy-text').select();}}
$('copy-svg').onclick=()=>copyText(D.artwork[currentId]);$('close-dialog').onclick=()=>{$('copy-dialog').close();};
function codeExample(){
 const pool=takePool(),take=pool.indexOf(currentId);
 if(currentCodeTab==='react'){
  if(currentId==='loader-eye-roll')return `import { OddbrainLoader } from "./Oddbrain";

<OddbrainLoader size={32} label="Loading" />`;
  if(currentId==='assemble')return `import { Oddbrain } from "./Oddbrain";

<Oddbrain motion="assemble" size={260} />
// Plays once. Change replayKey to restart.`;
  const props=take>=0?'word={'+JSON.stringify(currentWord)+'}'+(take>0?' variant={'+take+'}':''):'motion='+JSON.stringify(currentId);
  return `import { Oddbrain } from "./Oddbrain";

<Oddbrain ${props} size={100} />
// Or motion=${JSON.stringify(currentId)} for a direct pick.`;
 }
 if(currentCodeTab==='html')return `<img
  src="/oddbrain/${currentId}.svg"
  width="${currentId==='loader-eye-roll'?'32':'100'}" height="${currentId==='loader-eye-roll'?'32':'100'}"
  alt=""
/>
<!-- Pair with visible status text. -->`;
 if(currentId==='assemble')return `// The entrance is intentionally not a word loop.
<Oddbrain motion="assemble" size={260} />

// All ${WORD_COUNT} status words resolve to reusable loops.`;
 if(take>0)return `import { resolveMotionVariant } from "./resolve-motion";

resolveMotionVariant(${JSON.stringify(currentWord)}, ${take});
// → ${JSON.stringify(currentId)}
// Index zero always keeps the original default.`;
 const mapped=normalizedMap.get(normalize(currentWord));
 return `import { resolveMotion } from "./resolve-motion";

resolveMotion(${JSON.stringify(currentWord)});
// → ${JSON.stringify(mapped?mapped.id:'think')}

resolveMotion("A brand-new word"); // → "think"`;
}
function updateCode(){$('code-example').textContent=codeExample();}
$$('[data-code-tab]').forEach(b=>b.onclick=()=>{currentCodeTab=b.dataset.codeTab;$$('[data-code-tab]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));updateCode();});$('copy-code').onclick=()=>copyText(codeExample());
function renderVocab(value=''){const n=normalize(value);const entries=Object.entries(D.statusMap).filter(([word])=>normalize(word).includes(n));$('vocab-grid').innerHTML=entries.length?entries.map(([word,id])=>`<button class="vocab-row" data-vocab-word="${esc(word)}"><span>${esc(word)}</span><span class="vocab-motion">${esc(byId.get(id).name)}${(D.variantMap[word]||[]).length>1?` <i>+${D.variantMap[word].length-1} takes</i>`:''} ↗</span></button>`).join(''):'<p class="vocab-note">That word is not in the 259-word registry. Unknown words fall back to calm thought.</p>';}
$('vocab-search').oninput=e=>renderVocab(e.target.value);$('vocab-grid').onclick=e=>{const b=e.target.closest('[data-vocab-word]');if(b){const w=b.dataset.vocabWord;choose(D.statusMap[w],w,true);$('word-input').value=w;}};
// Tiny dependency-free ZIP writer (STORE). Keeps downloads available even offline.
const crcTable=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function crc32(bytes){let c=0xffffffff;for(const n of bytes)c=crcTable[(c^n)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
function zipFiles(files){const enc=new TextEncoder();const chunks=[],central=[];let offset=0,centralSize=0;for(const [name,text]of Object.entries(files)){const nb=enc.encode(name),data=enc.encode(text),crc=crc32(data);const h=new Uint8Array(30+nb.length);const v=new DataView(h.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x0800,true);v.setUint16(8,0,true);v.setUint16(12,0x21,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,nb.length,true);h.set(nb,30);chunks.push(h,data);const ch=new Uint8Array(46+nb.length);const cv=new DataView(ch.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x0800,true);cv.setUint16(14,0x21,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,nb.length,true);cv.setUint32(42,offset,true);ch.set(nb,46);central.push(ch);centralSize+=ch.length;offset+=h.length+data.length;}const end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,central.length,true);ev.setUint16(10,central.length,true);ev.setUint32(12,centralSize,true);ev.setUint32(16,offset,true);return new Blob([...chunks,...central,end],{type:'application/zip'});}
function downloadPack(){
 toast(`Packing ${Object.keys(D.artwork).length} little troublemakers…`);
 setTimeout(()=>{
  const files={};
  for(const [id,svg]of Object.entries(D.artwork))files['oddbrain-motion/svg/'+id+'.svg']=svg;
  files['oddbrain-motion/manifest.json']=JSON.stringify(D.manifest,null,2);
  files['oddbrain-motion/status-map.json']=JSON.stringify(D.statusMap,null,2);
  files['oddbrain-motion/status-map-original.json']=JSON.stringify(Object.fromEntries(Object.entries(D.statusMap).slice(0,D.manifest.originalStatusCount)),null,2);
  files['oddbrain-motion/status-variants.json']=JSON.stringify(D.variantMap,null,2);
  files['oddbrain-motion/react/motion-data.ts']=`export const motionSvg = ${JSON.stringify(D.artwork)} as const;
export type MotionId = keyof typeof motionSvg;
`;
  for(const [name,text]of Object.entries(D.downloadFiles||{}))files['oddbrain-motion/'+name]=text;
  files['oddbrain-motion/source/gallery-data.json']=JSON.stringify({motions:D.motions,statusMap:D.statusMap,variantMap:D.variantMap,manifest:D.manifest,artwork:D.artwork});
  files['oddbrain-motion/index.html']='<!doctype html>'+String.fromCharCode(10)+document.documentElement.outerHTML;
  download('oddbrain-motion-kit.zip',zipFiles(files));
  toast('Full pack exported: 60 motions, loader, word variants + React.');
 },30);
}
$$('[data-download-pack]').forEach(b=>b.onclick=downloadPack);
document.addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)||$('copy-dialog').open)return;if(e.key==='ArrowRight'){e.preventDefault();move(1);}if(e.key==='ArrowLeft'){e.preventDefault();move(-1);}if(e.code==='Space'&&e.target===document.body){e.preventDefault();paused=!paused;updatePlayback();}});
renderFilters();renderGrid();renderVocab();choose('shoe-skateboard');
// A tiny test/integration hook; no animation loop is driven by JavaScript.
window.oddbrain={select:choose,data:D,normalize,downloadPack};
