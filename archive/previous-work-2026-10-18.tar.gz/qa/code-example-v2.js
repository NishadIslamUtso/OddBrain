function codeExample(){
 const pool=takePool(),take=pool.indexOf(currentId);
 if(currentCodeTab==='react'){
  if(currentId==='loader-eye-roll')return `import { OddbrainLoader } from "./Oddbrain";

<OddbrainLoader size={32} label="Loading" />`;
  if(currentId==='assemble')return `import { Oddbrain } from "./Oddbrain";

<Oddbrain motion="assemble" size={260} />
// Plays once. Change replayKey to restart.`;
  const props=take>=0?'word={'+JSON.stringify(currentWord)+'}'+(take>0?' variant={'+take+'}':''):'motion='+JSON.stringify(currentId);
  return `import { Oddbrain } from "./Oddbrain";

<Oddbrain ${props} size={100} />
// Or motion=${JSON.stringify(currentId)} for a direct pick.`;
 }
 if(currentCodeTab==='html')return `<img
  src="/oddbrain/${currentId}.svg"
  width="${currentId==='loader-eye-roll'?'32':'100'}" height="${currentId==='loader-eye-roll'?'32':'100'}"
  alt=""
/>
<!-- Pair with visible status text. -->`;
 if(currentId==='assemble')return `// The entrance is intentionally not a word loop.
<Oddbrain motion="assemble" size={260} />

// All ${WORD_COUNT} status words resolve to reusable loops.`;
 if(take>0)return `import { resolveMotionVariant } from "./resolve-motion";

resolveMotionVariant(${JSON.stringify(currentWord)}, ${take});
// → ${JSON.stringify(currentId)}
// Index zero always keeps the original default.`;
 const mapped=normalizedMap.get(normalize(currentWord));
 return `import { resolveMotion } from "./resolve-motion";

resolveMotion(${JSON.stringify(currentWord)});
// → ${JSON.stringify(mapped?mapped.id:'think')}

resolveMotion("A brand-new word"); // → "think"`;
}
