const {chromium}=require('playwright');const fs=require('fs');const assert=require('assert/strict');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1000,height:900}});const errors=[],remote=[];p.on('pageerror',e=>errors.push(e.message));p.on('request',r=>{if(/^https?:/.test(r.url()))remote.push(r.url())});
const source=fs.readFileSync('/home/user/oddbrain-motion/svg/forge.svg','utf8');
await p.setContent('<style>body{margin:0}svg{width:740px;height:740px}</style>'+source);
const metrics=await p.evaluate(()=>{
 const svg=document.querySelector('svg'),arm=svg.querySelector('.rig-right-arm'),hammer=svg.querySelector('.prop-hammer'),head=svg.querySelector('.hammer-head');
 const point=(el,x,y)=>new DOMPoint(x,y).matrixTransform(el.getScreenCTM());let gripError=0,clipped=0;
 for(let i=0;i<=120;i++){
  svg.getAnimations({subtree:true}).forEach(a=>{a.pause();a.currentTime=i/120*1800});
  const a=point(arm,637,480),h=point(hammer,637,480);gripError=Math.max(gripError,Math.hypot(a.x-h.x,a.y-h.y));
  const box=head.getBoundingClientRect();if(box.left<0||box.top<0||box.right>740||box.bottom>740)clipped++;
 }
 svg.getAnimations({subtree:true}).forEach(a=>{a.pause();a.currentTime=.6*1800});
 const a=point(head,674.05,570),z=point(head,674.05,589);
 return {gripError,clipped,strikingFaceY:a.y,strikingFaceTilt:Math.abs(z.y-a.y),contactError:Math.abs(a.y-474.5),headBeforeMitten:arm.children[1]===hammer&&arm.children[2].tagName==='path'};
});
assert.equal(metrics.gripError,0);assert.equal(metrics.clipped,0);assert.ok(metrics.strikingFaceTilt<.01);assert.ok(metrics.contactError<1);assert.equal(metrics.headBeforeMitten,true);console.log('PASS hammer mechanics:',JSON.stringify(metrics));
await p.goto('file:///home/user/oddbrain-motion/index.html');assert.equal(await p.locator('#motion-name').textContent(),'Tiny tinkerer');assert.equal(await p.locator('.motion-card').count(),16);assert.equal(await p.locator('.vocab-row').count(),304);
await p.locator('[data-filter="All"]').click();assert.equal(await p.locator('.motion-card').count(),76);const ids=await p.locator('[id]').evaluateAll(ns=>ns.map(n=>n.id));assert.equal(ids.length,new Set(ids).size);
await p.locator('#toggle-play').click();const snap=()=>p.locator('#hero-art').evaluate(e=>e.getAnimations({subtree:true}).map(a=>({time:a.currentTime,state:a.playState})));const before=await snap();await p.waitForTimeout(75);assert.deepEqual(await snap(),before);assert.ok(before.every(a=>a.state==='paused'));
await p.locator('#speed-select').selectOption('2');assert.equal(await p.locator('#hero-art .rig-right-arm').evaluate(e=>getComputedStyle(e).animationDuration),'0.9s');await p.locator('#speed-select').selectOption('1');
const dl=p.waitForEvent('download');await p.locator('#export-svg').click();await(await dl).saveAs('/home/user/qa/hammer-export.svg');assert.equal(fs.readFileSync('/home/user/qa/hammer-export.svg','utf8'),source);
const zip=p.waitForEvent('download');await p.locator('[data-download-pack]').first().click();await(await zip).saveAs('/home/user/qa/hammer-browser-pack.zip');
await p.emulateMedia({reducedMotion:'reduce'});assert.equal(await p.locator('#hero-art').evaluate(e=>e.getAnimations({subtree:true}).length),0);assert.equal(await p.locator('#hero-art .prop-hammer').evaluate(e=>getComputedStyle(e).visibility),'visible');
await p.emulateMedia({reducedMotion:'no-preference'});await p.goto('file:///home/user/oddbrain-motion/svg/forge.svg');assert.ok((await p.evaluate(()=>document.getAnimations().length))>0);await p.emulateMedia({reducedMotion:'reduce'});assert.equal(await p.evaluate(()=>document.getAnimations().length),0);
assert.deepEqual(errors,[]);assert.deepEqual(remote,[]);console.log('PASS gallery opening on corrected clip, full library, unique IDs, true pause, speed, exact SVG export, browser ZIP and standalone/reduced motion; zero errors or remote requests.');await b.close();})().catch(e=>{console.error(e);process.exit(1)});
