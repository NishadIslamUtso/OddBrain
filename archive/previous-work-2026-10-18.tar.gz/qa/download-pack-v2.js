function downloadPack(){
 toast(`Packing ${Object.keys(D.artwork).length} little troublemakers…`);
 setTimeout(()=>{
  const files={};
  for(const [id,svg]of Object.entries(D.artwork))files['oddbrain-motion/svg/'+id+'.svg']=svg;
  files['oddbrain-motion/manifest.json']=JSON.stringify(D.manifest,null,2);
  files['oddbrain-motion/status-map.json']=JSON.stringify(D.statusMap,null,2);
  files['oddbrain-motion/status-map-original.json']=JSON.stringify(Object.fromEntries(Object.entries(D.statusMap).slice(0,D.manifest.originalStatusCount)),null,2);
  files['oddbrain-motion/status-variants.json']=JSON.stringify(D.variantMap,null,2);
  files['oddbrain-motion/react/motion-data.ts']=`export const motionSvg = ${JSON.stringify(D.artwork)} as const;
export type MotionId = keyof typeof motionSvg;
`;
  for(const [name,text]of Object.entries(D.downloadFiles||{}))files['oddbrain-motion/'+name]=text;
  files['oddbrain-motion/source/gallery-data.json']=JSON.stringify({motions:D.motions,statusMap:D.statusMap,variantMap:D.variantMap,manifest:D.manifest,artwork:D.artwork});
  files['oddbrain-motion/index.html']='<!doctype html>'+String.fromCharCode(10)+document.documentElement.outerHTML;
  download('oddbrain-motion-kit.zip',zipFiles(files));
  toast('Full pack exported: 60 motions, loader, word variants + React.');
 },30);
}
