from pathlib import Path
ROOT=Path('/home/user/oddbrain-ui-source')
def update(name,old,new):
 p=ROOT/name;s=p.read_text();assert old in s,(name,old[:100]);p.write_text(s.replace(old,new,1))
update('app.js',"function seed(){return {version:1,theme:","function seed(){return {version:1,hasWelcome:false,pluginTab:'installed',battleTally:[],compactSeed:'',artifactAskId:null,theme:")
update('app.js',"function artifactContent(a,version=a.current){\n if(a.imported)","function artifactContent(a,version=a.current){\n if(a.snapshots&&typeof a.snapshots[version]==='string')return a.snapshots[version];\n if(a.imported)")
update('app.js',"else if(matches.length===0)dead.push({from:n.title,target:m[1]})","else if(matches.length!==1)dead.push({from:n.title,target:m[1],reason:matches.length?'ambiguous':'missing'})")
update('app.js',"const n=S.notes.find(n=>n.title.toLowerCase()===name.toLowerCase()||n.path.split('/').at(-1).slice(0,-3).toLowerCase()===name.toLowerCase());return n?", "const matches=S.notes.filter(n=>esc(n.title).toLowerCase()===name.toLowerCase()||esc(n.path.split('/').at(-1).slice(0,-3)).toLowerCase()===name.toLowerCase()),n=matches.length===1?matches[0]:null;return n?")
update('views.js',"${b('Compact','compact','minimize','',{chat:chat.id})}<span style=", "${b('Compact','compact','minimize','',{chat:chat.id})}${m.artifactId?b('Checkpoints','checkpoints','clock','',{id:m.artifactId}):''}${m.receiptId?b('Receipt','open-note','file','',{id:m.receiptId}):''}<span style=")
update('views.js',"<textarea id=\"message-input\"", "${S.compactSeed?`<div class=\"compact-seed-note\">${icon('file','sm')}A small handoff brief will travel with the next send, once.${b('Read it','view-seed','','text-btn')}</div>`:''}<textarea id=\"message-input\"")
update('views.js',"function renderRunCard(){if(!run)return '';", "function renderRunCard(){if(!run||run.chatId!==S.chatId)return '';")
update('views.js',"Sample edit · welcome.html · no real file access", "Sample edit · ${esc(run.fileName||'welcome.html')} · no real file access")
update('panels.js',"M=null;$('#modal-host').innerHTML='';if(modalReturn", "M=null;$('#modal-host').innerHTML='';$('#app').inert=false;$('#studio-host').inert=false;if(modalReturn")
update('panels.js',"$('#modal-host').innerHTML=html;afterRender();", "$('#modal-host').innerHTML=html;$('#app').inert=true;$('#studio-host').inert=true;afterRender();")
# Update the Split renderer in one write, rather than simultaneous same-file patches.
p=ROOT/'panels.js';s=p.read_text();a=s.index('function splitDialog(data)');b=s.index('\nfunction compactDialog',a)
s=s[:a]+'''function splitDialog(data){
 const phase=data.phase||'draft',steps=data.steps||['Inspect the current direction and the relevant sample notes.','Make one small, thoughtful change to the sample artifact.','Check the result and keep a clear handoff.'];
 let body=phase==='draft'?`<div class="field"><label for="split-order">The work order</label><textarea id="split-order" rows="4">${esc(data.order||S.draft||'Make the OddBrain welcome a little warmer, then check the result and write a handoff.')}</textarea></div><div class="card-note"><p class="note tiny">What would be sent: break this order into the shortest honest list of 2–6 steps. If it should run whole, say so. No approval is granted by planning.</p></div>`:`<p class="note">${esc(data.order)}</p><ol class="step-list">${steps.map((s,i)=>`<li class="${i<(data.completed||0)?'done':''}"><span class="step-number">${i<(data.completed||0)?'✓':i+1}</span><span>${s}<small>${i<(data.completed||0)?'Sample step complete':data.waiting&&i===1?'Waiting for approval before the sample edit':phase==='done'?'Complete':['stopped','failed'].includes(phase)?'Not run':'Pending its turn'}</small></span></li>`).join('')}</ol>${data.waiting?`<div class="permission-note">${icon('shield')}<p>The sample edit needs your yes. Later steps stay pending.</p></div>`:''}${phase==='done'?`<div class="card-note row">${mascot('shades-drop',80)}<p class="note">All three sample steps ran in order. The artifact was updated.${data.receipt?' A receipt was kept in the sample vault.':' Conversation receipts are off.'}</p></div>`:''}${phase==='stopped'?'<p class="note amber">Stopped. The remaining steps are not marked done.</p>':''}${phase==='failed'?'<p class="note amber">A simulated failure halted the sequence. Later steps did not run. Retry resumes at the unfinished step.</p>':''}`;
 const footer=phase==='draft'?b('Break it down','split-plan','split','btn primary'):phase==='ready'?b('Run the steps','split-run','play','btn primary'):data.waiting?b('Simulate failure','split-fail','','btn ghost')+b('Stop here','split-stop','stop','btn')+b('Allow the sample edit','split-allow','check','btn primary'):phase==='running'?b('Stop the sequence','split-stop','stop','btn'):phase==='done'?b('Open the artifact','split-artifact','shapes','btn')+b('See the receipt','split-receipt','file','btn primary'):b('Try again from here','split-run','play','btn primary');
 return dialog('A big thought, in little steps.','Split · the engine plans, the app runs in order. Scripted demonstration.',body,footer,'medium');
}
''' + s[b:];p.write_text(s)
update('panels.js',"case 'copy':html=dialog(","case 'view-seed':html=dialog('A little context for the next thought.','This brief is used once, without deleting the original conversation.',`<pre class=\"card-note\">${esc(S.compactSeed)}</pre>`,b('Leave it out','discard-seed','','btn')+b('Keep it close','modal-close','file','btn primary'));break;\n case 'copy':html=dialog(")
update('events.js',"lastView=key;applyPreferences();afterRender();", "lastView=key;applyPreferences();afterRender();setSidebarAccessibility();$('#app').inert=!!M;")
update('events.js',"watch:!!opts.watch};", "watch:!!opts.watch,seed:S.compactSeed||'',fileName:target?.type==='svg'?'sample-asset.svg':'welcome.html'};\n if(target?.type==='svg'){run.after=before.replace(/<svg\\b[^>]*>/i,tag=>tag+'<desc>A sample annotation, kept separate from the original motion kit.</desc>');run.beforeLine='<svg …>';run.afterLine='<svg …><desc>A sample annotation…</desc>';}")
update('events.js',"const receipt=addReceipt(stopped?", "if(work.seed&&!stopped)result+='\\n\\nThe one-use sample handoff brief was included as context.';\n const receipt=addReceipt(stopped?")
update('events.js',"function runSplit(){", "function runSplit(){")
# Replace controller functions as one contiguous block.
p=ROOT/'events.js';s=p.read_text();a=s.index('function runSplit()');b=s.index('\nfunction resetLook()',a)
s=s[:a]+'''function applySplitArtifact(data){
 if(data.artifactId)return;
 let a=S.artifacts.find(a=>a.kind==='poster');if(!a){a={id:id('art'),title:'A little welcome, in steps',type:'html',kind:'poster',at:'Just now',versions:['Before the little steps'],current:0};S.artifacts.unshift(a)}
 const before=artifactContent(a);if(!a.snapshots)a.snapshots={};a.versions.forEach((_,i)=>{if(!(i in a.snapshots))a.snapshots[i]=artifactContent(a,i)});a.versions.push('A thoughtful change, made in Split step 2');a.current=a.versions.length-1;a.snapshots[a.current]=before.replace(/<h1([^>]*)>[\\s\\S]*?<\\/h1>/i,'<h1$1>A little less starting.<br>A little more making.</h1>');a.at='Just now';data.artifactId=a.id;persist();
}
function runSplit(){
 if(!M||M.type!=='split')return;if(run){toast('Finish or stop the current engine preview first.');return}
 const data=M.data;clearSplitTimers();data.phase='running';data.waiting=false;renderModal();
 const next=()=>{if(!M||M.type!=='split'||M.data!==data||data.phase!=='running')return;
  if((data.completed||0)<1){data.completed=1;renderModal();splitTimers.push(setTimeout(next,650));return}
  if(data.completed<2&&['ask','plan'].includes(S.approval)){data.waiting=true;renderModal();return}
  if(data.completed<2){applySplitArtifact(data);data.completed=2;renderModal();splitTimers.push(setTimeout(next,650));return}
  data.completed=3;data.phase='done';data.waiting=false;data.receipt=addReceipt('One big thought, in little steps',data.order,'Three sample steps ran in order. Context reviewed; welcome artifact updated; a clear handoff kept. No actual engine ran.');
  let c=currentChat();if(!c){c={id:id('chat'),title:'One big thought, in little steps',projectId:S.projectId,at:'Just now',messages:[]};S.chats.unshift(c)}
  c.messages.push({role:'user',content:data.order},{role:'assistant',content:'Three sample steps, run in order. The welcome artifact has a new version; its history is intact. No actual engine ran.',artifactId:data.artifactId,receiptId:data.receipt,motion:'shades-drop'});
  addActivity('Sample Split completed in order');persist();renderModal();renderApp();
 };splitTimers.push(setTimeout(next,600));
}
function finishSplitEdit(){if(!M||M.type!=='split')return;applySplitArtifact(M.data);M.data.waiting=false;M.data.completed=2;runSplit()}
''' + s[b:];p.write_text(s)
update('events.js',"case 'artifact':openModal('artifact',{id:v.id});return;", "case 'artifact':openModal('artifact',{id:v.id});return;\n case 'checkpoints':openModal('artifact',{id:v.id,tab:'history'});return;\n case 'view-seed':openModal('view-seed');return;\n case 'discard-seed':S.compactSeed='';closeModal();renderApp();toast('The brief stays in the vault, but will not travel with the next send.');return;")
update('events.js',"case 'split-receipt':{", "case 'split-artifact':{const aId=M.data.artifactId;openModal('artifact',{id:aId});return;}\n case 'split-receipt':{")
update('events.js',"window.addEventListener('resize',()=>requestAnimationFrame(()=>{if($('#graph-svg'))drawGraph()}));", "function setSidebarAccessibility(){const side=$('.sidebar');if(!side)return;const hidden=window.matchMedia('(max-width:730px)').matches&&!mobileOpen;side.inert=hidden;side.setAttribute('aria-hidden',String(hidden));}\nwindow.addEventListener('resize',()=>requestAnimationFrame(()=>{if($('#graph-svg'))drawGraph();setSidebarAccessibility()}));")
# Pause indicator for one-use compaction context.
p=ROOT/'styles.css';s=p.read_text();s+='\n.compact-seed-note{display:flex;align-items:center;gap:7px;padding:10px 14px 0;font-size:9px;color:var(--accent)}.compact-seed-note .text-btn{margin-left:auto;font-size:9px;flex:none}\n';p.write_text(s)
print('Completed concept state, snapshots, checkpoints, split retry, modal accessibility and one-use brief wiring.')
