# Oddbrain — Volume 02 only

24 new transparent, CSS-animated SVG loops. Combine them with your original pack for 60 full-character motions. See VOLUME-02.md for the complete list.

Copy svg/*.svg into your app's existing mascot asset directory. status-map-additions.json contains 72 new word mappings; merge it with the original 187 rather than replacing them. status-variants.json is intended for the combined 60-motion library.

This small archive does not include the gallery, updated React component, generators, or the playback-CSS fix for the V1 assets. Use oddbrain-motion-kit.zip for those.
