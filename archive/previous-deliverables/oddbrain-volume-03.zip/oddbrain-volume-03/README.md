# Oddbrain — Volume 03 only

16 new transparent, CSS-animated SVG scenes: **15 loops + one 2.2-second completion cue**. Add them to Volume 02 for 76 character motions, the compact loader, and 304 words. The existing 61 V2 SVGs do not need replacing.

## Add to your app

1. Copy `svg/*.svg` into your existing mascot asset directory. Each SVG is self-contained; external `<img>` use needs no animation runtime.
2. Merge `status-map-additions.json` (45 words) into your existing 259-word map. Do not replace the old map with this additions-only file.
3. `status-variants.json` is the **complete 304-word variant registry for the combined 76-motion kit**. It references existing assets as well as these sixteen. Every previous default and alternate-take index is preserved.

`shades-drop.svg` is a one-shot: plays once, holds its final pose. It is deliberately not mapped to a loading/thinking word. Re-create the external image to replay it, or use the full pack's React `replayKey` prop.

See `VOLUME-03.md` for all new IDs, timings and words, and `REFERENCE-REVIEW.md` for what was kept and discarded from the references.

This smaller archive does not include the offline gallery, updated typed React registries, original mascot, generators, or baseline validators. **Use `oddbrain-motion-kit.zip` for React integration and rebuilding.** Do not copy only the new SVGs into an old inline React bundle and expect its embedded motion registry to update automatically.
