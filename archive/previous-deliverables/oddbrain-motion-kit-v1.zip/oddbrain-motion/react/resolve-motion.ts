import { statusToMotion, type FullMotionId } from './status-map';

/** Case-, accent-, punctuation-, and trailing-ellipsis-insensitive. */
export function normalizeStatus(value: string): string {
  return value
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

const lookup = new Map<string, FullMotionId>(
  Object.entries(statusToMotion).map(([word, motion]) => [normalizeStatus(word), motion]),
);

/** Unknown/new words have an intentional, calm fallback. Extend status-map.ts as needed. */
export function resolveMotion(word: string, fallback: FullMotionId = 'think'): FullMotionId {
  return lookup.get(normalizeStatus(word)) ?? fallback;
}

/** Static-SVG integration: copy svg/ into public/oddbrain/, no React renderer required. */
export function motionSrc(word: string, basePath = '/oddbrain'): string {
  return `${basePath.replace(/\/$/, '')}/${resolveMotion(word)}.svg`;
}
