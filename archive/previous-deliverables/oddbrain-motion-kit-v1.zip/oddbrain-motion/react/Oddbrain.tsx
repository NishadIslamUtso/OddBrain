'use client';

import { useId, useMemo, type CSSProperties } from 'react';
import { motionSvg, type MotionId } from './motion-data';
import { resolveMotion } from './resolve-motion';
import './Oddbrain.css';

export type OddbrainProps = {
  /** Any of the 187 words; unknown words fall back to calm thought. */
  word?: string;
  /** An explicit motion overrides the word mapping. */
  motion?: MotionId;
  size?: CSSProperties['width'];
  /** 0.25–3; 1 is the designed timing. */
  speed?: number;
  paused?: boolean;
  /** Omit when paired with visible status text (decorative by default). */
  label?: string;
  /** Change this to restart the one-shot entrance. */
  replayKey?: string | number;
  className?: string;
  style?: CSSProperties;
};

type MotionStyle = CSSProperties & {
  '--duration-scale': number;
  '--play-state': 'paused' | 'running';
};

/** Inline trusted local SVG with per-instance IDs, scoped CSS, and no animation runtime. */
export function Oddbrain({
  word = 'Thinking',
  motion,
  size = 80,
  speed = 1,
  paused = false,
  label,
  replayKey = 0,
  className = '',
  style,
}: OddbrainProps) {
  const selected: MotionId = motion ?? resolveMotion(word);
  const instanceId = useId().replace(/[^a-zA-Z0-9_-]/g, '');
  const markup = useMemo(() => {
    const source = motionSvg[selected];
    const prefix = source.match(/<svg[^>]*\bid="([^"]+)"/)?.[1];
    if (!prefix) return '';
    // SVG defs, clipPaths, gradients, CSS selectors AND keyframes get unique IDs.
    // This prevents one mascot from hijacking another mascot's lenses or animation.
    return source
      .replaceAll(prefix, `ob-${instanceId}-${selected}`)
      .replace('role="img"', 'aria-hidden="true" focusable="false"')
      .replace(/ aria-labelledby="[^"]*"/, '');
  }, [selected, instanceId]);

  const safeSpeed = Number.isFinite(speed) ? Math.min(3, Math.max(0.25, speed)) : 1;
  const css: MotionStyle = {
    width: size,
    height: size,
    '--duration-scale': 1 / safeSpeed,
    '--play-state': paused ? 'paused' : 'running',
    ...style,
  };

  return (
    <span
      key={`${selected}-${replayKey}`}
      className={`oddbrain ${className}`.trim()}
      style={css}
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      // Only generated, checked-in SVG is inserted; never interpolate user HTML here.
      dangerouslySetInnerHTML={{ __html: markup }}
    />
  );
}

export function OddbrainLoader({
  size = 32,
  label = 'Loading',
  ...props
}: Omit<OddbrainProps, 'motion' | 'word'>) {
  return <Oddbrain {...props} motion="loader-eye-roll" size={size} label={label} />;
}

export type { MotionId } from './motion-data';
export { resolveMotion, motionSrc } from './resolve-motion';
