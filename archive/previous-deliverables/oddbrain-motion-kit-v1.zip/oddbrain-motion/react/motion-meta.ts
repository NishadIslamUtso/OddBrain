// Generated motion metadata.
export const motions = [
  {
    "id": "idle",
    "index": 1,
    "name": "Quiet mischief",
    "category": "Thinking",
    "duration": 3.2,
    "loop": true,
    "energy": "low",
    "description": "An almost-innocent sway, a little heel tap, and a smug glasses nudge",
    "defaultWord": "Lollygagging",
    "words": [
      "Dilly-dallying",
      "Lollygagging",
      "Moseying"
    ],
    "file": "svg/idle.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "think",
    "index": 2,
    "name": "Deep-ish thought",
    "category": "Thinking",
    "duration": 2.8,
    "loop": true,
    "energy": "low",
    "description": "A hand to its temple, a patient head tilt, and a tiny wandering thought",
    "defaultWord": "Thinking",
    "words": [
      "Cerebrating",
      "Cogitating",
      "Considering",
      "Contemplating",
      "Deliberating",
      "Mulling",
      "Musing",
      "Philosophising",
      "Pondering",
      "Ruminating",
      "Thinking"
    ],
    "file": "svg/think.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "eye-roll",
    "index": 3,
    "name": "Buffering upstairs",
    "category": "Thinking",
    "duration": 1.5,
    "loop": true,
    "energy": "low",
    "description": "The glasses ride up, pupils orbit like two loading spinners, and a soft haze wobbles around the head",
    "defaultWord": "Befuddling",
    "words": [
      "Befuddling",
      "Discombobulating",
      "Flummoxing",
      "Puzzling"
    ],
    "file": "svg/eye-roll.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "compute",
    "index": 4,
    "name": "Number crunch",
    "category": "Thinking",
    "duration": 2.2,
    "loop": true,
    "energy": "medium",
    "description": "Taps a floating calculator while its cells tick through a calculation",
    "defaultWord": "Calculating",
    "words": [
      "Calculating",
      "Computing",
      "Crunching",
      "Deciphering",
      "Determining",
      "Hashing",
      "Inferring",
      "Processing"
    ],
    "file": "svg/compute.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "type",
    "index": 5,
    "name": "Tiny power user",
    "category": "Making",
    "duration": 1.2,
    "loop": true,
    "energy": "medium",
    "description": "Alternating hands peck at a tiny floating keyboard while code lines pulse",
    "defaultWord": "Working",
    "words": [
      "Accomplishing",
      "Actioning",
      "Bootstrapping",
      "Clauding",
      "Doing",
      "Effecting",
      "Gitifying",
      "Working"
    ],
    "file": "svg/type.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "sketch",
    "index": 6,
    "name": "Doodle mode",
    "category": "Making",
    "duration": 2.8,
    "loop": true,
    "energy": "medium",
    "description": "Scratches a looping doodle with an oversized pencil, stopping to admire absolutely nothing",
    "defaultWord": "Doodling",
    "words": [
      "Creating",
      "Doodling",
      "Embellishing",
      "Sketching"
    ],
    "file": "svg/sketch.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "read",
    "index": 7,
    "name": "Very important news",
    "category": "Thinking",
    "duration": 3.4,
    "loop": true,
    "energy": "low",
    "description": "Peers over a tiny newspaper and flips the middle page with unjustified seriousness",
    "defaultWord": "Perusing",
    "words": [
      "Newspapering",
      "Perusing"
    ],
    "file": "svg/read.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "architect",
    "index": 8,
    "name": "Questionable architecture",
    "category": "Making",
    "duration": 3.2,
    "loop": true,
    "energy": "medium",
    "description": "Places three floating blocks into an improbably tidy little tower",
    "defaultWord": "Architecting",
    "words": [
      "Architecting",
      "Choreographing",
      "Composing",
      "Orchestrating",
      "Reticulating"
    ],
    "file": "svg/architect.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "idea",
    "index": 9,
    "name": "A suspiciously good idea",
    "category": "Thinking",
    "duration": 2.6,
    "loop": true,
    "energy": "low",
    "description": "A small lightbulb pops above a cheeky head tilt and turns on",
    "defaultWord": "Ideating",
    "words": [
      "Actualizing",
      "Elucidating",
      "Envisioning",
      "Generating",
      "Ideating",
      "Imagining",
      "Manifesting"
    ],
    "file": "svg/idea.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "stir",
    "index": 10,
    "name": "Let it cook",
    "category": "Cooking",
    "duration": 2.4,
    "loop": true,
    "energy": "medium",
    "description": "Stirs a round little pot with a wooden spoon while three wisps of steam curl upward",
    "defaultWord": "Brewing",
    "words": [
      "Brewing",
      "Concocting",
      "Cooking",
      "Fermenting",
      "Infusing",
      "Marinating",
      "Noodling",
      "Percolating",
      "Simmering",
      "Stewing"
    ],
    "file": "svg/stir.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "whisk",
    "index": 11,
    "name": "Aggressively delicious",
    "category": "Cooking",
    "duration": 0.8,
    "loop": true,
    "energy": "high",
    "description": "Whisks a bowl with overconfident wrist flicks as little ingredient flecks fly",
    "defaultWord": "Whisking",
    "words": [
      "Drizzling",
      "Flambéing",
      "Garnishing",
      "Julienning",
      "Sautéing",
      "Seasoning",
      "Whisking",
      "Zesting"
    ],
    "file": "svg/whisk.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "bake",
    "index": 12,
    "name": "Proof of genius",
    "category": "Cooking",
    "duration": 2.8,
    "loop": true,
    "energy": "medium",
    "description": "Gently kneads an absurdly proud little bun; it squashes, proofs, and puffs back up",
    "defaultWord": "Baking",
    "words": [
      "Baking",
      "Blanching",
      "Bunning",
      "Caramelizing",
      "Frosting",
      "Kneading",
      "Leavening",
      "Proofing"
    ],
    "file": "svg/bake.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "shimmy",
    "index": 13,
    "name": "The extremely unnecessary shimmy",
    "category": "Dancing",
    "duration": 1.2,
    "loop": true,
    "energy": "high",
    "description": "A shoulder shimmy, pigeon-toed kicks, and sunglasses that arrive half a beat late",
    "defaultWord": "Shimmying",
    "words": [
      "Beboppin'",
      "Boogieing",
      "Grooving",
      "Harmonizing",
      "Jitterbugging",
      "Shimmying",
      "Vibing"
    ],
    "file": "svg/shimmy.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "wiggle",
    "index": 14,
    "name": "Certified cheek wobble",
    "category": "Dancing",
    "duration": 1.6,
    "loop": true,
    "energy": "high",
    "description": "The two brain cheeks wobble independently, with floppy arms and a deeply undignified hip wiggle",
    "defaultWord": "Wibbling",
    "words": [
      "Slithering",
      "Smooshing",
      "Twisting",
      "Undulating",
      "Wibbling"
    ],
    "file": "svg/wiggle.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "moonwalk",
    "index": 15,
    "name": "Absolutely going nowhere",
    "category": "Dancing",
    "duration": 2.4,
    "loop": true,
    "energy": "medium",
    "description": "Alternates a toe-up shoe with a sliding shoe in a tiny in-place moonwalk",
    "defaultWord": "Moonwalking",
    "words": [
      "Moonwalking",
      "Sock-hopping"
    ],
    "file": "svg/moonwalk.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "chaos",
    "index": 16,
    "name": "No bones, no rules",
    "category": "Dancing",
    "duration": 1.6,
    "loop": true,
    "energy": "high",
    "description": "Squats, kicks, throws both arms up, and lands on completely the wrong beat",
    "defaultWord": "Tomfoolering",
    "words": [
      "Flibbertigibbeting",
      "Frolicking",
      "Gallivanting",
      "Hullaballooing",
      "Razzmatazzing",
      "Tomfoolering"
    ],
    "file": "svg/chaos.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "waddle",
    "index": 17,
    "name": "On a very small mission",
    "category": "Travel",
    "duration": 1.8,
    "loop": true,
    "energy": "medium",
    "description": "Takes tiny duck-footed steps, swaying its cheeks in the opposite direction",
    "defaultWord": "Waddling",
    "words": [
      "Meandering",
      "Perambulating",
      "Puttering",
      "Schlepping",
      "Waddling",
      "Wandering"
    ],
    "file": "svg/waddle.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "run",
    "index": 18,
    "name": "Late for absolutely nothing",
    "category": "Travel",
    "duration": 0.72,
    "loop": true,
    "energy": "high",
    "description": "A frantic in-place scamper with opposite arm and leg swings and little speed streaks",
    "defaultWord": "Scampering",
    "words": [
      "Galloping",
      "Herding",
      "Pouncing",
      "Scampering",
      "Scurrying",
      "Skedaddling",
      "Wrangling"
    ],
    "file": "svg/run.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "spin",
    "index": 19,
    "name": "One brain, zero bearings",
    "category": "Magic",
    "duration": 2.4,
    "loop": true,
    "energy": "medium",
    "description": "Turns around its vertical axis with a squashy edge-on moment and orbiting dots",
    "defaultWord": "Spinning",
    "words": [
      "Orbiting",
      "Quantumizing",
      "Spinning",
      "Swirling",
      "Whirlpooling",
      "Whirring"
    ],
    "file": "svg/spin.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "float",
    "index": 20,
    "name": "Zero-gravity daydream",
    "category": "Magic",
    "duration": 3.6,
    "loop": true,
    "energy": "low",
    "description": "Levitation with dangling feet, a slow roll, and a breathing shadow",
    "defaultWord": "Levitating",
    "words": [
      "Channeling",
      "Channelling",
      "Ebbing",
      "Flowing",
      "Levitating",
      "Osmosing",
      "Symbioting"
    ],
    "file": "svg/float.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "gust",
    "index": 21,
    "name": "A little winded",
    "category": "Magic",
    "duration": 2.4,
    "loop": true,
    "energy": "medium",
    "description": "Leans into a gust; cheeks and arms lag as three breezy strokes pass by",
    "defaultWord": "Gusting",
    "words": [
      "Billowing",
      "Cascading",
      "Fluttering",
      "Gusting",
      "Precipitating",
      "Thundering"
    ],
    "file": "svg/gust.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "grow",
    "index": 22,
    "name": "A thought takes root",
    "category": "Making",
    "duration": 3.6,
    "loop": true,
    "energy": "low",
    "description": "A tiny sprout unfolds out of the brain while the mascot carefully holds still",
    "defaultWord": "Sprouting",
    "words": [
      "Cultivating",
      "Germinating",
      "Hatching",
      "Incubating",
      "Nesting",
      "Photosynthesizing",
      "Pollinating",
      "Propagating",
      "Roosting",
      "Sprouting"
    ],
    "file": "svg/grow.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "forge",
    "index": 23,
    "name": "Tiny tinkerer",
    "category": "Making",
    "duration": 1.8,
    "loop": true,
    "energy": "medium",
    "description": "Winds up a little hammer and strikes an anvil, with two small impact sparks",
    "defaultWord": "Tinkering",
    "words": [
      "Boondoggling",
      "Crafting",
      "Forging",
      "Tempering",
      "Tinkering"
    ],
    "file": "svg/forge.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "transform",
    "index": 24,
    "name": "Getting it together",
    "category": "Magic",
    "duration": 3.2,
    "loop": true,
    "energy": "medium",
    "description": "The two cheeks separate, twist, and reform as little diamond pieces converge",
    "defaultWord": "Transmuting",
    "words": [
      "Coalescing",
      "Combobulating",
      "Crystallizing",
      "Forming",
      "Metamorphosing",
      "Nucleating",
      "Recombobulating",
      "Synthesizing",
      "Transfiguring",
      "Transmuting"
    ],
    "file": "svg/transform.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "dissolve",
    "index": 25,
    "name": "Slightly less corporeal",
    "category": "Magic",
    "duration": 3.2,
    "loop": true,
    "energy": "low",
    "description": "Becomes translucent as a few pink and purple bubbles drift upward, then condenses again",
    "defaultWord": "Nebulizing",
    "words": [
      "Evaporating",
      "Ionizing",
      "Misting",
      "Nebulizing",
      "Sublimating"
    ],
    "file": "svg/dissolve.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "sparkle",
    "index": 26,
    "name": "Unlicensed wizardry",
    "category": "Magic",
    "duration": 2.2,
    "loop": true,
    "energy": "medium",
    "description": "A little wrist flick sends four-pointed sparkles around the brain; no hat or outfit required",
    "defaultWord": "Enchanting",
    "words": [
      "Beaming",
      "Enchanting",
      "Prestidigitating",
      "Razzle-dazzling"
    ],
    "file": "svg/sparkle.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "boop",
    "index": 27,
    "name": "A highly professional boop",
    "category": "Mischief",
    "duration": 2,
    "loop": true,
    "energy": "medium",
    "description": "Leans forward for a playful boop, then recoils with a smug little bounce",
    "defaultWord": "Booping",
    "words": [
      "Booping",
      "Canoodling"
    ],
    "file": "svg/boop.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "juggle-shoes",
    "index": 28,
    "name": "Shoes are optional",
    "category": "Mischief",
    "duration": 2.8,
    "loop": true,
    "energy": "high",
    "description": "Juggles both purple shoes on staggered toss arcs while standing in socks",
    "defaultWord": "Fiddle-faddling",
    "words": [
      "Fiddle-faddling"
    ],
    "file": "svg/juggle-shoes.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "juggle-glasses",
    "index": 29,
    "name": "Optical nonsense",
    "category": "Mischief",
    "duration": 2.8,
    "loop": true,
    "energy": "high",
    "description": "Tosses its own sunglasses from hand to hand, with exposed eyes following the flight",
    "defaultWord": "Finagling",
    "words": [
      "Finagling",
      "Improvising"
    ],
    "file": "svg/juggle-glasses.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "juggle-body",
    "index": 30,
    "name": "Some assembly not required",
    "category": "Mischief",
    "duration": 2.4,
    "loop": true,
    "energy": "high",
    "description": "Tosses its own two brain cheeks in counterphase while its face hangs smugly in midair",
    "defaultWord": "Shenaniganing",
    "words": [
      "Shenaniganing"
    ],
    "file": "svg/juggle-body.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "assemble",
    "index": 31,
    "name": "Thrown together",
    "category": "Special",
    "duration": 2.8,
    "loop": false,
    "energy": "high",
    "description": "Brain cheeks, arms, legs, shoes, and sunglasses fly in from different directions and settle into the original mascot",
    "defaultWord": "Getting started",
    "words": [],
    "file": "svg/assemble.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "tunnel",
    "index": 32,
    "name": "Down the rabbit hole",
    "category": "Travel",
    "duration": 3.2,
    "loop": true,
    "energy": "medium",
    "description": "Ducks into a little hole, peeks out, and resurfaces with its dignity mostly intact",
    "defaultWord": "Burrowing",
    "words": [
      "Burrowing",
      "Spelunking"
    ],
    "file": "svg/tunnel.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "warp",
    "index": 33,
    "name": "Taking a shortcut",
    "category": "Travel",
    "duration": 2.4,
    "loop": true,
    "energy": "high",
    "description": "Crouches, zips diagonally through a soft portal, then re-enters from the opposite side",
    "defaultWord": "Hyperspacing",
    "words": [
      "Catapulting",
      "Hyperspacing",
      "Swooping",
      "Warping",
      "Zigzagging"
    ],
    "file": "svg/warp.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "unwind",
    "index": 34,
    "name": "Untangling the situation",
    "category": "Making",
    "duration": 3,
    "loop": true,
    "energy": "medium",
    "description": "Pulls a looping ribbon between its hands, unravels it, then winds it back",
    "defaultWord": "Unravelling",
    "words": [
      "Churning",
      "Mustering",
      "Unfurling",
      "Unravelling"
    ],
    "file": "svg/unwind.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "talk",
    "index": 35,
    "name": "Making a very good point",
    "category": "Mischief",
    "duration": 2.4,
    "loop": true,
    "energy": "medium",
    "description": "Babbling mouth shapes, an opinionated hand gesture, and three tiny speech dots",
    "defaultWord": "Bloviating",
    "words": [
      "Bloviating",
      "Gesticulating",
      "Honking",
      "Pontificating",
      "Whatchamacalliting"
    ],
    "file": "svg/talk.svg",
    "viewBox": "0 0 740 740"
  },
  {
    "id": "topsy",
    "index": 36,
    "name": "Head over heels",
    "category": "Mischief",
    "duration": 3.2,
    "loop": true,
    "energy": "high",
    "description": "A slow upside-down cartwheel with dangling limbs and a very late glasses wobble",
    "defaultWord": "Topsy-turvying",
    "words": [
      "Topsy-turvying"
    ],
    "file": "svg/topsy.svg",
    "viewBox": "0 0 740 740"
  }
] as const;
