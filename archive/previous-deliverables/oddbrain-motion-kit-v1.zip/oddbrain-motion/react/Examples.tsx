'use client';

import { useState } from 'react';
import { Oddbrain, OddbrainLoader, motionSrc } from './Oddbrain';

export function ChatStatus({ word = 'Brewing' }: { word?: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <Oddbrain word={word} size={72} />
      {/* The picture is decorative; the adjacent text carries the status. */}
      <span role="status" aria-live="polite">{word}…</span>
    </div>
  );
}

export function CompactStatus() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <OddbrainLoader size={32} label="" />
      <span role="status">Befuddling…</span>
    </div>
  );
}

export function Welcome() {
  const [replay, setReplay] = useState(0);
  return (
    <section>
      <Oddbrain motion="assemble" size={260} replayKey={replay} label="A brain mascot assembling itself" />
      <button onClick={() => setReplay(n => n + 1)}>Replay entrance</button>
    </section>
  );
}

export function LightweightStatus({ word }: { word: string }) {
  // For this version, copy svg/*.svg to public/oddbrain/.
  // Import motionSrc from './resolve-motion' directly to avoid bundling SVG markup.
  return <img src={motionSrc(word)} width={72} height={72} alt="" />;
}
