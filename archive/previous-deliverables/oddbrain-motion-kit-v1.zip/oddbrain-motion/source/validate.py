#!/usr/bin/env python3
"""Validate the shipped assets and registry; standard library only."""
from pathlib import Path
import json, re
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'manifest.json').read_text())
status_map=json.loads((root/'status-map.json').read_text())
assert manifest['motionCount']==36
assert manifest['statusCount']==len(status_map)==187
ids={m['id'] for m in manifest['motions']}
assert len(ids)==36
assert sum(not m['loop'] for m in manifest['motions'])==1
assert next(m for m in manifest['motions'] if not m['loop'])['id']=='assemble'
assert set(status_map.values())==ids-{'assemble'}
for m in manifest['motions']:
    assert set(m['words'])=={word for word,slug in status_map.items() if slug==m['id']}

files=list((root/'svg').glob('*.svg'))
assert len(files)==37
animations=0
for file in files:
    text=file.read_text()
    doc=ET.fromstring(text)
    local_ids=[e.get('id') for e in doc.iter() if e.get('id')]
    assert len(local_ids)==len(set(local_ids)), f'Duplicate IDs: {file.name}'
    for ref in re.findall(r'(?:href="#|url\(#)([a-zA-Z0-9_-]+)',text):
        assert ref in local_ids, f'Broken reference {ref} in {file.name}'
    assert 'prefers-reduced-motion' in text
    assert '<script' not in text and '<image' not in text
    assert not re.search(r'(?:href|src)="https?://',text)
    assert '<style>' in text and '@keyframes' in text
    animations+=text.count('@keyframes')
assert '__MOTION_TABLE__' not in (root/'README.md').read_text()
assert '__DATA__</script>' not in (root/'index.html').read_text()
print(f'PASS: {len(files)} valid standalone SVGs, {animations} scoped keyframe sequences, {len(status_map)} exact status mappings, no broken references or external assets.')
