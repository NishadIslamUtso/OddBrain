#!/usr/bin/env python3
"""Embed all local assets into a single offline gallery. No third-party modules."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent.parent
D=json.loads((ROOT/'source/gallery-data.json').read_text())
readme=ROOT/'README.md'
text=readme.read_text()
table='| # | Motion ID | Name | Category | Main beat | Status words |\n|---|---|---|---|---|---|\n'+'\n'.join(f'| {m["index"]:02} | `{m["id"]}` | {m["name"]} | {m["category"]} | {m["duration"]:g}s'+(' once' if not m['loop'] else '')+f' | {len(m["words"])} |' for m in D['motions'])
if '__MOTION_TABLE__' in text:
    readme.write_text(text.replace('__MOTION_TABLE__',table))
files={}
for file in [ROOT/'README.md',*sorted((ROOT/'react').glob('*')),*sorted((ROOT/'source').glob('*'))]:
    if file.is_file() and file.name not in ['gallery-data.json']:
        files[str(file.relative_to(ROOT))]=file.read_text()
D['downloadFiles']=files
payload=json.dumps(D,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
template=(ROOT/'source/gallery.template.html').read_text()
assert template.count('__DATA__')==1
(ROOT/'index.html').write_text(template.replace('__DATA__',payload))
print(f'Offline gallery built: {(ROOT/"index.html").stat().st_size:,} bytes; {len(files)} editable/integration files embedded for download.')
