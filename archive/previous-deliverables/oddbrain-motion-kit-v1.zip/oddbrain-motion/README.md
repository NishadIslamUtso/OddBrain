# Oddbrain Motion Kit

Your supplied pink butt-brain mascot, animated as an editable, reusable character system. “Oddbrain” is just a working label for the kit; rename it to suit your app.

**36 full-character motions + 1 compact loader · all 187 supplied status words mapped · no animation runtime**

## Start here

Open **index.html** in a modern browser. It is self-contained: no server, network, fonts, CDNs, or install required.

- Preview, pause, replay, change speed, and check cream/dark/transparent backgrounds.
- Search by a motion name **or any of the 187 words**.
- Select a word to see its shared motion.
- Export a single SVG, copy its source, or download the pack.
- The complete word registry is also visible at the bottom of the gallery.

The motion language is mischievous physical comedy: delayed glasses, tiny pigeon-toed steps, independently wobbling cheeks, overconfident hand gestures, and off-beat dances. It keeps your actual character, not another character's design or costume.

## The requested extras

| Moment | SVG | Behavior |
|---|---|---|
| Weird dancing | `shimmy.svg`, `wiggle.svg`, `chaos.svg`, `moonwalk.svg` | Independent arm, leg, cheek, and glasses motion—not simply rotating the entire logo. |
| Shoe juggling | `juggle-shoes.svg` | Purple shoes follow staggered toss arcs; socks stay on the legs. |
| Glasses juggling | `juggle-glasses.svg` | Spectacles tumble between hands while uncovered pupils follow them. |
| Body-part juggling | `juggle-body.svg` | The two brain cheeks are tossed in counterphase around a floating smug face. |
| Starting-page entrance | `assemble.svg` | Cheeks, arms, legs, shoes, then glasses fly in. Plays **once in 2.8 seconds**, settles, and stays assembled. |
| Confused, hazy loading | `eye-roll.svg` | Glasses lift, pupils orbit like spinners, and a soft haze wobbles. |
| Actual small loading icon | `loader-eye-roll.svg` | Simplified 96×96 vector, intended for **24–64px** display. |

The full character is most readable at **80px and up**; prop-heavy scenes benefit from 120px+. Use the compact loader rather than shrinking every brain wrinkle into a 24px icon.

## What's in the kit

```
index.html                 Self-contained interactive gallery
svg/                       36 character SVGs + compact loader
status-map.json            Your 187 exact words → motion ID
manifest.json              Motion names, timing, categories, descriptions, mapped words
react/
  Oddbrain.tsx             Inline React/TypeScript component
  Oddbrain.css             Sizing and accessibility styles
  motion-data.ts           Generated trusted SVG markup
  status-map.ts            Lightweight typed word registry
  resolve-motion.ts        Normalization, fallback, static asset URL helper
  motion-meta.ts           Typed motion metadata
  Examples.tsx             Chat status, loader, entrance, and image examples
source/
  original-mascot.svg       Your supplied source, preserved
  build.py                 Editable rig, props, keyframes, and mappings
  gallery.template.html    Editable gallery source
  build_gallery.py         Rebuilds the offline gallery
```

## Framework-agnostic use

Copy `svg/` to your app's public directory, e.g. `public/oddbrain/`:

```html
<img src="/oddbrain/think.svg" width="80" height="80" alt="" />
<span role="status">Thinking…</span>

<!-- The compact loading icon -->
<img src="/oddbrain/loader-eye-roll.svg" width="32" height="32" alt="Loading" />

<!-- A one-shot entrance. Re-create the <img> to replay it. -->
<img src="/oddbrain/assemble.svg" width="260" height="260"
     alt="A brain mascot assembling itself" />
```

Each SVG contains its own CSS animation, vector paths, gradients, and reduced-motion rules. It works as an external `<img>` without JavaScript. Set an external image's size with width/height or normal CSS. Do not convert the SVG into a PNG if you want it to animate.

For word-driven URLs, use `status-map.json` or import **only** `motionSrc` from `react/resolve-motion.ts`:

```tsx
import { motionSrc } from './oddbrain/resolve-motion';

<img src={motionSrc('Brewing')} width={80} height={80} alt="" />
// /oddbrain/stir.svg
```

This lightweight path does not bundle all the SVG strings. Serve the SVG assets separately.

## React / TypeScript

Copy `react/` into your app. React 18+ is the only assumed UI dependency; no GSAP, Lottie, Framer Motion, or timer loop is needed. The included source was type-checked and rendered in a browser as part of QA.

```tsx
import { Oddbrain, OddbrainLoader } from './oddbrain/Oddbrain';

<Oddbrain word="Brewing" size={80} />
<Oddbrain word="Ruminating" size={80} speed={0.75} />
<Oddbrain motion="juggle-shoes" size={180} />
<Oddbrain motion="chaos" size={160} paused={false} />
<OddbrainLoader size={32} label="Loading" />
<Oddbrain motion="assemble" size={260} replayKey={0} />
```

Changing `replayKey` remounts the SVG and restarts a one-shot animation. See `Examples.tsx` for a replay button. Changing `word` within the same shared motion does not unnecessarily restart the animation.

The component re-prefixes **all IDs, gradient references, clip paths, CSS selectors, and keyframe names** per instance. Multiple mascots can safely coexist. If you manually paste the same SVG inline twice, give each copy a different ID prefix too. External `<img>` instances are already isolated.

### Accessibility

- Every SVG honors `prefers-reduced-motion: reduce`, becoming a useful static pose. The assembly entrance is fully assembled in this mode, not left off screen.
- `Oddbrain` is decorative by default. Pair it with visible status text; add `label` when the image needs its own accessible description.
- Do not announce every whimsical word repeatedly. Put meaningful task progress in a separate `role="status"` region.
- The compact loader defaults to the accessible label “Loading”. Pass `label=""` when adjacent visible text already supplies it.

### Inline timing controls

For trusted inline SVG (including the React component), these CSS variables are available on the SVG or an ancestor:

```css
.my-mascot {
  --duration-scale: 1.5;  /* 1.5× the duration = slower */
  --play-state: paused;  /* running | paused */
}
```

CSS variables do **not** cross into an external `<img>`. Use the inline component for dynamic speed/pause controls. Each exported file otherwise runs at its designed timing. The gallery's SVG export bakes in the chosen speed.

## Word reuse and extension

The 187 words map to **35 looping character motions**; the one-shot assembly is intentionally reserved for startup. Examples:

- `Thinking`, `Cogitating`, `Considering`, `Contemplating`, `Pondering` → `think`
- `Calculating`, `Computing`, `Hashing`, `Processing` → `compute`
- `Brewing`, `Concocting`, `Percolating`, `Simmering` → `stir`
- `Beboppin'`, `Boogieing`, `Grooving`, `Shimmying`, `Vibing` → `shimmy`
- `Befuddling`, `Discombobulating`, `Flummoxing`, `Puzzling` → `eye-roll`

Mappings are semantic groups, not literal illustrations of every verb: e.g. cooking words can share a whisk or pot. You can freely reassign any word.

`resolveMotion()` ignores capitalization, accents, punctuation, and trailing ellipses. For example, `Sautéing…` and `sauteing` select the same loop. An unknown word safely returns `think`, not a random high-energy action.

To add more words in an app, extend `react/status-map.ts` (or your copy of `status-map.json`). To change the generated source of truth, edit `WORDS` and `ASSIGNMENTS` in `source/build.py` and update its expected word-count assertion. Rebuilding overwrites generated mappings and markup, not your original source SVG.

## Editing and rebuilding

All artwork is vector: no raster textures, image generation, base64 pictures, or external assets. The original silhouette, pink palette, brain wrinkles, smirk, sunglasses, and purple shoes are preserved. Props and compact-loader artwork are newly drawn SVG paths.

In `source/build.py`, every clip has independently editable layers (`rig-head`, arms, legs, shoes, glasses, cheeks), a few keyframes, and optional props. Artwork is shared inside each file via `<defs>` / `<use>`. ViewBoxes are `0 0 740 740` for the full character and `0 0 96 96` for the compact loader.

```sh
python source/build.py
python source/build_gallery.py
```

Only the Python standard library is needed to rebuild. The offline gallery bundles the generated SVGs and integration files, so there are no resource-fetching dependencies. The archive supplied alongside this gallery also contains the editable generator and original SVG.

**CSP note:** the inline React component uses trusted checked-in SVG markup with embedded styles. If your app has a strict `style-src` policy, use the external `<img>` approach or adapt the embedded styles to your CSP rather than allowing untrusted HTML.

## Motion index

The table below is generated with the kit. “Duration” is the main beat; individual hands, particles, and secondary motions can have staggered or shorter beats.

| # | Motion ID | Name | Category | Main beat | Status words |
|---|---|---|---|---|---|
| 01 | `idle` | Quiet mischief | Thinking | 3.2s | 3 |
| 02 | `think` | Deep-ish thought | Thinking | 2.8s | 11 |
| 03 | `eye-roll` | Buffering upstairs | Thinking | 1.5s | 4 |
| 04 | `compute` | Number crunch | Thinking | 2.2s | 8 |
| 05 | `type` | Tiny power user | Making | 1.2s | 8 |
| 06 | `sketch` | Doodle mode | Making | 2.8s | 4 |
| 07 | `read` | Very important news | Thinking | 3.4s | 2 |
| 08 | `architect` | Questionable architecture | Making | 3.2s | 5 |
| 09 | `idea` | A suspiciously good idea | Thinking | 2.6s | 7 |
| 10 | `stir` | Let it cook | Cooking | 2.4s | 10 |
| 11 | `whisk` | Aggressively delicious | Cooking | 0.8s | 8 |
| 12 | `bake` | Proof of genius | Cooking | 2.8s | 8 |
| 13 | `shimmy` | The extremely unnecessary shimmy | Dancing | 1.2s | 7 |
| 14 | `wiggle` | Certified cheek wobble | Dancing | 1.6s | 5 |
| 15 | `moonwalk` | Absolutely going nowhere | Dancing | 2.4s | 2 |
| 16 | `chaos` | No bones, no rules | Dancing | 1.6s | 6 |
| 17 | `waddle` | On a very small mission | Travel | 1.8s | 6 |
| 18 | `run` | Late for absolutely nothing | Travel | 0.72s | 7 |
| 19 | `spin` | One brain, zero bearings | Magic | 2.4s | 6 |
| 20 | `float` | Zero-gravity daydream | Magic | 3.6s | 7 |
| 21 | `gust` | A little winded | Magic | 2.4s | 6 |
| 22 | `grow` | A thought takes root | Making | 3.6s | 10 |
| 23 | `forge` | Tiny tinkerer | Making | 1.8s | 5 |
| 24 | `transform` | Getting it together | Magic | 3.2s | 10 |
| 25 | `dissolve` | Slightly less corporeal | Magic | 3.2s | 5 |
| 26 | `sparkle` | Unlicensed wizardry | Magic | 2.2s | 4 |
| 27 | `boop` | A highly professional boop | Mischief | 2s | 2 |
| 28 | `juggle-shoes` | Shoes are optional | Mischief | 2.8s | 1 |
| 29 | `juggle-glasses` | Optical nonsense | Mischief | 2.8s | 2 |
| 30 | `juggle-body` | Some assembly not required | Mischief | 2.4s | 1 |
| 31 | `assemble` | Thrown together | Special | 2.8s once | 0 |
| 32 | `tunnel` | Down the rabbit hole | Travel | 3.2s | 2 |
| 33 | `warp` | Taking a shortcut | Travel | 2.4s | 5 |
| 34 | `unwind` | Untangling the situation | Making | 3s | 4 |
| 35 | `talk` | Making a very good point | Mischief | 2.4s | 5 |
| 36 | `topsy` | Head over heels | Mischief | 3.2s | 1 |
