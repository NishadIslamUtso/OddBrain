# Reference review — keep the premise, redraw the performance

## Scope

Reviewed the three supplied HTML libraries and the pasted sleepy-mochi SVG. The HTML references were inspected statically and rendered in an isolated browser with network requests blocked and injected third-party scripts removed.

This review uses the references as **premise/choreography input**, not as an asset or code source. The production builder does not read the uploaded HTML or extracted reference SVGs. It reads only the user's original mascot and our own editable motion definitions.

## What was worth keeping

| Reference | Useful premise | Our reconstruction |
|---|---|---|
| Pasted mochi SVG | Weighty flattened sleep; kicked-off shoes; expanding sleep bubble | `mochi-melt`: low original brain silhouette, closed lids, forehead shades, clearly separated shoes, pearl-lilac face-attached bubble |
| 17-scene HTML, `index (1).html` | Conducting music | `maestro`: a baton following the actual shoulder/hand transform and three off-beat notes |
| 17-scene HTML + 79-loop library | Personal raincloud + umbrella | `rain-check`: an umbrella too small to protect both cheeks, with quiet rain on the exposed side |
| 14-clip HTML, `index.html` | Magnifier inspection | `lens-inspector`: original uncovered eyes, one clipped enlarged eye, a real handle grip and a temple scratch |
| 14-clip HTML | Belly laughter | `belly-laugh`: cheeks squash independently, arms close inward, shades lag, mouth genuinely opens |
| 14-clip HTML | A short sunglasses-drop confidence cue | `shades-drop`: intact mascot, brief completion timing, final smug hold; not another startup assembly |
| 17-scene HTML | Head sprout / flower with a bee | `bee-bloom`: a tiny flower in the cleft and an authored landing/departure arc, with a failed polite shoo |
| 79-loop HTML, `butt-brain-animations.html` | Lasso / herding | `shoe-lasso`: catches its own escaping shoe; a sampled rope connects hand and moving loop |
| 79-loop HTML | Branching / Gitifying | `branch-merge`: cream card with two drawn routes that reunite; no product mark |
| 79-loop HTML | Wrench / tinkering | `hinge-tune`: repairs its own sunglasses hinge instead of waving an unrelated tool |
| 79-loop HTML | Frost / snow | `snow-shiver`: quiet flakes, self-warming arms and chattering teeth; the brain stays pink |
| 79-loop HTML | Pan / sauté / flambé | `pan-flip`: golden pancake toss-and-catch, held pan, tiny warm flame |
| 14-clip HTML | Crossed-leg meditation | `lotus-float`: original shoes folded into newly drawn crossed legs, closed lids, thin breathing ripple |
| 79-loop HTML | Megaphone / announcement | `megaphone`: one little horn, hand grip, quiet vector sound arcs and an over-serious speaking rhythm |
| 79-loop HTML | Hearts | `self-hug`: a physical squeeze first, then one small heart; not just a heart-particle overlay |
| 79-loop HTML | Spelunking / lamp | `flashlight-search`: a hand-held lamp and transparent warm cone moving as one object, eyes tracking the beam |

## What we deliberately left behind

- **Costumes and character redesigns:** no chef hat, cap, cape, superhero outfit, detective outfit or helmet. No borrowed face, newly simplified brain silhouette or alternate shoe style.
- **Off-theme spectacle:** no electric-blue sleep bubble, neon aura, glowing eye treatment, opaque scenic backdrop or full-screen flash.
- **Already-covered premises:** more generic sways, walks, spins, panic, assembly, juggling and stirring did not justify near-duplicates of the existing sixty scenes.
- **Particle-only variants:** a new colour or decorative symbol over the same bounce is not a new physical-comedy scene.
- **Reference implementations:** no source SVG geometry, animation tables, SMIL timelines, CSS keyframes, scripts or HTML UI were transplanted.

## Technical issues avoided

### Repeated inline SVG IDs

The 14-clip page inserts the same raw SVG into its gallery, stage and mini preview without per-instance namespacing. In the sanitized default page, the browser reported **413 elements with IDs but only 172 unique ID values**. This makes shared gradients and clip paths vulnerable to resolving against the wrong instance. A static scan of inline markup alone misses the issue because the SVGs initially live inside JSON strings.

Our standalone files scope IDs and keyframes to the clip; the gallery and React component then re-prefix every inline instance. The new magnifier's custom clip path uses the same mechanism.

### Reduced-motion and timing

The 17-scene reference relies heavily on SMIL and has no reduced-motion media handling. The 79-loop library also combines multiple transform behaviours on some of the same parts, which needs careful composition rather than blind stacking.

This kit retains its CSS-based rig with deliberate parent/child transforms, useful reduced-motion stills, inherited speed and true pause controls. No reference timing tables were reused.

### The pasted mochi staging

The promising premise was stronger than its implementation: the shoe transforms can move the shoes outside the 740-square canvas; the bubble is not coupled to the body's breathing; the bright-blue glow breaks the existing visual language; and the squash does not sell a truly heavy floor pose.

The replacement changes the staging, not just the colour. It flattens the actual brain, redraws resting arms, compresses the unused legs, places both original shoes safely apart, uses closed lids and raised shades, and couples the pearl bubble's attachment point to the face's breathing.

### Extraneous uploaded scripts

The uploaded HTML contains injected Cloudflare challenge scripts; the 79-loop file additionally loads analytics. Those were excluded from the isolated review. No such code, remote asset or request is part of the production motion kit.

## Compatibility boundary

Volume 03 is additive:

- All **61 existing V2 SVG files** are checked against their saved SHA-256 digests and remain byte-identical.
- All **259 existing defaults** are preserved.
- Existing alternate-take arrays remain exact prefixes of the expanded arrays, so every prior variant index keeps its meaning.
- **45 words** are added, three per new loop.
- `shades-drop` is an explicit one-shot and is excluded from all word pools.
- The original V1 compatibility checks remain in place. The only historical V1 SVG source difference is the already-documented V2 pause-specificity fix.

The result is **76 character scenes: 74 loops, two one-shots, plus the compact eye-roll loader**, all in one consistent mascot system.
