#!/usr/bin/env python3
"""Validate all three volumes, scoped SVGs, word pools, and V1/V2 compatibility."""
from pathlib import Path
import json, re, hashlib
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'manifest.json').read_text())
status_map=json.loads((root/'status-map.json').read_text())
original=json.loads((root/'status-map-original.json').read_text())
variants=json.loads((root/'status-variants.json').read_text())
v1=json.loads((root/'source/v1-baseline.json').read_text())
v2=json.loads((root/'source/v2-baseline.json').read_text())
assert manifest['version']=='3.0.0'
assert manifest['latestVolume']==3
assert manifest['motionCount']==76
assert manifest['newMotionCount']==16
assert manifest['statusCount']==len(status_map)==304
assert manifest['originalStatusCount']==len(original)==187
assert manifest['additionalStatusCount']==len(status_map)-len(original)==117
assert manifest['newStatusCount']==len(status_map)-len(v2['statusMap'])==45
assert original==v1['statusMap']
assert all(status_map[word]==motion for word,motion in v2['statusMap'].items())
ids={m['id'] for m in manifest['motions']}
one_shots={m['id'] for m in manifest['motions'] if not m['loop']}
assert len(ids)==76
assert {str(v):sum(m['volume']==v for m in manifest['motions']) for v in (1,2,3)}==manifest['volumeCounts']=={'1':36,'2':24,'3':16}
assert one_shots=={'assemble','shades-drop'}
assert manifest['oneShotCount']==len(one_shots)==2
assert manifest['loopCount']==len(ids-one_shots)==74
assert set(status_map.values())==ids-one_shots
for m in manifest['motions']:
    assert set(m['words'])=={w for w,slug in status_map.items() if slug==m['id']}
    assert set(m['suggestedFor']).issubset(v2['statusMap'])
    if m['volume']==3:
        assert m['referenceIdea'] and m['rebuiltTwist']
        assert len(m['words'])==(3 if m['loop'] else 0)
assert set(variants)==set(status_map)
normalize=lambda s:__import__('unicodedata').normalize('NFKD',s).encode('ascii','ignore').decode().lower()
normalized=[re.sub(r'[^a-z0-9]','',normalize(w)) for w in status_map]
assert len(normalized)==len(set(normalized)), 'Word-normalization collision'
for word,pool in variants.items():
    assert pool and len(pool)==len(set(pool))
    assert pool[0]==status_map[word]
    assert set(pool).issubset(ids-one_shots)
for word,old_pool in v2['variantMap'].items():
    assert variants[word][:len(old_pool)]==old_pool, f'Previous variant indices changed: {word}'

files=list((root/'svg').glob('*.svg'))
assert len(files)==77
animations=0
all_ids=[]
for file in files:
    text=file.read_text()
    doc=ET.fromstring(text)
    local_ids=[e.get('id') for e in doc.iter() if e.get('id')]
    assert len(local_ids)==len(set(local_ids)), f'Duplicate IDs: {file.name}'
    prefix=doc.get('id')
    assert all(i==prefix or i.startswith(prefix+'-') for i in local_ids), file.name
    all_ids.extend(local_ids)
    for ref in re.findall(r'(?:href="#|url\(#)([a-zA-Z0-9_-]+)',text):
        assert ref in local_ids, f'Broken reference {ref} in {file.name}'
    for ref in (doc.get('aria-labelledby') or '').split():
        assert ref in local_ids
    names=re.findall(r'@keyframes\s+([\w-]+)',text)
    assert len(names)==len(set(names))
    assert all(n.startswith(prefix+'-') for n in names)
    assert 'prefers-reduced-motion' in text
    assert not re.search(r'<(?:script|image|text|animate|animateTransform|animateMotion)\b',text)
    assert not re.search(r'(?:href|src)="https?://',text)
    assert '<style>' in text and names
    if file.stem in ids and next(m for m in manifest['motions'] if m['id']==file.stem)['volume']==3:
        assert '<filter' not in text and 'feGaussianBlur' not in text
    animations+=len(names)
assert len(all_ids)==len(set(all_ids)), 'IDs collide across standalone assets'
for name,digest in v2['hashes'].items():
    actual=hashlib.sha256((root/'svg'/name).read_bytes()).hexdigest()
    assert actual==digest, f'V2 asset changed: {name}'
for name,digest in v1['hashes'].items():
    data=(root/'svg'/name).read_text()
    # The documented V2 pause-specificity fix is the only allowed V1 source change.
    data=data.replace('animation-play-state:var(--play-state,running)!important;', 'animation-play-state:var(--play-state,running);')
    assert hashlib.sha256(data.encode()).hexdigest()==digest, f'Original V1 art/keyframes changed: {name}'
assert '__MOTION_TABLE__' not in (root/'README.md').read_text()
assert '__DATA__</script>' not in (root/'index.html').read_text()
print(f'PASS: {len(files)} standalone SVGs, {animations} scoped sequences, {len(status_map)} words, opt-in variants.')
print('PASS: all 61 V2 SVGs are byte-identical; all 259 V2 defaults and every existing variant index are preserved.')
print('PASS: original V1 artwork/keyframes and all 187 original defaults remain intact (documented V2 pause-CSS fix only).')
