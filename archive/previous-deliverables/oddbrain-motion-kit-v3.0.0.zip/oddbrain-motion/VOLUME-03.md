# Volume 03 — The reference cut

**16 added scenes: 15 loops + 1 completion one-shot · 45 added words · 76 full-character motions + compact loader · 304 words total**

Good premises from the three supplied HTML libraries and the pasted mochi SVG, restaged in the existing Oddbrain rig. This is not a repaired or reskinned copy of those libraries. The supplied pink brain, wrinkle paths, matte-black sunglasses, black limbs, purple shoes and smug personality stay consistent. No costume is added.

The previous **61 SVG files are byte-for-byte unchanged**. Every one of the previous **259 default mappings** and every previous alternate-take index is preserved. New takes are appended, not inserted ahead of existing takes.

## The sixteen additions

| ID | New scene | Timing | Added words |
|---|---|---|---|
| `mochi-melt` | A genuinely flat sleepy floor pose, shoes resting apart, closed lids, attached pearl-lilac bubble | 4.8s loop | Mochifying, Melting, Dozing |
| `maestro` | Shoulder-linked baton conducts three cheeky notes | 2.8s loop | Conducting, Cueing, Syncopating |
| `rain-check` | Own raincloud; umbrella protects approximately one cheek | 3.6s loop | Dripping, Weathering, Sheltering |
| `lens-inspector` | Raised shades, one magnified eye, a baffled temple scratch | 3.6s loop | Inspecting, Examining, Investigating |
| `belly-laugh` | Soft cheek squash, hugging arms and a proper open laugh | 2.8s loop | Laughing, Chuckling, Snickering |
| `shades-drop` | Original sunglasses fall into place; a tiny lean, then a smug hold | **2.2s once** | None — explicit completion cue |
| `bee-bloom` | A flower sprouts from the cleft; a bee inspects it despite a polite shoo | 4.4s loop | Blooming, Buzzing, Cross-pollinating |
| `shoe-lasso` | One shoe escapes; a connected lasso catches and reels it back | 4.8s loop | Lassoing, Rounding-up, Retrieving |
| `branch-merge` | A little graph forks into two paths, then reunites | 3.6s loop | Branching, Merging, Reconciling |
| `hinge-tune` | Tightens its own sunglasses hinge with a small spanner | 3.2s loop | Adjusting, Tightening, Troubleshooting |
| `snow-shiver` | Pink stays pink: self-warming arms, quiet flakes, chattering teeth | 3.6s loop | Shivering, Chattering, Defrosting |
| `pan-flip` | A golden pancake actually leaves the pan and lands back in it | 3.2s loop | Flipping, Pan-tossing, Searing |
| `lotus-float` | Crossed original shoes, closed lids, quiet breathing ripple | 4.8s loop | Meditating, Centering, Attuning |
| `megaphone` | A very important announcement about absolutely nothing | 3.2s loop | Announcing, Amplifying, Broadcasting |
| `self-hug` | Long rubbery arms squeeze both cheeks; one small heart escapes | 3.6s loop | Hugging, Appreciating, Heartwarming |
| `flashlight-search` | Hand-held lamp and pale cone pivot together; uncovered eyes track it | 3.6s loop | Searching, Scanning, Illuminating |

## Why these are not duplicates

- `nap` remains the original upright bobbing nap. `mochi-melt` is a low, flattened, feet-off floor pose with a face-attached bubble.
- `float` remains the original standing levitation. `lotus-float` uses newly drawn crossed legs and the original detached shoes.
- The existing cooking loops stir, whisk and bake. `pan-flip` performs a timed toss-and-catch.
- `assemble` is still the thrown-pieces startup entrance. `shades-drop` starts with an intact character and is deliberately short enough for a task-complete moment.
- Hearts, musical notes and weather are used as responses to physical actions, not as a reason to add another generic bob with a different particle colour.

## Try the new scenes

The offline gallery starts with **New / 16**, and **Volume 02 / 24** remains a separate filter. **All / 76** includes every character motion. The curation note explains what was kept and discarded.

```tsx
import { Oddbrain } from './oddbrain/Oddbrain';

<Oddbrain motion="mochi-melt" size={180} />
<Oddbrain motion="maestro" size={160} />
<Oddbrain motion="shoe-lasso" size={180} />
<Oddbrain word="Inspecting" size={140} />

// Completion cue: plays once and holds. Change replayKey to replay.
<Oddbrain motion="shades-drop" size={180} replayKey={completedRequestId} />
```

Every new loop has three unique canonical words. Existing words can opt into appropriate new scenes through the variant helpers without changing their defaults:

```tsx
import { motionVariants, resolveMotionVariant } from './oddbrain/resolve-motion';

motionVariants('Orchestrating');
// ['architect', 'cheek-drums', 'maestro']

resolveMotionVariant('Orchestrating', 0); // 'architect' — unchanged
resolveMotionVariant('Orchestrating', 1); // 'cheek-drums' — previous take preserved
resolveMotionVariant('Orchestrating', 2); // 'maestro' — new opt-in take
```

`shades-drop` is intentionally absent from all word defaults and alternate-take pools. A thinking/loading word must never resolve to a one-shot that finishes and stops.

## Motion and implementation notes

- All new scenes are standalone, transparent, CSS-animated SVGs. No JavaScript runtime, SMIL, raster image, remote font or third-party script is required.
- Closed lids, magnified eyes, new props and new limb poses are drawn as ordinary editable vectors. The base mascot art is read from `source/original-mascot.svg`, not from the reference files.
- The mochi bubble has a separate breathing anchor coupled to the flattened face. Its growth does not disconnect it from the face; it releases only at the end of the pop.
- The lasso is sampled as eight rounded path segments. Its endpoint is derived from the transformed loop, rather than moving a disconnected decorative rope beside a shoe.
- The baton, umbrella, spanner and flashlight are staged around the real hand/shoulder anchors. The flashlight and its cone share one transform.
- Reduced-motion mode presents useful stills, including a readable branch graph and a few quiet snowflakes. One-shots show the completed character, not a half-built pose.
- Namespaced IDs and keyframes support multiple inline instances through the gallery and React component. Pause and speed controls apply to every layer.

Edit `source/volume3.py`, then run:

```bash
python source/build.py
python source/build_gallery.py
python source/validate.py
```

See **REFERENCE-REVIEW.md** for the curation decisions and reference implementation issues that were deliberately not carried forward.
