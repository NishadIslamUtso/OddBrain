#!/usr/bin/env python3
"""Build the editable, dependency-free Oddbrain SVG motion kit from the supplied mascot.
Run from any directory: python source/build.py
The gallery is built by source/build_gallery.py after this file.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
import json, re, html

ROOT = Path(__file__).resolve().parent.parent
ET.register_namespace('', 'http://www.w3.org/2000/svg')
NS = '{http://www.w3.org/2000/svg}'
original = ET.parse(ROOT / 'source/original-mascot.svg').getroot()

def element(id):
    return next(x for x in original.iter() if x.get('id') == id)

def xml(el):
    return ET.tostring(el, encoding='unicode').replace(' xmlns="http://www.w3.org/2000/svg"', '')

def inside(id):
    return ''.join(xml(x) for x in element(id))

ORIGINAL_DEFS = ''.join(xml(x) for x in original.find(NS + 'defs'))
BRAIN = inside('butt-shaped-brain')
GLASSES = xml(element('sunglasses'))
SMIRK = inside('smug-smirk')
LEFT_ARM, RIGHT_ARM = inside('near-arm'), inside('far-arm')
LEFT_SOCK = xml(list(element('left-shoe'))[0])
RIGHT_SOCK = xml(list(element('right-shoe'))[0])
LEFT_SHOE = ''.join(xml(x) for x in list(element('left-shoe'))[1:])
RIGHT_SHOE = ''.join(xml(x) for x in list(element('right-shoe'))[1:])

PINK = '#FF98A5'
PURPLE = '#8C6AA7'
INK = '#393A35'
CREAM = '#FFF9F1'
GREEN = '#9AAD8E'
YELLOW = '#EDC77E'


def star(x, y, r=16, color=PURPLE, cls=''):
    return f'<g class="{cls}"><path d="M{x} {y-r} Q{x+3} {y-3} {x+r} {y} Q{x+3} {y+3} {x} {y+r} Q{x-3} {y+3} {x-r} {y} Q{x-3} {y-3} {x} {y-r}Z" fill="{color}"/></g>'


def dot(x, y, r=6, color=PURPLE, cls=''):
    return f'<circle class="{cls}" cx="{x}" cy="{y}" r="{r}" fill="{color}"/>'


def steam():
    return '<g stroke="#8C6AA7" stroke-width="6" stroke-linecap="round" opacity=".55">' + ''.join(f'<path class="steam-{i}" d="M{x} 392 C{x-18} 377 {x+15} 366 {x} 349"/>' for i,x in enumerate([320,360,400])) + '</g>'


def notes():
    return '<g class="note-a" fill="#8C6AA7"><path d="M110 209 V163 L147 153 V197 H140 V165 L117 171 V209Z"/><ellipse cx="105" cy="209" rx="12" ry="9"/><ellipse cx="135" cy="200" rx="12" ry="9"/></g><g class="note-b" fill="#D5949E"><path d="M618 176 V132 L644 144 V155 L625 146 V176Z"/><ellipse cx="613" cy="176" rx="12" ry="9"/></g>'


class Clip:
    def __init__(self, slug, label, category, duration, description, word, energy='medium', loop=True, split=False, eyes=False):
        self.slug, self.label, self.category = slug, label, category
        self.duration, self.description, self.word = duration, description, word
        self.energy, self.loop, self.split, self.eyes = energy, loop, split, eyes
        self.css, self.animations = [], []
        self.back, self.front, self.head_extra = '', '', ''
        self.open_mouth = False
        # Optional Volume 02 layers; empty defaults preserve V1 artwork and keyframes.
        self.extra_defs = self.rig_back = self.rig_extra = ''
        self.detached_shoes = set()
        self.rig_clip = None
        self.mouth_markup = self.left_arm_markup = self.right_arm_markup = None
        self.index = 0

    def style(self, selector, css):
        self.css.append((selector, css))

    def anim(self, selector, duration, frames, ease='cubic-bezier(.45,0,.55,1)', delay=0, repeat=None):
        self.index += 1
        name = f'__P__-k{self.index}'
        repeat = ('infinite' if self.loop else '1') if repeat is None else repeat
        self.css.append((selector, f'animation:{name} calc({duration}s * var(--duration-scale,1)) {ease} calc({delay}s * var(--duration-scale,1)) {repeat} both;'))
        self.animations.append('@keyframes '+name+'{'+''.join(f'{time}{{{value}}}' for time,value in frames.items())+'}')
        # A useful still pose, not an off-screen assembly pose, for reduced motion.
        if self.loop and selector not in ['.rig-ground']:
            first = next(iter(frames.values()))
            self.css.insert(len(self.css)-1, (selector, first))

    def bounce(self, amount=8, duration=None):
        self.anim('.rig-root', duration or self.duration, {'0%,100%':'transform:translateY(0);','50%':f'transform:translateY({-amount}px);'})

    def steam(self):
        for i in range(3):
            self.anim(f'.steam-{i}', 1.8, {'0%':'transform:translateY(6px);opacity:0;','25%':'opacity:.7;','100%':'transform:translateY(-34px);opacity:0;'}, delay=-i*.6)

    def music(self):
        self.back += notes()
        self.anim('.note-a', 1.8, {'0%,100%':'transform:translateY(6px) rotate(-5deg);opacity:.4;','50%':'transform:translateY(-12px) rotate(5deg);opacity:1;'})
        self.anim('.note-b', 1.8, {'0%,100%':'transform:translateY(-12px) rotate(4deg);opacity:1;','50%':'transform:translateY(6px) rotate(-4deg);opacity:.4;'})
        self.style('.note-a','transform-origin:120px 180px;')
        self.style('.note-b','transform-origin:630px 160px;')

    def render(self):
        p = 'ob-' + self.slug
        defs = ORIGINAL_DEFS + f'<g id="brain-art">{BRAIN}</g><g id="glasses-art">{GLASSES}</g><g id="shoe-left-art">{LEFT_SHOE}</g><g id="shoe-right-art">{RIGHT_SHOE}</g><clipPath id="clip-left"><rect x="0" y="0" width="357" height="550"/></clipPath><clipPath id="clip-right"><rect x="356" y="0" width="384" height="550"/></clipPath>'
        if self.extra_defs:
            defs += self.extra_defs
        if self.split:
            brain = '<g class="lobe-left"><g clip-path="url(#clip-left)"><use href="#brain-art"/></g></g><g class="lobe-right"><g clip-path="url(#clip-right)"><use href="#brain-art"/></g></g>'
        else:
            brain = '<use href="#brain-art"/>'
        eyes = ''
        if self.eyes:
            eyes = '<g class="rig-eyes"><ellipse cx="294" cy="274" rx="29" ry="32" fill="#FFF9F1" stroke="#393A35" stroke-width="5"/><ellipse cx="470" cy="274" rx="29" ry="32" fill="#FFF9F1" stroke="#393A35" stroke-width="5"/><g class="pupil-left"><circle cx="294" cy="261" r="11" fill="#393A35"/><circle cx="291" cy="258" r="3" fill="#FFF9F1"/></g><g class="pupil-right"><circle cx="470" cy="261" r="11" fill="#393A35"/><circle cx="467" cy="258" r="3" fill="#FFF9F1"/></g></g>'
        mouth = ('<ellipse cx="379" cy="342" rx="17" ry="16" fill="#393A35"/><path d="M368 350 Q379 341 390 350" stroke="#FF98A5" stroke-width="8" stroke-linecap="round"/>') if self.open_mouth else '<g stroke="#3C3836" stroke-linecap="round">'+SMIRK+'</g>'
        if self.mouth_markup is not None:
            mouth = self.mouth_markup
        left_arm = self.left_arm_markup if self.left_arm_markup is not None else LEFT_ARM
        right_arm = self.right_arm_markup if self.right_arm_markup is not None else RIGHT_ARM
        head = f'<g class="rig-head">{brain}{eyes}<g class="rig-glasses"><use href="#glasses-art"/></g><g class="rig-mouth">{mouth}</g>{self.head_extra}</g>'
        left_shoe = '<g class="rig-shoe-left"><use href="#shoe-left-art"/></g>'
        right_shoe = '<g class="rig-shoe-right"><use href="#shoe-right-art"/></g>'
        detached = self.slug == 'juggle-shoes'
        dl, dr = detached or 'left' in self.detached_shoes, detached or 'right' in self.detached_shoes
        rig = f'''<g class="rig-root">{self.rig_back}
          <g class="rig-left-leg"><path d="M259 481 C267 514 260 548 250 574" stroke="#393A35" stroke-width="23" stroke-linecap="round"/>{LEFT_SOCK}{'' if dl else left_shoe}</g>
          <g class="rig-right-leg"><path d="M418 480 C432 513 424 550 414 574" stroke="#393A35" stroke-width="23" stroke-linecap="round"/>{RIGHT_SOCK}{'' if dr else right_shoe}</g>
          {head}<g class="rig-right-arm">{right_arm}</g><g class="rig-left-arm">{left_arm}</g>{(left_shoe if dl else '') + (right_shoe if dr else '')}{self.rig_extra}
        </g>'''
        if self.slug == 'tunnel':
            defs += '<clipPath id="tunnel-cut"><path d="M0 0H740V654H571 Q356 706 141 654H0Z"/></clipPath>'
            rig = '<g clip-path="url(#tunnel-cut)">' + rig + '</g>'
        if self.rig_clip:
            rig = '<g clip-path="url(#' + self.rig_clip + ')">' + rig + '</g>'
        # Scope every selector and every keyframe. Several copies may coexist when IDs are re-prefixed.
        base_css = f'''#{{P}} {{overflow:hidden;}}
#{{P}} .rig-root,#{{P}} .rig-head,#{{P}} .rig-left-arm,#{{P}} .rig-right-arm,#{{P}} .rig-left-leg,#{{P}} .rig-right-leg,#{{P}} .rig-shoe-left,#{{P}} .rig-shoe-right,#{{P}} .rig-glasses,#{{P}} .rig-mouth,#{{P}} .lobe-left,#{{P}} .lobe-right,#{{P}} [class^="fx-"],#{{P}} [class^="prop-"],#{{P}} [class^="steam-"],#{{P}} [class^="note-"],#{{P}} .pupil-left,#{{P}} .pupil-right {{transform-box:view-box;}}
#{{P}} .rig-root {{transform-origin:356px 640px;}}
#{{P}} .rig-head {{transform-origin:356px 445px;}}
#{{P}} .rig-left-arm {{transform-origin:151px 358px;}}
#{{P}} .rig-right-arm {{transform-origin:580px 358px;}}
#{{P}} .rig-left-leg {{transform-origin:259px 486px;}}
#{{P}} .rig-right-leg {{transform-origin:418px 486px;}}
#{{P}} .rig-shoe-left {{transform-origin:258px 610px;}}
#{{P}} .rig-shoe-right {{transform-origin:423px 610px;}}
#{{P}} .rig-glasses {{transform-origin:379px 267px;}}
#{{P}} .rig-mouth {{transform-origin:379px 342px;}}
#{{P}} .lobe-left {{transform-origin:208px 320px;}}
#{{P}} .lobe-right {{transform-origin:489px 320px;}}
#{{P}} .pupil-left {{transform-origin:294px 274px;}}
#{{P}} .pupil-right {{transform-origin:470px 274px;}}
'''.replace('{P}', '__P__')
        css = base_css + ''.join('#__P__ '+s+'{'+v+'}' for s,v in self.css) + ''.join(self.animations)
        css += '#__P__ *{animation-play-state:var(--play-state,running)!important;}@media(prefers-reduced-motion:reduce){#__P__ *{animation:none!important;}#__P__ .fx-flash{opacity:0;}}'
        svg = f'''<svg xmlns="http://www.w3.org/2000/svg" id="__P__" width="740" height="740" viewBox="0 0 740 740" fill="none" role="img" aria-labelledby="__P__-title __P__-desc">
<title id="__P__-title">Oddbrain — {html.escape(self.label)}</title><desc id="__P__-desc">{html.escape(self.description)}. Editable vector animation on a transparent background. {'Loops' if self.loop else 'Plays once and settles'}. Respects reduced motion.</desc>
<defs>{defs}</defs><style>{css}</style>
{self.back}<ellipse class="rig-ground" cx="356" cy="658" rx="147" ry="12" fill="#393A35" opacity=".065"/>{rig}{self.front}</svg>'''
        # Re-prefix ALL original artwork IDs and references, as well as the motion namespace.
        ids = re.findall(r'\bid="([^"]+)"', svg)
        for old in sorted(set(ids), key=len, reverse=True):
            if old.startswith('__P__'):
                continue
            svg = svg.replace(f'id="{old}"', f'id="__P__-{old}"').replace(f'href="#{old}"', f'href="#__P__-{old}"').replace(f'url(#{old})', f'url(#__P__-{old})')
        return svg.replace('__P__', p)


clips = []
def add(*args, **kwargs):
    c = Clip(*args, **kwargs)
    clips.append(c)
    return c

# 01: quiet default, keeping the supplied expression and silhouette.
c = add('idle','Quiet mischief','Thinking',3.2,'An almost-innocent sway, a little heel tap, and a smug glasses nudge','Lollygagging','low')
c.anim('.rig-head',3.2,{'0%,100%':'transform:rotate(-2deg) translateY(0);','50%':'transform:rotate(2deg) translateY(4px);'})
c.anim('.rig-shoe-right',1.6,{'0%,65%,100%':'transform:rotate(0);','80%':'transform:rotate(-9deg);'})
c.anim('.rig-glasses',3.2,{'0%,80%,100%':'transform:translateY(0);','87%':'transform:translateY(-5px) rotate(-2deg);'})
c.anim('.rig-left-arm',3.2,{'0%,100%':'transform:rotate(0);','50%':'transform:rotate(5deg);'})

# 02: a hand comes up to the temple rather than rotating the whole icon.
c = add('think','Deep-ish thought','Thinking',2.8,'A hand to its temple, a patient head tilt, and a tiny wandering thought','Thinking','low')
c.style('.rig-left-arm','transform:rotate(-126deg);')
c.anim('.rig-head',2.8,{'0%,100%':'transform:rotate(1deg);','50%':'transform:rotate(-4deg) translateY(3px);'})
c.anim('.rig-left-arm',2.8,{'0%,100%':'transform:rotate(-126deg);','50%':'transform:rotate(-132deg);'})
c.back += '<g class="fx-thought">'+dot(600,129,7)+dot(621,103,11)+dot(652,73,18)+'</g>'
c.anim('.fx-thought',2.8,{'0%,100%':'opacity:.25;transform:translateY(3px);','50%':'opacity:.85;transform:translateY(-6px);'})

# 03: opaque sunglasses lift to reveal orbiting pupils; no eyes painted over the lenses.
c = add('eye-roll','Buffering upstairs','Thinking',1.5,'The glasses ride up, pupils orbit like two loading spinners, and a soft haze wobbles around the head','Befuddling','low',eyes=True)
c.style('.rig-glasses','transform:translateY(-104px) rotate(3deg) scale(.9);')
c.anim('.rig-head',3,{'0%,100%':'transform:rotate(-3deg);','50%':'transform:rotate(3deg);'})
for s in ['.pupil-left','.pupil-right']:
    c.anim(s,1.5,{'0%':'transform:rotate(0);','100%':'transform:rotate(360deg);'},'linear')
c.anim('.rig-left-arm',3,{'0%,100%':'transform:rotate(-25deg);','50%':'transform:rotate(-42deg);'})
c.anim('.rig-right-arm',3,{'0%,100%':'transform:rotate(42deg);','50%':'transform:rotate(25deg);'})
c.back += '<g class="fx-haze" fill="#B8A6D3" opacity=".18"><ellipse cx="92" cy="330" rx="47" ry="108"/><ellipse cx="639" cy="330" rx="42" ry="108"/></g><g class="fx-question" stroke="#8C6AA7" stroke-width="8" stroke-linecap="round"><path d="M641 151 C637 130 669 123 677 141 C685 158 661 160 662 174"/><path d="M663 190V192"/></g>'
c.anim('.fx-haze',3,{'0%,100%':'transform:translateX(-12px) scaleX(.97);opacity:.12;','50%':'transform:translateX(12px) scaleX(1.03);opacity:.28;'})
c.anim('.fx-question',3,{'0%,100%':'opacity:.3;transform:translateY(0);','50%':'opacity:.9;transform:translateY(-8px);'})

# 04: calculation board, sequential cells, tapping hands.
c = add('compute','Number crunch','Thinking',2.2,'Taps a floating calculator while its cells tick through a calculation','Calculating','medium')
c.bounce(4)
c.anim('.rig-left-arm',1.1,{'0%,100%':'transform:rotate(-77deg);','50%':'transform:rotate(-87deg);'})
c.anim('.rig-right-arm',1.1,{'0%,100%':'transform:rotate(88deg);','50%':'transform:rotate(76deg);'})
c.front += '<g class="prop-board"><rect x="262" y="408" width="213" height="132" rx="21" fill="#FFF9F1" stroke="#8C6AA7" stroke-width="6"/><rect x="283" y="425" width="171" height="23" rx="7" fill="#E6DDED"/>' + ''.join(f'<rect class="cell-{i}" x="{286+(i%4)*44}" y="{463+(i//4)*31}" width="29" height="18" rx="5" fill="#8C6AA7"/>' for i in range(8))+'</g>'
for i in range(8):
    c.anim(f'.cell-{i}',1.1,{'0%,100%':'opacity:.3;','35%,55%':'opacity:1;'},'steps(1,end)',delay=-i*.1375)
c.style('.prop-board','transform-origin:369px 474px;')
c.anim('.prop-board',2.2,{'0%,100%':'transform:rotate(-2deg);','50%':'transform:rotate(2deg);'})

# 05: busy little keyboard, not a bouncing logo.
c = add('type','Tiny power user','Making',1.2,'Alternating hands peck at a tiny floating keyboard while code lines pulse','Working','medium')
c.bounce(3)
c.anim('.rig-left-arm',.3,{'0%,100%':'transform:rotate(-74deg);','50%':'transform:rotate(-88deg);'})
c.anim('.rig-right-arm',.3,{'0%,100%':'transform:rotate(88deg);','50%':'transform:rotate(74deg);'})
c.front += '<g class="prop-keyboard"><path d="M251 447 H479 L506 497 Q509 510 492 511 H236 Q221 510 225 498Z" fill="#FFF9F1" stroke="#8C6AA7" stroke-width="6"/>'+''.join(f'<path d="M{258+i*38} 466h20m-15 19h20" stroke="#8C6AA7" stroke-width="7" stroke-linecap="round"/>' for i in range(6))+'</g>'
c.back += '<g class="fx-code" stroke="#8C6AA7" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"><path d="M640 214l-18 18 18 18m39-36 18 18-18 18m-19-44-9 51"/></g>'
c.anim('.fx-code',1.2,{'0%,100%':'opacity:.4;transform:translateY(0);','50%':'opacity:1;transform:translateY(-8px);'})

# 06: pencil + progressive doodle.
c = add('sketch','Doodle mode','Making',2.8,'Scratches a looping doodle with an oversized pencil, stopping to admire absolutely nothing','Doodling','medium')
c.style('.rig-left-arm','transform:rotate(-74deg);')
c.anim('.rig-right-arm',1.4,{'0%,100%':'transform:rotate(100deg);','50%':'transform:rotate(83deg);'})
c.front += '<g class="prop-paper"><rect x="234" y="437" width="249" height="117" rx="12" fill="#FFF9F1" stroke="#D6CBDD" stroke-width="5"/><path class="fx-doodle" d="M268 501 C282 455 301 539 319 487 S355 533 373 490 S413 532 442 482" stroke="#8C6AA7" stroke-width="7" stroke-linecap="round" pathLength="100" stroke-dasharray="100"/></g><g class="prop-pencil"><path d="M421 446 L483 345 L498 355 L437 456 L420 467Z" fill="#EDC77E" stroke="#393A35" stroke-width="4" stroke-linejoin="round"/><path d="M420 467l4-19 13 8Z" fill="#393A35"/><path d="M483 345l8-13 15 10-8 13" fill="#FF98A5"/></g>'
c.style('.prop-pencil','transform-origin:429px 455px;')
c.anim('.prop-pencil',1.4,{'0%,100%':'transform:translateX(-12px) rotate(-9deg);','50%':'transform:translateX(12px) rotate(7deg);'})
c.anim('.fx-doodle',2.8,{'0%,5%':'stroke-dashoffset:100;opacity:1;','75%,88%':'stroke-dashoffset:0;opacity:1;','100%':'stroke-dashoffset:0;opacity:0;'},'linear')
c.anim('.rig-head',2.8,{'0%,100%':'transform:rotate(0);','65%':'transform:rotate(3deg);'})

# 07: actual page flip via scaleX, safely opaque behind it.
c = add('read','Very important news','Thinking',3.4,'Peers over a tiny newspaper and flips the middle page with unjustified seriousness','Perusing','low')
c.style('.rig-left-arm','transform:rotate(-79deg);')
c.style('.rig-right-arm','transform:rotate(79deg);')
c.front += '<g class="prop-book"><path d="M228 412 Q296 394 364 421 Q432 394 500 412 V536 Q430 521 364 545 Q296 521 228 536Z" fill="#FFF9F1" stroke="#8C6AA7" stroke-width="5"/><path d="M364 421v124" stroke="#D6CBDD" stroke-width="5"/>'+''.join(f'<path d="M{x} {y}h78" stroke="#BEADC9" stroke-width="5" stroke-linecap="round"/>' for x in [251,393] for y in [440,458,476,494,512])+'<g class="prop-page"><path d="M364 421 Q432 394 500 412 V536 Q430 521 364 545Z" fill="#F1EAF4" stroke="#8C6AA7" stroke-width="4"/><path d="M392 440h78m-78 18h78m-78 18h60" stroke="#BEADC9" stroke-width="5" stroke-linecap="round"/></g></g>'
c.style('.prop-page','transform-origin:364px 480px;')
c.anim('.prop-page',3.4,{'0%,58%':'transform:scaleX(1);','78%':'transform:scaleX(-1);','88%':'transform:scaleX(-1);opacity:1;','89%':'opacity:0;','99%,100%':'transform:scaleX(1);opacity:0;'})
c.anim('.rig-head',3.4,{'0%,100%':'transform:rotate(-2deg);','50%':'transform:rotate(3deg);'})

# 08: constructing an actual small block tower.
c = add('architect','Questionable architecture','Making',3.2,'Places three floating blocks into an improbably tidy little tower','Architecting','medium')
c.style('.rig-left-arm','transform:rotate(-71deg);')
c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(52deg);','55%,72%':'transform:rotate(115deg);'})
c.front += '<g class="prop-block-base"><rect x="282" y="483" width="163" height="46" rx="9" fill="#D6C7E4" stroke="#8C6AA7" stroke-width="5"/></g><g class="prop-block-mid"><rect x="305" y="432" width="117" height="46" rx="9" fill="#FFCDD2" stroke="#D58A98" stroke-width="5"/></g><g class="prop-block-top"><path d="M314 427 L363 372 L412 427Z" fill="#EDC77E" stroke="#B29456" stroke-width="5" stroke-linejoin="round"/></g>'
c.anim('.prop-block-mid',3.2,{'0%,100%':'transform:translate(-135px,-30px) rotate(-16deg);opacity:0;','15%':'opacity:1;','38%,88%':'transform:translate(0,0) rotate(0);opacity:1;','97%':'opacity:0;'})
c.style('.prop-block-mid','transform-origin:365px 455px;')
c.anim('.prop-block-top',3.2,{'0%,38%,100%':'transform:translate(105px,-140px) rotate(30deg);opacity:0;','48%':'opacity:1;','69%,88%':'transform:translate(0,0) rotate(0);opacity:1;','97%':'opacity:0;'})
c.style('.prop-block-top','transform-origin:363px 407px;')

# 09: idea bulb rises, the glasses perk, cheeky nod.
c = add('idea','A suspiciously good idea','Thinking',2.6,'A small lightbulb pops above a cheeky head tilt and turns on','Ideating','low')
c.anim('.rig-head',2.6,{'0%,100%':'transform:rotate(-3deg);','45%,62%':'transform:rotate(4deg) translateY(-6px);'})
c.anim('.rig-glasses',2.6,{'0%,100%':'transform:translateY(0);','45%,62%':'transform:translateY(-10px) rotate(2deg);'})
c.back += '<g class="fx-bulb"><path d="M603 109 C574 109 568 146 585 162 C593 170 593 176 593 181 H617 C617 176 617 170 625 162 C642 145 634 109 603 109Z" fill="#F4DEAA" stroke="#B39861" stroke-width="5"/><path d="M595 191h20m-16 10h12m-7-37v-20m-9-6 9 6 9-6" stroke="#B39861" stroke-width="5" stroke-linecap="round"/><g class="fx-rays" stroke="#D5AF59" stroke-width="6" stroke-linecap="round"><path d="M604 89V77m-41 35-10-7m94 7 10-7m-94 57-12 5m96-5 12 5"/></g></g>'
c.style('.fx-bulb','transform-origin:604px 163px;')
c.anim('.fx-bulb',2.6,{'0%,100%':'transform:translateY(9px) scale(.8);opacity:.25;','40%,70%':'transform:translateY(-7px) scale(1);opacity:1;'})
c.anim('.fx-rays',2.6,{'0%,30%,100%':'opacity:0;','40%,70%':'opacity:1;'})

# 10: stirring around the rim, three staggered wisps of steam.
c = add('stir','Let it cook','Cooking',2.4,'Stirs a round little pot with a wooden spoon while three wisps of steam curl upward','Brewing','medium')
c.style('.rig-left-arm','transform:rotate(-77deg);')
c.anim('.rig-right-arm',1.2,{'0%,100%':'transform:rotate(97deg);','50%':'transform:rotate(82deg);'})
c.front += '<g class="prop-spoon"><path d="M383 451L456 357" stroke="#B39574" stroke-width="13" stroke-linecap="round"/><ellipse cx="380" cy="454" rx="14" ry="21" fill="#B39574" transform="rotate(34 380 454)"/></g><g class="prop-pot"><path d="M259 440 H473 L454 522 Q449 539 431 539 H301 Q283 539 278 522Z" fill="#B8A4CB" stroke="#8C6AA7" stroke-width="6"/><ellipse cx="366" cy="439" rx="107" ry="22" fill="#FFF1D7" stroke="#8C6AA7" stroke-width="6"/><path class="fx-swirl" d="M303 438 C325 418 425 420 429 440 C430 452 336 454 337 439 C337 431 389 432 389 439" stroke="#D2AB6E" stroke-width="5" stroke-linecap="round"/><path d="M261 464 Q232 456 238 482 Q241 495 275 491 M471 464 Q500 456 494 482 Q490 495 458 491" stroke="#8C6AA7" stroke-width="9" stroke-linecap="round"/></g>'+steam()
c.style('.prop-spoon','transform-origin:391px 441px;')
c.anim('.prop-spoon',1.2,{'0%,100%':'transform:translateX(-15px) rotate(-8deg);','50%':'transform:translateX(15px) rotate(8deg);'})
c.anim('.fx-swirl',2.4,{'0%,100%':'opacity:.4;','50%':'opacity:1;'})
c.steam()
c.anim('.rig-head',2.4,{'0%,100%':'transform:rotate(-2deg);','50%':'transform:rotate(2deg);'})

# 11: quick whisking, with ingredient flecks, distinct from stirring.
c = add('whisk','Aggressively delicious','Cooking',.8,'Whisks a bowl with overconfident wrist flicks as little ingredient flecks fly','Whisking','high')
c.style('.rig-left-arm','transform:rotate(-79deg);')
c.anim('.rig-right-arm',.4,{'0%,100%':'transform:rotate(105deg);','50%':'transform:rotate(86deg);'})
c.front += '<g class="prop-whisk"><path d="M384 456 L458 352" stroke="#393A35" stroke-width="10" stroke-linecap="round"/><path d="M395 437 C351 475 375 495 395 455 C419 415 420 447 384 477 M402 428 C377 467 397 494 405 452" stroke="#9D8CAB" stroke-width="4" stroke-linecap="round"/></g><path d="M252 459 H481 C470 520 436 544 366 544 C297 544 265 520 252 459Z" fill="#FFCDD2" stroke="#D58A98" stroke-width="6"/><ellipse cx="366" cy="459" rx="114" ry="19" fill="#FFF4DF" stroke="#D58A98" stroke-width="6"/>'+dot(303,424,7,YELLOW,'fx-a')+dot(419,404,6,PINK,'fx-b')+star(452,431,10,YELLOW,'fx-c')
c.style('.prop-whisk','transform-origin:390px 455px;')
c.anim('.prop-whisk',.4,{'0%,100%':'transform:translateX(-16px) rotate(-10deg);','50%':'transform:translateX(16px) rotate(10deg);'})
for i,cl in enumerate(['.fx-a','.fx-b','.fx-c']):
    c.anim(cl,.8,{'0%':'transform:translateY(10px);opacity:0;','30%':'opacity:1;','100%':'transform:translateY(-35px);opacity:0;'},delay=-i*.25)
c.bounce(3,.8)

# 12: dough compresses then rises. Easy to reuse for all baking labels.
c = add('bake','Proof of genius','Cooking',2.8,'Gently kneads an absurdly proud little bun; it squashes, proofs, and puffs back up','Baking','medium')
c.anim('.rig-left-arm',1.4,{'0%,100%':'transform:rotate(-75deg);','50%':'transform:rotate(-85deg);'})
c.anim('.rig-right-arm',1.4,{'0%,100%':'transform:rotate(75deg);','50%':'transform:rotate(85deg);'})
c.front += '<rect x="245" y="511" width="241" height="20" rx="10" fill="#8C6AA7"/><g class="prop-bun"><path d="M280 506 C259 437 294 405 365 405 C435 405 471 438 450 506Z" fill="#EDC77E" stroke="#C8A067" stroke-width="6"/><path d="M321 427 C308 442 311 454 321 463 M363 418 C351 435 353 450 364 459 M406 427 C393 442 396 453 406 464" stroke="#FFF0C9" stroke-width="9" stroke-linecap="round"/></g>' + steam()
c.style('.prop-bun','transform-origin:365px 508px;')
c.anim('.prop-bun',2.8,{'0%,100%':'transform:scale(1,.94);','25%':'transform:scale(1.12,.75);','64%':'transform:scale(.95,1.1);'})
c.steam()
c.anim('.rig-head',2.8,{'0%,100%':'transform:rotate(-2deg);','65%':'transform:rotate(3deg);'})

# 13: offset shoulder, hip, foot and glasses beats.
c = add('shimmy','The extremely unnecessary shimmy','Dancing',1.2,'A shoulder shimmy, pigeon-toed kicks, and sunglasses that arrive half a beat late','Shimmying','high')
c.anim('.rig-root',1.2,{'0%,100%':'transform:translateX(-10px) rotate(-4deg);','50%':'transform:translateX(10px) rotate(4deg);'})
c.anim('.rig-head',.6,{'0%,100%':'transform:skewX(-4deg) scale(1.02,.98);','50%':'transform:skewX(4deg) scale(.99,1.01);'})
c.anim('.rig-left-arm',.6,{'0%,100%':'transform:rotate(-48deg);','50%':'transform:rotate(-95deg);'})
c.anim('.rig-right-arm',.6,{'0%,100%':'transform:rotate(95deg);','50%':'transform:rotate(48deg);'})
c.anim('.rig-left-leg',.6,{'0%,100%':'transform:rotate(-12deg);','50%':'transform:rotate(8deg);'})
c.anim('.rig-right-leg',.6,{'0%,100%':'transform:rotate(8deg);','50%':'transform:rotate(-12deg);'})
c.anim('.rig-glasses',.6,{'0%,100%':'transform:translate(3px,-5px) rotate(2deg);','50%':'transform:translate(-3px,1px) rotate(-2deg);'},delay=-.08)
c.music()

# 14: the actual cheeks move in counterphase.
c = add('wiggle','Certified cheek wobble','Dancing',1.6,'The two brain cheeks wobble independently, with floppy arms and a deeply undignified hip wiggle','Wibbling','high',split=True)
c.anim('.rig-root',1.6,{'0%,100%':'transform:rotate(-6deg) translateX(-9px);','50%':'transform:rotate(6deg) translateX(9px);'})
c.anim('.lobe-left',.8,{'0%,100%':'transform:translate(-5px,3px) scale(1.025,.98);','50%':'transform:translate(5px,-3px) scale(.98,1.025);'})
c.anim('.lobe-right',.8,{'0%,100%':'transform:translate(-5px,-3px) scale(.98,1.025);','50%':'transform:translate(5px,3px) scale(1.025,.98);'})
c.anim('.rig-left-arm',.8,{'0%,100%':'transform:rotate(16deg);','50%':'transform:rotate(-27deg);'})
c.anim('.rig-right-arm',.8,{'0%,100%':'transform:rotate(27deg);','50%':'transform:rotate(-16deg);'})
c.anim('.rig-left-leg',1.6,{'0%,100%':'transform:rotate(12deg);','50%':'transform:rotate(-9deg);'})
c.anim('.rig-right-leg',1.6,{'0%,100%':'transform:rotate(9deg);','50%':'transform:rotate(-12deg);'})
c.music()

# 15: toe-up + sliding foot, alternating every half beat.
c = add('moonwalk','Absolutely going nowhere','Dancing',2.4,'Alternates a toe-up shoe with a sliding shoe in a tiny in-place moonwalk','Moonwalking','medium')
c.anim('.rig-root',2.4,{'0%,100%':'transform:translateX(12px) rotate(-2deg);','50%':'transform:translateX(-12px) rotate(2deg);'})
c.anim('.rig-left-leg',1.2,{'0%,100%':'transform:translateX(-18px) rotate(8deg);','50%':'transform:translate(18px,-8px) rotate(-6deg);'})
c.anim('.rig-right-leg',1.2,{'0%,100%':'transform:translate(18px,-8px) rotate(-6deg);','50%':'transform:translateX(-18px) rotate(8deg);'})
c.anim('.rig-shoe-left',1.2,{'0%,100%':'transform:rotate(0);','50%':'transform:rotate(-22deg);'})
c.anim('.rig-shoe-right',1.2,{'0%,100%':'transform:rotate(-22deg);','50%':'transform:rotate(0);'})
c.anim('.rig-left-arm',1.2,{'0%,100%':'transform:rotate(-18deg);','50%':'transform:rotate(14deg);'})
c.anim('.rig-right-arm',1.2,{'0%,100%':'transform:rotate(14deg);','50%':'transform:rotate(-18deg);'})
c.back += '<g class="fx-slide" stroke="#BDA8CE" stroke-width="5" stroke-linecap="round" opacity=".5"><path d="M164 651h51m-22 15h34m290-15h47m-32 15h24"/></g>'
c.anim('.fx-slide',1.2,{'0%,100%':'transform:translateX(-14px);opacity:.2;','50%':'transform:translateX(14px);opacity:.65;'})
c.music()

# 16: a genuinely odd off-beat dance, with squash before lift.
c = add('chaos','No bones, no rules','Dancing',1.6,'Squats, kicks, throws both arms up, and lands on completely the wrong beat','Tomfoolering','high')
c.anim('.rig-root',1.6,{'0%,100%':'transform:translateY(10px) rotate(-3deg) scale(1.03,.95);','22%':'transform:translateY(-39px) rotate(-10deg) scale(.97,1.02);','47%':'transform:translateY(13px) rotate(5deg) scale(1.04,.94);','73%':'transform:translateY(-35px) rotate(9deg) scale(.97,1.02);'})
c.anim('.rig-left-arm',.8,{'0%,100%':'transform:rotate(-30deg);','45%':'transform:rotate(-160deg);'})
c.anim('.rig-right-arm',.8,{'0%,100%':'transform:rotate(150deg);','45%':'transform:rotate(15deg);'})
c.anim('.rig-left-leg',.8,{'0%,100%':'transform:rotate(18deg);','45%':'transform:rotate(-30deg);'})
c.anim('.rig-right-leg',.8,{'0%,100%':'transform:rotate(-30deg);','45%':'transform:rotate(18deg);'})
c.anim('.rig-glasses',.8,{'0%,100%':'transform:rotate(-5deg) translateY(-8px);','50%':'transform:rotate(4deg);'},delay=-.1)
c.music()

# 17: small measured steps, head lagging behind hips.
c = add('waddle','On a very small mission','Travel',1.8,'Takes tiny duck-footed steps, swaying its cheeks in the opposite direction','Waddling','medium')
c.anim('.rig-root',1.8,{'0%,100%':'transform:translate(-7px,0) rotate(-4deg);','25%,75%':'transform:translateY(-7px);','50%':'transform:translate(7px,0) rotate(4deg);'})
c.anim('.rig-head',1.8,{'0%,100%':'transform:rotate(3deg);','50%':'transform:rotate(-3deg);'})
c.anim('.rig-left-leg',1.8,{'0%,100%':'transform:rotate(-13deg);','50%':'transform:translateY(-12px) rotate(12deg);'})
c.anim('.rig-right-leg',1.8,{'0%,100%':'transform:translateY(-12px) rotate(12deg);','50%':'transform:rotate(-13deg);'})
c.anim('.rig-left-arm',1.8,{'0%,100%':'transform:rotate(12deg);','50%':'transform:rotate(-16deg);'})
c.anim('.rig-right-arm',1.8,{'0%,100%':'transform:rotate(16deg);','50%':'transform:rotate(-12deg);'})

# 18: tilted head, opposing limbs, and ground-speed lines.
c = add('run','Late for absolutely nothing','Travel',.72,'A frantic in-place scamper with opposite arm and leg swings and little speed streaks','Scampering','high')
c.anim('.rig-root',.36,{'0%,100%':'transform:translateY(0) rotate(7deg) scale(.96,.98);','50%':'transform:translateY(-18px) rotate(7deg) scale(.96,1.01);'})
c.anim('.rig-left-leg',.72,{'0%,100%':'transform:rotate(34deg);','50%':'transform:rotate(-31deg);'})
c.anim('.rig-right-leg',.72,{'0%,100%':'transform:rotate(-31deg);','50%':'transform:rotate(34deg);'})
c.anim('.rig-left-arm',.72,{'0%,100%':'transform:rotate(-80deg);','50%':'transform:rotate(25deg);'})
c.anim('.rig-right-arm',.72,{'0%,100%':'transform:rotate(-25deg);','50%':'transform:rotate(80deg);'})
c.back += '<g class="fx-speed" stroke="#BDA8CE" stroke-width="6" stroke-linecap="round"><path d="M64 490h62m-80 38h75m-30 37h40m13 102h65m310 0h64"/></g>'
c.anim('.fx-speed',.36,{'0%':'transform:translateX(12px);opacity:0;','35%':'opacity:.7;','100%':'transform:translateX(-25px);opacity:0;'},'linear')

# 19: faux 3-D spin, compressed at the side, glasses facing away for half a turn.
c = add('spin','One brain, zero bearings','Magic',2.4,'Turns around its vertical axis with a squashy edge-on moment and orbiting dots','Spinning','medium')
c.anim('.rig-root',2.4,{'0%,100%':'transform:scaleX(1) translateY(0);','25%':'transform:scaleX(.15) translateY(-15px);','50%':'transform:scaleX(-1) translateY(0);','75%':'transform:scaleX(-.15) translateY(-15px);'},'linear')
c.anim('.rig-glasses',2.4,{'0%,20%,80%,100%':'opacity:1;','28%,72%':'opacity:0;'},'linear')
c.anim('.rig-mouth',2.4,{'0%,20%,80%,100%':'opacity:1;','28%,72%':'opacity:0;'},'linear')
c.back += '<ellipse cx="356" cy="433" rx="277" ry="85" stroke="#C9B8D8" stroke-width="4" stroke-dasharray="9 16"/><g class="fx-orbit">'+dot(84,433,10,PURPLE)+'</g>'
c.style('.fx-orbit','transform-origin:356px 433px;')
c.anim('.fx-orbit',2.4,{'0%':'transform:rotate(0);','100%':'transform:rotate(360deg);'},'linear')

# 20: buoyant levitation, soft hands and feet.
c = add('float','Zero-gravity daydream','Magic',3.6,'Levitation with dangling feet, a slow roll, and a breathing shadow','Levitating','low')
c.anim('.rig-root',3.6,{'0%,100%':'transform:translateY(-23px) rotate(-3deg);','50%':'transform:translateY(-58px) rotate(3deg);'})
c.anim('.rig-left-arm',3.6,{'0%,100%':'transform:rotate(18deg);','50%':'transform:rotate(30deg);'})
c.anim('.rig-right-arm',3.6,{'0%,100%':'transform:rotate(-30deg);','50%':'transform:rotate(-18deg);'})
c.anim('.rig-left-leg',3.6,{'0%,100%':'transform:rotate(-8deg);','50%':'transform:rotate(5deg);'})
c.anim('.rig-right-leg',3.6,{'0%,100%':'transform:rotate(-5deg);','50%':'transform:rotate(8deg);'})
c.style('.rig-ground','transform-origin:356px 658px;')
c.anim('.rig-ground',3.6,{'0%,100%':'transform:scaleX(.85);opacity:.065;','50%':'transform:scaleX(.6);opacity:.035;'})
c.back += star(102,318,13,PURPLE,'fx-a')+star(650,394,12,PURPLE,'fx-b')
c.anim('.fx-a',3.6,{'0%,100%':'opacity:.2;transform:translateY(0);','50%':'opacity:.7;transform:translateY(-15px);'})
c.anim('.fx-b',3.6,{'0%,100%':'opacity:.7;transform:translateY(-15px);','50%':'opacity:.2;transform:translateY(0);'})

# 21: floppy head + continuous flowing wind lines.
c = add('gust','A little winded','Magic',2.4,'Leans into a gust; cheeks and arms lag as three breezy strokes pass by','Gusting','medium')
c.anim('.rig-root',2.4,{'0%,100%':'transform:skewX(-3deg) rotate(-2deg);','50%':'transform:skewX(-10deg) rotate(-6deg);'})
c.anim('.rig-head',2.4,{'0%,100%':'transform:translateX(-3px) rotate(0);','50%':'transform:translateX(-15px) rotate(-4deg);'},delay=-.15)
c.anim('.rig-left-arm',2.4,{'0%,100%':'transform:rotate(12deg);','50%':'transform:rotate(45deg);'})
c.anim('.rig-right-arm',2.4,{'0%,100%':'transform:rotate(-12deg);','50%':'transform:rotate(-45deg);'})
c.back += '<g stroke="#BDA8CE" stroke-width="6" stroke-linecap="round">'+''.join(f'<path class="wind-{i}" d="M34 {y} H181 Q209 {y} 201 {y-16} C195 {y-29} 173 {y-21} 180 {y-9}" pathLength="100" stroke-dasharray="48 52"/>' for i,y in enumerate([245,335,419]))+'</g>'
for i in range(3):
    c.anim(f'.wind-{i}',1.2,{'0%':'stroke-dashoffset:100;opacity:0;','30%,70%':'opacity:.7;','100%':'stroke-dashoffset:0;opacity:0;'},'linear',delay=-i*.4)

# 22: head-grown sprout, not a generic floating leaf.
c = add('grow','A thought takes root','Making',3.6,'A tiny sprout unfolds out of the brain while the mascot carefully holds still','Sprouting','low')
c.head_extra += '<g class="prop-sprout"><path d="M356 150 C349 109 365 96 358 65" stroke="#7C946B" stroke-width="9" stroke-linecap="round"/><path class="leaf-left" d="M356 116 C309 119 304 81 315 78 C343 73 357 91 356 116Z" fill="#A8BA99"/><path class="leaf-right" d="M360 97 C401 102 412 69 401 64 C373 58 359 74 360 97Z" fill="#8FA47E"/></g>'
c.style('.prop-sprout','transform-origin:356px 150px;')
c.anim('.prop-sprout',3.6,{'0%,100%':'transform:scale(.2);opacity:.2;','45%,80%':'transform:scale(1);opacity:1;'})
c.style('.leaf-left','transform-box:view-box;transform-origin:356px 116px;')
c.style('.leaf-right','transform-box:view-box;transform-origin:360px 97px;')
c.anim('.leaf-left',3.6,{'0%,100%':'transform:rotate(42deg) scale(.2);','45%,80%':'transform:rotate(0) scale(1);'})
c.anim('.leaf-right',3.6,{'0%,100%':'transform:rotate(-42deg) scale(.2);','50%,80%':'transform:rotate(0) scale(1);'})
c.anim('.rig-head',3.6,{'0%,100%':'transform:translateY(3px);','50%':'transform:translateY(-3px);'})
c.anim('.rig-left-arm',3.6,{'0%,100%':'transform:rotate(-15deg);','50%':'transform:rotate(-40deg);'})
c.anim('.rig-right-arm',3.6,{'0%,100%':'transform:rotate(15deg);','50%':'transform:rotate(40deg);'})

# 23: winding up and striking a tiny anvil; particles only on the impact beat.
c = add('forge','Tiny tinkerer','Making',1.8,'Winds up a little hammer and strikes an anvil, with two small impact sparks','Tinkering','medium')
c.style('.rig-left-arm','transform:rotate(-66deg);')
c.anim('.rig-right-arm',1.8,{'0%,100%':'transform:rotate(110deg);','45%':'transform:rotate(163deg);','59%,69%':'transform:rotate(84deg);'})
c.front += '<path d="M284 477 H426 L471 455 L449 495 H395 V521 H419 V540 H290 V521 H314 V495 H284Z" fill="#B8A4CB" stroke="#8C6AA7" stroke-width="5" stroke-linejoin="round"/><g class="prop-hammer"><path d="M397 460 L474 373" stroke="#AD8F70" stroke-width="13" stroke-linecap="round"/><rect x="445" y="346" width="70" height="38" rx="8" fill="#D6CBDD" stroke="#8C6AA7" stroke-width="5" transform="rotate(40 480 365)"/></g>'+star(340,454,15,YELLOW,'fx-a')+star(436,445,12,YELLOW,'fx-b')
c.style('.prop-hammer','transform-origin:461px 416px;')
c.anim('.prop-hammer',1.8,{'0%,100%':'transform:rotate(-18deg);','45%':'transform:rotate(-80deg);','59%,69%':'transform:translate(-16px,12px) rotate(35deg);'})
for s in ['.fx-a','.fx-b']:
    c.anim(s,1.8,{'0%,53%,82%,100%':'opacity:0;','60%':'opacity:1;','75%':'opacity:.1;transform:translateY(-15px);'})
c.anim('.rig-head',1.8,{'0%,100%':'transform:rotate(0);','59%':'transform:rotate(4deg) translateY(5px);'})

# 24: the halves reconfigure, crystal particles move toward the centre.
c = add('transform','Getting it together','Magic',3.2,'The two cheeks separate, twist, and reform as little diamond pieces converge','Transmuting','medium',split=True)
c.anim('.lobe-left',3.2,{'0%,100%':'transform:translate(0,0) rotate(0) scale(1);','42%,58%':'transform:translate(-25px,-12px) rotate(-10deg) scale(.92);'})
c.anim('.lobe-right',3.2,{'0%,100%':'transform:translate(0,0) rotate(0) scale(1);','42%,58%':'transform:translate(25px,-12px) rotate(10deg) scale(.92);'})
c.anim('.rig-glasses',3.2,{'0%,100%':'transform:translateY(0);','50%':'transform:translateY(-15px) scale(.96);'})
c.anim('.rig-left-arm',3.2,{'0%,100%':'transform:rotate(0);','50%':'transform:rotate(-65deg);'})
c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(0);','50%':'transform:rotate(65deg);'})
for i,(x,y) in enumerate([(77,220),(656,211),(95,445),(643,435)]):
    c.back += f'<g class="fx-piece-{i}"><path d="M{x} {y-13}l12 13-12 13-12-13Z" fill="#C4AED5"/></g>'
    c.anim(f'.fx-piece-{i}',3.2,{'0%,100%':'opacity:0;transform:translate(0,0);','35%':'opacity:.9;','80%':f'opacity:0;transform:translate({(356-x)*.3}px,{(320-y)*.3}px);'})

# 25: local opacity illusion, no expensive blur filter.
c = add('dissolve','Slightly less corporeal','Magic',3.2,'Becomes translucent as a few pink and purple bubbles drift upward, then condenses again','Nebulizing','low')
c.anim('.rig-root',3.2,{'0%,100%':'transform:translateY(0);opacity:1;','50%':'transform:translateY(-18px);opacity:.24;'})
for i,(x,y,r) in enumerate([(114,397,13),(169,235,9),(601,375,16),(559,206,10),(357,101,12)]):
    c.front += dot(x,y,r,[PINK,PURPLE][i%2],f'fx-bubble-{i}')
    c.anim(f'.fx-bubble-{i}',3.2,{'0%':'transform:translateY(35px) scale(.4);opacity:0;','35%,55%':'opacity:.6;','100%':'transform:translateY(-70px) scale(1.15);opacity:0;'},delay=-i*.53)
c.anim('.rig-left-arm',3.2,{'0%,100%':'transform:rotate(0);','50%':'transform:rotate(30deg);'})
c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(0);','50%':'transform:rotate(-30deg);'})

# 26: magician wrist flick, not licensed costume or extra clothing.
c = add('sparkle','Unlicensed wizardry','Magic',2.2,'A little wrist flick sends four-pointed sparkles around the brain; no hat or outfit required','Enchanting','medium')
c.anim('.rig-right-arm',2.2,{'0%,100%':'transform:rotate(30deg);','40%,60%':'transform:rotate(126deg);'})
c.anim('.rig-left-arm',2.2,{'0%,100%':'transform:rotate(10deg);','40%,60%':'transform:rotate(-40deg);'})
c.anim('.rig-head',2.2,{'0%,100%':'transform:rotate(-2deg);','45%':'transform:rotate(3deg) translateY(-5px);'})
for i,(x,y,r) in enumerate([(111,230,22),(638,177,22),(657,381,17),(186,101,13),(505,80,13)]):
    c.front += star(x,y,r,[PURPLE,YELLOW,PINK][i%3],f'fx-star-{i}')
    c.style(f'.fx-star-{i}',f'transform-origin:{x}px {y}px;')
    c.anim(f'.fx-star-{i}',2.2,{'0%,100%':'transform:scale(.1) rotate(-35deg);opacity:0;','45%,58%':'transform:scale(1) rotate(10deg);opacity:.9;'},delay=-i*.17)

# 27: boop gesture toward the viewer with elastic head recoil.
c = add('boop','A highly professional boop','Mischief',2,'Leans forward for a playful boop, then recoils with a smug little bounce','Booping','medium')
c.anim('.rig-root',2,{'0%,100%':'transform:scale(1);','40%':'transform:scale(1.045) translateY(-6px);','54%':'transform:scale(.98) translateY(4px);','68%':'transform:scale(1.015);'})
c.anim('.rig-left-arm',2,{'0%,100%':'transform:rotate(-10deg);','40%':'transform:rotate(-126deg) scale(1.08);','58%':'transform:rotate(-96deg);'})
c.anim('.rig-head',2,{'0%,100%':'transform:rotate(-2deg);','40%':'transform:rotate(4deg);','58%':'transform:rotate(-4deg);'})
c.front += '<g class="fx-boop" stroke="#8C6AA7" stroke-width="6" stroke-linecap="round"><path d="M300 299l-8-12m26 5 2-14m13 26 12-6"/></g>'
c.anim('.fx-boop',2,{'0%,33%,70%,100%':'opacity:0;','42%,48%':'opacity:1;'})

# 28: socks remain on the feet; the shoes follow staggered toss arcs.
c = add('juggle-shoes','Shoes are optional','Mischief',2.8,'Juggles both purple shoes on staggered toss arcs while standing in socks','Fiddle-faddling','high')
c.bounce(6,1.4)
c.anim('.rig-left-arm',1.4,{'0%,100%':'transform:rotate(-74deg);','50%':'transform:rotate(-111deg);'})
c.anim('.rig-right-arm',1.4,{'0%,100%':'transform:rotate(111deg);','50%':'transform:rotate(74deg);'})
for side,base_x,phase,direction in [('left',258,0,1),('right',423,.5,-1)]:
    frames = {}
    for step in range(33):
        t = step / 32
        q = (t + phase) % 1
        s = q * 2 if q <= .5 else (q-.5) * 2
        x = 220 + 290*s if q <= .5 else 510-290*s
        y = 380 - 280*4*s*(1-s) if q <= .5 else 380+60*4*s*(1-s)
        frames[f'{t*100:g}%'] = f'transform:translate({x-base_x:.2f}px,{y-610:.2f}px) rotate({direction*t*720:g}deg);'
    c.anim(f'.rig-shoe-{side}',2.8,frames,'linear')
c.anim('.rig-head',2.8,{'0%,100%':'transform:rotate(-3deg);','50%':'transform:rotate(3deg);'})

# 29: glasses tumble while actual eyes follow them.
c = add('juggle-glasses','Optical nonsense','Mischief',2.8,'Tosses its own sunglasses from hand to hand, with exposed eyes following the flight','Finagling','high',eyes=True)
c.bounce(5,1.4)
c.anim('.rig-left-arm',1.4,{'0%,100%':'transform:rotate(-76deg);','50%':'transform:rotate(-112deg);'})
c.anim('.rig-right-arm',1.4,{'0%,100%':'transform:rotate(112deg);','50%':'transform:rotate(76deg);'})
frames = {}
for step in range(33):
    t = step/32
    q = t if t <= .5 else 1-t
    s = q*2
    x = 245 + 255*s
    y = 400 - 310*4*s*(1-s)
    frames[f'{t*100:g}%'] = f'transform:translate({x-379:.2f}px,{y-267:.2f}px) rotate({-20+t*720:g}deg) scale(.64);'
c.anim('.rig-glasses',2.8,frames,'linear')
c.anim('.pupil-left',2.8,{'0%,100%':'transform:translate(-7px,13px);','25%,75%':'transform:translate(0,-2px);','50%':'transform:translate(7px,13px);'},'linear')
c.anim('.pupil-right',2.8,{'0%,100%':'transform:translate(-7px,13px);','25%,75%':'transform:translate(0,-2px);','50%':'transform:translate(7px,13px);'},'linear')

# 30: impossible body-part slapstick, separated into editable lobes.
c = add('juggle-body','Some assembly not required','Mischief',2.4,'Tosses its own two brain cheeks in counterphase while its face hangs smugly in midair','Shenaniganing','high',split=True)
c.anim('.lobe-left',2.4,{'0%,100%':'transform:translate(0,0) rotate(0);','25%':'transform:translate(-34px,-92px) rotate(-18deg);','50%':'transform:translate(0,0) rotate(0);','75%':'transform:translate(8px,14px) rotate(5deg);'})
c.anim('.lobe-right',2.4,{'0%,100%':'transform:translate(30px,-90px) rotate(18deg);','25%':'transform:translate(0,0) rotate(0);','50%':'transform:translate(-8px,14px) rotate(-5deg);','75%':'transform:translate(0,0) rotate(0);'})
c.anim('.rig-left-arm',1.2,{'0%,100%':'transform:rotate(-80deg);','50%':'transform:rotate(-125deg);'})
c.anim('.rig-right-arm',1.2,{'0%,100%':'transform:rotate(125deg);','50%':'transform:rotate(80deg);'})
c.anim('.rig-glasses',2.4,{'0%,100%':'transform:rotate(-3deg) translateY(-4px);','50%':'transform:rotate(3deg) translateY(4px);'})
c.front += star(78,112,13,YELLOW,'fx-a')+star(650,100,15,PURPLE,'fx-b')
c.anim('.fx-a',1.2,{'0%,100%':'opacity:.1;','50%':'opacity:.8;'})
c.anim('.fx-b',1.2,{'0%,100%':'opacity:.8;','50%':'opacity:.1;'})

# 31: actual one-shot entrance, not an endlessly exploding loading state.
c = add('assemble','Thrown together','Special',2.8,'Brain cheeks, arms, legs, shoes, and sunglasses fly in from different directions and settle into the original mascot','Getting started','high',loop=False,split=True)
c.anim('.lobe-left',2.8,{'0%':'transform:translate(-670px,-340px) rotate(-155deg);','37%':'transform:translate(25px,7px) rotate(8deg);','49%':'transform:translate(-9px,-3px) rotate(-3deg);','61%,100%':'transform:translate(0,0) rotate(0);'})
c.anim('.lobe-right',2.8,{'0%,10%':'transform:translate(650px,-300px) rotate(160deg);','48%':'transform:translate(-24px,9px) rotate(-8deg);','61%':'transform:translate(8px,-3px) rotate(3deg);','72%,100%':'transform:translate(0,0) rotate(0);'})
c.anim('.rig-left-leg',2.8,{'0%':'transform:translate(-80px,550px) rotate(100deg);','38%':'transform:translate(0,-12px) rotate(-6deg);','53%,100%':'transform:translate(0,0) rotate(0);'})
c.anim('.rig-right-leg',2.8,{'0%,12%':'transform:translate(90px,550px) rotate(-100deg);','48%':'transform:translate(0,-12px) rotate(6deg);','63%,100%':'transform:translate(0,0) rotate(0);'})
c.anim('.rig-shoe-left',2.8,{'0%,12%':'transform:translate(-580px,-540px) rotate(-650deg);','56%':'transform:translate(6px,9px) rotate(12deg);','72%,100%':'transform:translate(0,0) rotate(0);'})
c.anim('.rig-shoe-right',2.8,{'0%,20%':'transform:translate(580px,-540px) rotate(650deg);','64%':'transform:translate(-6px,9px) rotate(-12deg);','78%,100%':'transform:translate(0,0) rotate(0);'})
c.anim('.rig-left-arm',2.8,{'0%,15%':'transform:translate(-600px,190px) rotate(-190deg);','57%':'transform:translate(8px,0) rotate(14deg);','70%,100%':'transform:translate(0,0) rotate(0);'})
c.anim('.rig-right-arm',2.8,{'0%,23%':'transform:translate(600px,190px) rotate(190deg);','64%':'transform:translate(-8px,0) rotate(-14deg);','78%,100%':'transform:translate(0,0) rotate(0);'})
c.anim('.rig-glasses',2.8,{'0%,52%':'transform:translate(0,-650px) rotate(-85deg);','77%':'transform:translate(0,13px) rotate(6deg);','88%':'transform:translate(0,-5px) rotate(-2deg);','100%':'transform:translate(0,0) rotate(0);'})
c.anim('.rig-mouth',2.8,{'0%,60%':'opacity:0;','73%,100%':'opacity:1;'})
c.anim('.rig-root',2.8,{'0%,69%':'transform:scale(1);','78%':'transform:scale(1.025,.98);','90%':'transform:scale(.99,1.01);','100%':'transform:scale(1);'})
c.anim('.rig-ground',2.8,{'0%,25%':'opacity:0;','60%,100%':'opacity:.065;'})
c.front += star(95,210,18,YELLOW,'fx-flash')+star(649,205,20,PURPLE,'fx-flash')
c.anim('.fx-flash',2.8,{'0%,70%,100%':'opacity:0;','82%':'opacity:.8;'})
c.style('.fx-flash','opacity:0;')

# 32: the foreground hole occludes the mascot while it ducks into it.
c = add('tunnel','Down the rabbit hole','Travel',3.2,'Ducks into a little hole, peeks out, and resurfaces with its dignity mostly intact','Burrowing','medium')
c.back += '<ellipse cx="356" cy="654" rx="211" ry="34" fill="#D9CCDF"/>'
c.front += '<path d="M151 657 Q356 711 561 657" stroke="#C2AED2" stroke-width="9" stroke-linecap="round"/>'
c.anim('.rig-root',3.2,{'0%,100%':'transform:translateY(0) scale(1);','38%,57%':'transform:translateY(340px) scale(.87);','71%':'transform:translateY(230px) scale(.92);','87%':'transform:translateY(-15px) scale(1);'})
c.anim('.rig-left-arm',3.2,{'0%,100%':'transform:rotate(-18deg);','40%,65%':'transform:rotate(-140deg);'})
c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(18deg);','40%,65%':'transform:rotate(140deg);'})
c.style('.rig-ground','opacity:0;')

# 33: use anticipation -> launch -> re-entry, rather than flashing strobing effects.
c = add('warp','Taking a shortcut','Travel',2.4,'Crouches, zips diagonally through a soft portal, then re-enters from the opposite side','Hyperspacing','high')
c.anim('.rig-root',2.4,{'0%,100%':'transform:translate(0,0) scale(1);opacity:1;','20%':'transform:translate(-14px,9px) scale(1.03,.94);opacity:1;','42%':'transform:translate(370px,-360px) scale(.55,.7) rotate(18deg);opacity:0;','43%':'transform:translate(-370px,240px) scale(.55,.7) rotate(-18deg);opacity:0;','68%':'transform:translate(0,-14px) scale(.98,1.03);opacity:1;','83%':'transform:translate(0,5px) scale(1.02,.98);opacity:1;'})
c.back += '<g class="fx-portal"><ellipse cx="560" cy="210" rx="94" ry="141" stroke="#C3AED4" stroke-width="9" transform="rotate(34 560 210)"/><ellipse cx="560" cy="210" rx="76" ry="121" stroke="#E0D5E9" stroke-width="5" transform="rotate(34 560 210)"/></g>'
c.anim('.fx-portal',2.4,{'0%,100%':'opacity:0;','23%,53%':'opacity:.65;','73%':'opacity:0;'})
c.anim('.rig-left-arm',2.4,{'0%,100%':'transform:rotate(0);','30%,62%':'transform:rotate(-145deg);'})
c.anim('.rig-right-arm',2.4,{'0%,100%':'transform:rotate(0);','30%,62%':'transform:rotate(145deg);'})

# 34: unwinds and winds a visible spring-like ribbon.
c = add('unwind','Untangling the situation','Making',3,'Pulls a looping ribbon between its hands, unravels it, then winds it back','Unravelling','medium')
c.anim('.rig-left-arm',3,{'0%,100%':'transform:rotate(-86deg);','50%':'transform:rotate(-44deg);'})
c.anim('.rig-right-arm',3,{'0%,100%':'transform:rotate(86deg);','50%':'transform:rotate(44deg);'})
c.front += '<g class="prop-ribbon"><path d="M247 436 C269 392 286 478 307 436 S345 478 366 436 S404 478 425 436 S464 478 485 436" stroke="#8C6AA7" stroke-width="8" stroke-linecap="round"/><circle cx="247" cy="436" r="10" fill="#D7C8E2"/><circle cx="485" cy="436" r="10" fill="#D7C8E2"/></g>'
c.style('.prop-ribbon','transform-origin:366px 436px;')
c.anim('.prop-ribbon',3,{'0%,100%':'transform:scale(1,1);','50%':'transform:scale(1.67,.25) translateY(110px);'})
c.anim('.rig-head',3,{'0%,100%':'transform:rotate(-3deg);','50%':'transform:rotate(3deg);'})

# 35: restrained babbling and a conversational hand gesture.
c = add('talk','Making a very good point','Mischief',2.4,'Babbling mouth shapes, an opinionated hand gesture, and three tiny speech dots','Bloviating','medium')
c.open_mouth = True
c.anim('.rig-mouth',.48,{'0%,100%':'transform:scale(1,.35);','45%':'transform:scale(.8,1);','70%':'transform:scale(1.15,.6);'})
c.anim('.rig-right-arm',2.4,{'0%,100%':'transform:rotate(25deg);','25%':'transform:rotate(77deg);','55%':'transform:rotate(42deg);','78%':'transform:rotate(88deg);'})
c.anim('.rig-head',2.4,{'0%,100%':'transform:rotate(-2deg);','50%':'transform:rotate(4deg);'})
c.back += '<path d="M590 96 H676 Q696 96 696 116 V154 Q696 174 676 174 H626 L598 192 L603 174 H590 Q570 174 570 154 V116 Q570 96 590 96Z" fill="#F0E8F4" stroke="#C8B5D7" stroke-width="4"/>'
for i,x in enumerate([603,633,663]):
    c.back += dot(x,136,7,PURPLE,f'fx-talk-{i}')
    c.anim(f'.fx-talk-{i}',1.2,{'0%,100%':'opacity:.2;transform:translateY(0);','35%':'opacity:1;transform:translateY(-5px);'},delay=-i*.2)

# 36: full upside-down turn with leg/arm lag; no abrupt flip.
c = add('topsy','Head over heels','Mischief',3.2,'A slow upside-down cartwheel with dangling limbs and a very late glasses wobble','Topsy-turvying','high')
c.style('.rig-root','transform-origin:356px 380px;')
c.anim('.rig-root',3.2,{'0%':'transform:rotate(0) scale(.84);','35%,57%':'transform:rotate(180deg) scale(.84);','100%':'transform:rotate(360deg) scale(.84);'})
c.anim('.rig-left-arm',3.2,{'0%,100%':'transform:rotate(0);','40%,55%':'transform:rotate(-125deg);'})
c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(0);','40%,55%':'transform:rotate(125deg);'})
c.anim('.rig-left-leg',3.2,{'0%,100%':'transform:rotate(0);','40%,55%':'transform:rotate(25deg);'})
c.anim('.rig-right-leg',3.2,{'0%,100%':'transform:rotate(0);','40%,55%':'transform:rotate(-25deg);'})
c.anim('.rig-glasses',3.2,{'0%,100%':'transform:translateY(0) rotate(0);','40%,55%':'transform:translateY(-18px) rotate(5deg);'})

WORDS = '''Accomplishing
Actioning
Actualizing
Architecting
Baking
Beaming
Beboppin'
Befuddling
Billowing
Blanching
Bloviating
Boogieing
Boondoggling
Booping
Bootstrapping
Brewing
Bunning
Burrowing
Calculating
Canoodling
Caramelizing
Cascading
Catapulting
Cerebrating
Channeling
Channelling
Choreographing
Churning
Clauding
Coalescing
Cogitating
Combobulating
Composing
Computing
Concocting
Considering
Contemplating
Cooking
Crafting
Creating
Crunching
Crystallizing
Cultivating
Deciphering
Deliberating
Determining
Dilly-dallying
Discombobulating
Doing
Doodling
Drizzling
Ebbing
Effecting
Elucidating
Embellishing
Enchanting
Envisioning
Evaporating
Fermenting
Fiddle-faddling
Finagling
Flambéing
Flibbertigibbeting
Flowing
Flummoxing
Fluttering
Forging
Forming
Frolicking
Frosting
Gallivanting
Galloping
Garnishing
Generating
Gesticulating
Germinating
Gitifying
Grooving
Gusting
Harmonizing
Hashing
Hatching
Herding
Honking
Hullaballooing
Hyperspacing
Ideating
Imagining
Improvising
Incubating
Inferring
Infusing
Ionizing
Jitterbugging
Julienning
Kneading
Leavening
Levitating
Lollygagging
Manifesting
Marinating
Meandering
Metamorphosing
Misting
Moonwalking
Moseying
Mulling
Mustering
Musing
Nebulizing
Nesting
Newspapering
Noodling
Nucleating
Orbiting
Orchestrating
Osmosing
Perambulating
Percolating
Perusing
Philosophising
Photosynthesizing
Pollinating
Pondering
Pontificating
Pouncing
Precipitating
Prestidigitating
Processing
Proofing
Propagating
Puttering
Puzzling
Quantumizing
Razzle-dazzling
Razzmatazzing
Recombobulating
Reticulating
Roosting
Ruminating
Sautéing
Scampering
Schlepping
Scurrying
Seasoning
Shenaniganing
Shimmying
Simmering
Skedaddling
Sketching
Slithering
Smooshing
Sock-hopping
Spelunking
Spinning
Sprouting
Stewing
Sublimating
Swirling
Swooping
Symbioting
Synthesizing
Tempering
Thinking
Thundering
Tinkering
Tomfoolering
Topsy-turvying
Transfiguring
Transmuting
Twisting
Undulating
Unfurling
Unravelling
Vibing
Waddling
Wandering
Warping
Whatchamacalliting
Whirlpooling
Whirring
Whisking
Wibbling
Working
Wrangling
Zesting
Zigzagging'''.splitlines()

ASSIGNMENTS = {
'idle': 'Dilly-dallying|Lollygagging|Moseying',
'think': 'Cerebrating|Cogitating|Considering|Contemplating|Deliberating|Mulling|Musing|Philosophising|Pondering|Ruminating|Thinking',
'eye-roll': 'Befuddling|Discombobulating|Flummoxing|Puzzling',
'compute': 'Calculating|Computing|Crunching|Deciphering|Determining|Hashing|Inferring|Processing',
'type': 'Accomplishing|Actioning|Bootstrapping|Clauding|Doing|Effecting|Gitifying|Working',
'sketch': 'Creating|Doodling|Embellishing|Sketching',
'read': 'Newspapering|Perusing',
'architect': 'Architecting|Choreographing|Composing|Orchestrating|Reticulating',
'idea': 'Actualizing|Elucidating|Envisioning|Generating|Ideating|Imagining|Manifesting',
'stir': 'Brewing|Concocting|Cooking|Fermenting|Infusing|Marinating|Noodling|Percolating|Simmering|Stewing',
'whisk': 'Drizzling|Flambéing|Garnishing|Julienning|Sautéing|Seasoning|Whisking|Zesting',
'bake': 'Baking|Blanching|Bunning|Caramelizing|Frosting|Kneading|Leavening|Proofing',
'shimmy': "Beboppin'|Boogieing|Grooving|Harmonizing|Jitterbugging|Shimmying|Vibing",
'wiggle': 'Slithering|Smooshing|Twisting|Undulating|Wibbling',
'moonwalk': 'Moonwalking|Sock-hopping',
'chaos': 'Flibbertigibbeting|Frolicking|Gallivanting|Hullaballooing|Razzmatazzing|Tomfoolering',
'waddle': 'Meandering|Perambulating|Puttering|Schlepping|Waddling|Wandering',
'run': 'Galloping|Herding|Pouncing|Scampering|Scurrying|Skedaddling|Wrangling',
'spin': 'Orbiting|Spinning|Swirling|Whirlpooling|Whirring|Quantumizing',
'float': 'Channeling|Channelling|Ebbing|Flowing|Levitating|Osmosing|Symbioting',
'gust': 'Billowing|Cascading|Fluttering|Gusting|Precipitating|Thundering',
'grow': 'Cultivating|Germinating|Hatching|Incubating|Nesting|Photosynthesizing|Pollinating|Propagating|Roosting|Sprouting',
'forge': 'Boondoggling|Crafting|Forging|Tempering|Tinkering',
'transform': 'Coalescing|Combobulating|Crystallizing|Forming|Metamorphosing|Nucleating|Recombobulating|Synthesizing|Transfiguring|Transmuting',
'dissolve': 'Evaporating|Ionizing|Misting|Nebulizing|Sublimating',
'sparkle': 'Beaming|Enchanting|Prestidigitating|Razzle-dazzling',
'boop': 'Booping|Canoodling',
'juggle-shoes': 'Fiddle-faddling',
'juggle-glasses': 'Finagling|Improvising',
'juggle-body': 'Shenaniganing',
'assemble': '',
'tunnel': 'Burrowing|Spelunking',
'warp': 'Catapulting|Hyperspacing|Swooping|Warping|Zigzagging',
'unwind': 'Churning|Mustering|Unfurling|Unravelling',
'talk': 'Bloviating|Gesticulating|Honking|Pontificating|Whatchamacalliting',
'topsy': 'Topsy-turvying',
}
status_map = {}
for motion, group in ASSIGNMENTS.items():
    for word in group.split('|'):
        if not word:
            continue
        assert word not in status_map, f'Duplicate mapping: {word}'
        status_map[word] = motion
assert len(WORDS) == 187, len(WORDS)
assert set(WORDS) == set(status_map), f'Missing={set(WORDS)-set(status_map)}; Extra={set(status_map)-set(WORDS)}'
assert len(clips) == 36

# Preserve the original 187 default mappings and append an additive second volume.
original_words = list(WORDS)
original_status = {w:status_map[w] for w in original_words}
from volume2 import register as register_volume2
new_clips = register_volume2(add, star, dot)
for c in new_clips:
    for word in c.added_words:
        assert word not in status_map, f'Duplicate expansion word: {word}'
        WORDS.append(word)
        status_map[word] = c.slug
    assert set(c.suggested_words).issubset(original_status), c.suggested_words
assert len(clips) == 60
assert len(WORDS) == len(status_map) == 259

# Variant zero is ALWAYS the original default. More takes are opt-in and deterministic.
variant_map = {w:[status_map[w]] for w in WORDS}
for c in new_clips:
    for word in c.suggested_words:
        if c.slug not in variant_map[word]:
            variant_map[word].append(c.slug)
    related = list(dict.fromkeys(original_status[w] for w in c.suggested_words))
    for word in c.added_words:
        variant_map[word].extend(m for m in related if m != c.slug)

manifest = []
artwork = {}
for i,c in enumerate(clips,1):
    svg = c.render()
    ET.fromstring(svg)
    (ROOT / 'svg' / (c.slug+'.svg')).write_text(svg)
    artwork[c.slug] = svg
    manifest.append({'id':c.slug,'index':i,'name':c.label,'category':c.category,'duration':c.duration,'loop':c.loop,'energy':c.energy,'description':c.description,'defaultWord':c.word,'words':[w for w in WORDS if status_map[w]==c.slug],'file':f'svg/{c.slug}.svg','viewBox':'0 0 740 740','volume':getattr(c,'volume',1),'suggestedFor':getattr(c,'suggested_words',[])})

# The dedicated 96px loader is deliberately simplified, not a full mascot crushed to 24px.
compact = '''<svg xmlns="http://www.w3.org/2000/svg" id="ob-loader" viewBox="0 0 96 96" width="96" height="96" fill="none" role="img" aria-labelledby="ob-loader-title ob-loader-desc"><title id="ob-loader-title">Oddbrain eye-roll loader</title><desc id="ob-loader-desc">A small pink brain with raised glasses and two orbiting pupils. Transparent, looping, and reduced-motion aware.</desc><style>#ob-loader .pupil-a,#ob-loader .pupil-b{transform-box:view-box;animation:ob-loader-orbit calc(1.2s * var(--duration-scale,1)) linear infinite;animation-play-state:var(--play-state,running)}#ob-loader .pupil-a{transform-origin:34px 54px}#ob-loader .pupil-b{transform-origin:62px 54px}@keyframes ob-loader-orbit{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){#ob-loader *{animation:none!important}}</style><path d="M48 21 C39 9 24 13 16 23 C4 38 5 65 18 77 C27 86 41 85 48 75 C55 85 69 86 78 77 C91 65 92 38 80 23 C72 13 57 9 48 21Z" fill="#FFAFB8"/><path d="M48 21q-6 8-3 16m4 29q3 8-1 13M22 31q-8 4-6 13m63-13q6 5 4 14M17 61q-5 9 4 11m58-11q5 9-4 11" stroke="#EE818D" stroke-width="3" stroke-linecap="round"/><g transform="rotate(-6 48 30)"><path d="M22 26h21l-2 11H26Zm31 0h21l-4 11H55Z" fill="#263039" stroke="#222625" stroke-width="4" stroke-linejoin="round"/><path d="M43 28h10m-31-1-5 1m57-1 5 2" stroke="#222625" stroke-width="4" stroke-linecap="round"/></g><circle cx="34" cy="54" r="10" fill="#FFF9F1" stroke="#393A35" stroke-width="2.5"/><circle cx="62" cy="54" r="10" fill="#FFF9F1" stroke="#393A35" stroke-width="2.5"/><g class="pupil-a"><circle cx="34" cy="50" r="4" fill="#393A35"/></g><g class="pupil-b"><circle cx="62" cy="50" r="4" fill="#393A35"/></g><path d="M43 69q7 4 13-2" stroke="#393A35" stroke-width="2.5" stroke-linecap="round"/></svg>'''
ET.fromstring(compact)
(ROOT/'svg/loader-eye-roll.svg').write_text(compact)
artwork['loader-eye-roll'] = compact
meta = {'name':'Oddbrain Motion Kit','version':'2.0.0','motionCount':len(clips),'newMotionCount':24,'utilityCount':1,'statusCount':len(WORDS),'originalStatusCount':187,'additionalStatusCount':72,'motions':manifest,'utilities':[{'id':'loader-eye-roll','file':'svg/loader-eye-roll.svg','viewBox':'0 0 96 96','recommendedSize':{'min':24,'max':64},'duration':1.2}]}
(ROOT/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
(ROOT/'status-map.json').write_text(json.dumps({w:status_map[w] for w in WORDS},ensure_ascii=False,indent=2))
(ROOT/'status-map-original.json').write_text(json.dumps(original_status,ensure_ascii=False,indent=2))
(ROOT/'status-variants.json').write_text(json.dumps(variant_map,ensure_ascii=False,indent=2))
(ROOT/'source/gallery-data.json').write_text(json.dumps({'motions':manifest,'statusMap':{w:status_map[w] for w in WORDS},'variantMap':variant_map,'manifest':meta,'artwork':artwork},ensure_ascii=False))
(ROOT/'react/motion-data.ts').write_text('// Generated by source/build.py. Trusted local SVG markup; no remote HTML.\nexport const motionSvg = '+json.dumps(artwork,ensure_ascii=False)+' as const;\n\nexport type MotionId = keyof typeof motionSvg;\n')
(ROOT/'react/status-map.ts').write_text('// Lightweight word registry. Original 187 defaults preserved.\nexport const statusToMotion = '+json.dumps({w:status_map[w] for w in WORDS},ensure_ascii=False,indent=2)+' as const;\n\nexport type FullMotionId = '+ ' | '.join(json.dumps(c.slug) for c in clips) + ';\n')
(ROOT/'react/status-variants.ts').write_text('// Opt-in alternate takes. Index zero is always the canonical default.\nexport const statusVariants = '+json.dumps(variant_map,ensure_ascii=False,indent=2)+' as const;\n')
(ROOT/'react/motion-meta.ts').write_text('// Generated motion metadata.\nexport const motions = '+json.dumps(manifest,ensure_ascii=False,indent=2)+' as const;\n')
print(f'Built {len(clips)} full SVG motions + compact loader. Preserved 187 original defaults; added 72 words and 24 motions.')
