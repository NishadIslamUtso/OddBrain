#!/usr/bin/env python3
"""Validate both volumes, SVG references, registry compatibility, and opt-in variants."""
from pathlib import Path
import json, re, hashlib
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'manifest.json').read_text())
status_map=json.loads((root/'status-map.json').read_text())
original=json.loads((root/'status-map-original.json').read_text())
variants=json.loads((root/'status-variants.json').read_text())
baseline=json.loads((root/'source/v1-baseline.json').read_text())
assert manifest['motionCount']==60
assert manifest['newMotionCount']==24
assert manifest['statusCount']==len(status_map)==259
assert manifest['originalStatusCount']==len(original)==187
assert manifest['additionalStatusCount']==len(status_map)-len(original)==72
assert original==baseline['statusMap']
assert all(status_map[word]==motion for word,motion in original.items())
ids={m['id'] for m in manifest['motions']}
assert len(ids)==60
assert sum(m['volume']==2 for m in manifest['motions'])==24
assert sum(not m['loop'] for m in manifest['motions'])==1
assert next(m for m in manifest['motions'] if not m['loop'])['id']=='assemble'
assert set(status_map.values())==ids-{'assemble'}
for m in manifest['motions']:
    assert set(m['words'])=={w for w,slug in status_map.items() if slug==m['id']}
    assert set(m['suggestedFor']).issubset(original)
assert set(variants)==set(status_map)
for word,pool in variants.items():
    assert pool and len(pool)==len(set(pool))
    assert pool[0]==status_map[word]
    assert set(pool).issubset(ids-{'assemble'})

files=list((root/'svg').glob('*.svg'))
assert len(files)==61
animations=0
for file in files:
    text=file.read_text()
    doc=ET.fromstring(text)
    local_ids=[e.get('id') for e in doc.iter() if e.get('id')]
    assert len(local_ids)==len(set(local_ids)), f'Duplicate IDs: {file.name}'
    for ref in re.findall(r'(?:href="#|url\(#)([a-zA-Z0-9_-]+)',text):
        assert ref in local_ids, f'Broken reference {ref} in {file.name}'
    assert 'prefers-reduced-motion' in text
    assert '<script' not in text and '<image' not in text
    assert not re.search(r'(?:href|src)="https?://',text)
    assert '<style>' in text and '@keyframes' in text
    animations+=text.count('@keyframes')
for name,digest in baseline['hashes'].items():
    data=(root/'svg'/name).read_text()
    # Only this deliberate specificity fix is allowed in the original files.
    # Without !important, each layer's animation shorthand overrode the pause state.
    data=data.replace('animation-play-state:var(--play-state,running)!important;', 'animation-play-state:var(--play-state,running);')
    actual=hashlib.sha256(data.encode()).hexdigest()
    assert actual==digest, f'Original V1 artwork/keyframes changed: {name}'
assert '__MOTION_TABLE__' not in (root/'README.md').read_text()
assert '__DATA__</script>' not in (root/'index.html').read_text()
print(f'PASS: {len(files)} standalone SVGs, {animations} scoped sequences, {len(status_map)} words, opt-in variants.')
print('PASS: all 37 original art/keyframe definitions are preserved (only playback CSS was fixed); all 187 original defaults are unchanged.')
