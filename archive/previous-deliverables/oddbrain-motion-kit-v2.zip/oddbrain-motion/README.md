# Oddbrain Motion Kit — Volume 02

Your pink butt-brain mascot, with even less dignity. “Oddbrain” is just a working label; rename it for your app.

**60 full-character motions + 1 compact loader · 24 new loops · 259 status words (187 original + 72 new) · no animation runtime**

## Open the gallery

Open **index.html** in a modern browser. It is fully self-contained: no install, network, CDN, external font, or server required.

- **New** shows the 24 Volume 02 loops. **All** shows all 60 motions.
- Search by a motion name, word, or suggested use.
- Pause, replay, change speed, and check cream/dark/checkerboard backgrounds.
- Export one SVG or download the entire kit, including React integration.
- Enter a word and select **Another take** to try its optional variants.
- The complete 259-word registry is visible at the bottom.

The physical-comedy language stays the same: delayed sunglasses, tiny feet, independently wobbling brain cheeks, and overconfident hand gestures. No costume or third-party character artwork is added.

## What is new

See **VOLUME-02.md** for the full 24-motion index. A few highlights:

- `shoe-skateboard`: one purple shoe becomes the skateboard; the other foot pushes.
- `brain-kickflip`: tosses and flips its own brain-head above two patient legs.
- `sneeze`: anticipation, sneeze, flying sunglasses, embarrassed recovery.
- `pocket-panic`: checks its cheeks for pockets, then remembers it has no outfit.
- `shoe-phone`: holds its own shoe to its ear and confidently offers bad advice.
- `cheek-drums`: its own brain cheeks become bongos.
- `glasses-clean`, `noodle-slurp`, `nap`, `stretch`, `sneak`, `peekaboo`.
- `balloon-brain`, `hula-hoop`, `tap-dance`, `cancan`, `ribbon`, `magnet`.
- `bubbles`, `wind-up`, `accordion`, `confetti`, `hammock`, `shoe-vortex`.

**Compatibility:** all original artwork, motion keyframes, and 187 default word mappings are preserved. Volume 02 adds 24 SVGs, 72 new words, and opt-in alternate takes. It also fixes a CSS-specificity issue in the original full-character files so Pause actually freezes every animated limb; this is the only change to their SVG source. The original V1 archive is retained separately.

## Original extras are still here

| Moment | SVG | Behavior |
|---|---|---|
| Weird dancing | `shimmy`, `wiggle`, `chaos`, `moonwalk` | Independently animated arms, legs, cheeks, and glasses. |
| Shoe / glasses / body juggling | `juggle-shoes`, `juggle-glasses`, `juggle-body` | Actual detachable accessories and brain halves. |
| Startup entrance | `assemble` | Pieces fly in from different directions. **Plays once in 2.8 seconds and stays assembled.** |
| Confused loading | `eye-roll` | Raised sunglasses, orbiting pupils, and soft vector haze. |
| Small loading icon | `loader-eye-roll` | Simplified 96×96 SVG, intended for **24–64px** display. |

The full character is most readable at **80px+**; prop-heavy scenes benefit from **120px+**. Use the compact loader for small chat indicators rather than crushing every wrinkle into a 24px icon.

## Files

```
index.html                 Offline interactive gallery (starts on New)
svg/                       60 character SVGs + compact loader
manifest.json              Metadata, timing, volume, words, suggested uses
status-map.json            259 canonical word → motion mappings
status-map-original.json   The unchanged original 187 defaults
status-variants.json       Opt-in pools; first item is always the canonical default
VOLUME-02.md                Expansion guide and all 24 new motion IDs
react/
  Oddbrain.tsx              Inline React / TypeScript component
  Oddbrain.css              Sizing / accessibility styles
  motion-data.ts            Generated trusted SVG markup
  status-map.ts             Lightweight typed canonical registry
  status-variants.ts        Lightweight typed variant registry
  resolve-motion.ts         Normalization, resolution, variants, static asset URLs
  motion-meta.ts            Typed metadata
  Examples.tsx              Chat / loader / entrance / variant examples
source/
  original-mascot.svg       Your original SVG, preserved
  build.py                  Original rig, 36 original clips, build/export logic
  volume2.py                24 new editable loops and their new/suggested words
  gallery.template.html    Editable gallery
  build_gallery.py         Embeds the gallery and refreshes this motion index
  validate.py               Validates all assets, mappings, and V1 preservation
  v1-baseline.json          Hashes and canonical mappings for compatibility checks
```

## Simplest integration: external SVG

Copy `svg/` to `public/oddbrain/` in your app:

```html
<img src="/oddbrain/shoe-skateboard.svg" width="120" height="120" alt="" />
<span role="status">Coasting…</span>

<img src="/oddbrain/loader-eye-roll.svg" width="32" height="32" alt="Loading" />

<!-- Plays once. Re-create the element to replay. -->
<img src="/oddbrain/assemble.svg" width="260" height="260"
     alt="A brain mascot assembling itself" />
```

Every SVG embeds its own vector art, CSS keyframes, gradients, clipping, and reduced-motion rules. No JavaScript is required for the animation itself. No raster textures, generated images, animation sprites, or external assets are used.

For word-driven URLs without bundling SVG strings:

```tsx
import { motionSrc } from './oddbrain/resolve-motion';

<img src={motionSrc('Brewing')} width={80} height={80} alt="" />
// /oddbrain/stir.svg — original default

<img src={motionSrc('Befuddling', '/oddbrain', 1)}
     width={100} height={100} alt="" />
// /oddbrain/pocket-panic.svg — opt-in alternate
```

Import the helper directly from `resolve-motion.ts` for this lightweight route, not from the inline renderer. Serve the SVG files separately.

## React / TypeScript

Copy `react/` into your app. React 18+ is the only UI dependency. No GSAP, Lottie, or Framer Motion is needed.

```tsx
import { Oddbrain, OddbrainLoader } from './oddbrain/Oddbrain';

<Oddbrain word="Brewing" size={80} />
<Oddbrain word="Befuddling" variant={1} size={120} />
<Oddbrain motion="shoe-skateboard" size={160} />
<Oddbrain motion="cheek-drums" size={160} speed={0.75} />
<Oddbrain motion="hammock" size={180} paused={false} />
<OddbrainLoader size={32} label="Loading" />
<Oddbrain motion="assemble" size={260} replayKey={0} />
```

- `motion` overrides word/variant resolution.
- `variant={0}` is the default and always preserves the canonical mapping.
- Change `replayKey` to restart a one-shot entrance.
- Changing words within the same shared motion does not restart it unnecessarily.
- All SVG IDs, gradients, clip paths, CSS selectors, and keyframe names are re-prefixed per instance. Multiple copies safely coexist.
- Only trusted checked-in SVG markup is injected; never interpolate untrusted HTML.

### Alternate takes

```ts
import {
  resolveMotion, motionVariants, resolveMotionVariant
} from './oddbrain/resolve-motion';

resolveMotion('Befuddling');           // 'eye-roll' — unchanged
motionVariants('Befuddling');          // ['eye-roll', 'pocket-panic']
resolveMotionVariant('Befuddling', 1); // 'pocket-panic'
resolveMotionVariant('Befuddling', 2); // 'eye-roll' — wraps around
```

Pick an index **once per task/request**, not on every render. Resolution is deterministic, so there is no random server/client hydration mismatch. Negative indices wrap; non-finite indices use zero. Unknown words safely fall back to `think`.

Normalization ignores case, accents, punctuation, and trailing ellipses. `Sautéing…` and `sauteing` select the same canonical loop. Add custom words to your copied registry, or edit `WORDS` / `ASSIGNMENTS` in `build.py` and the per-clip `added_words` / `suggested_words` in `volume2.py`. Update the validation counts when extending beyond this release.

### Accessibility and timing

- Every SVG honors `prefers-reduced-motion: reduce` and becomes a useful still pose. The entrance remains fully assembled; peekaboo remains visibly peeking.
- The inline mascot is decorative by default. Pair it with visible status text, or give it a `label` if used alone.
- Do not announce every whimsical word repeatedly; put meaningful progress in a separate status region.
- The compact loader defaults to “Loading”; pass `label=""` when adjacent text already supplies that meaning.

Inline SVG supports inherited custom properties:

```css
.my-mascot {
  --duration-scale: 1.5; /* 1.5× duration = slower */
  --play-state: paused; /* running | paused */
}
```

These variables do not cross into an external `<img>`. Use the inline component for live speed/pause controls. The gallery's SVG export bakes in the selected speed.

**CSP:** the inline component embeds trusted SVG styles. For strict `style-src` policies, prefer the external `<img>` route or adapt the styles to your CSP.

## Editing and rebuilding

Both volumes use the same editable rig (`rig-head`, arms, legs, shoes, glasses, independent cheeks), plus vector props. The full-character viewBox is `0 0 740 740`; the compact loader is `0 0 96 96`. Timing is all CSS. The gallery's JavaScript only selects, exports, and pauses clips; it does not drive frame-by-frame animation.

```sh
python source/build.py
python source/build_gallery.py
python source/validate.py
```

Only Python's standard library is needed. React integration is type-checked and browser-rendered during QA. Browser/gallery controls, transparent backgrounds, external SVG animation, reduced-motion poses, and original-file preservation are also checked.

## Motion index

“Main beat” is the headline timing; secondary limbs/particles may have shorter or staggered cycles. Volume 01 has 35 loops + one entrance. Volume 02 adds 24 loops.

<!-- MOTION_TABLE_START -->
| # | ID | Motion | Category | Main beat | Volume | Words |
|---|---|---|---|---|---|---|
| 01 | `idle` | Quiet mischief | Thinking | 3.2s | 01 | 3 |
| 02 | `think` | Deep-ish thought | Thinking | 2.8s | 01 | 11 |
| 03 | `eye-roll` | Buffering upstairs | Thinking | 1.5s | 01 | 4 |
| 04 | `compute` | Number crunch | Thinking | 2.2s | 01 | 8 |
| 05 | `type` | Tiny power user | Making | 1.2s | 01 | 8 |
| 06 | `sketch` | Doodle mode | Making | 2.8s | 01 | 4 |
| 07 | `read` | Very important news | Thinking | 3.4s | 01 | 2 |
| 08 | `architect` | Questionable architecture | Making | 3.2s | 01 | 5 |
| 09 | `idea` | A suspiciously good idea | Thinking | 2.6s | 01 | 7 |
| 10 | `stir` | Let it cook | Cooking | 2.4s | 01 | 10 |
| 11 | `whisk` | Aggressively delicious | Cooking | 0.8s | 01 | 8 |
| 12 | `bake` | Proof of genius | Cooking | 2.8s | 01 | 8 |
| 13 | `shimmy` | The extremely unnecessary shimmy | Dancing | 1.2s | 01 | 7 |
| 14 | `wiggle` | Certified cheek wobble | Dancing | 1.6s | 01 | 5 |
| 15 | `moonwalk` | Absolutely going nowhere | Dancing | 2.4s | 01 | 2 |
| 16 | `chaos` | No bones, no rules | Dancing | 1.6s | 01 | 6 |
| 17 | `waddle` | On a very small mission | Travel | 1.8s | 01 | 6 |
| 18 | `run` | Late for absolutely nothing | Travel | 0.72s | 01 | 7 |
| 19 | `spin` | One brain, zero bearings | Magic | 2.4s | 01 | 6 |
| 20 | `float` | Zero-gravity daydream | Magic | 3.6s | 01 | 7 |
| 21 | `gust` | A little winded | Magic | 2.4s | 01 | 6 |
| 22 | `grow` | A thought takes root | Making | 3.6s | 01 | 10 |
| 23 | `forge` | Tiny tinkerer | Making | 1.8s | 01 | 5 |
| 24 | `transform` | Getting it together | Magic | 3.2s | 01 | 10 |
| 25 | `dissolve` | Slightly less corporeal | Magic | 3.2s | 01 | 5 |
| 26 | `sparkle` | Unlicensed wizardry | Magic | 2.2s | 01 | 4 |
| 27 | `boop` | A highly professional boop | Mischief | 2s | 01 | 2 |
| 28 | `juggle-shoes` | Shoes are optional | Mischief | 2.8s | 01 | 1 |
| 29 | `juggle-glasses` | Optical nonsense | Mischief | 2.8s | 01 | 2 |
| 30 | `juggle-body` | Some assembly not required | Mischief | 2.4s | 01 | 1 |
| 31 | `assemble` | Thrown together | Special | 2.8s once | 01 | 0 |
| 32 | `tunnel` | Down the rabbit hole | Travel | 3.2s | 01 | 2 |
| 33 | `warp` | Taking a shortcut | Travel | 2.4s | 01 | 5 |
| 34 | `unwind` | Untangling the situation | Making | 3s | 01 | 4 |
| 35 | `talk` | Making a very good point | Mischief | 2.4s | 01 | 5 |
| 36 | `topsy` | Head over heels | Mischief | 3.2s | 01 | 1 |
| 37 | `shoe-skateboard` | Questionable transport | Travel | 2.4s | 02 | 3 |
| 38 | `brain-kickflip` | Hold my frontal lobe | Mischief | 3.2s | 02 | 3 |
| 39 | `sneeze` | Achoo, there go the glasses | Mischief | 3.6s | 02 | 3 |
| 40 | `pocket-panic` | Wait. I do not have pockets. | Mischief | 2.8s | 02 | 3 |
| 41 | `shoe-phone` | The sole support line | Mischief | 3.2s | 02 | 3 |
| 42 | `cheek-drums` | Built-in bongos | Dancing | 1.2s | 02 | 3 |
| 43 | `glasses-clean` | Polishing the perspective | Thinking | 3.2s | 02 | 3 |
| 44 | `noodle-slurp` | One very long thought | Cooking | 3.2s | 02 | 3 |
| 45 | `nap` | Saving brain power | Thinking | 4.8s | 02 | 3 |
| 46 | `stretch` | Booting the last brain cell | Mischief | 4.2s | 02 | 3 |
| 47 | `sneak` | Definitely not up to anything | Travel | 2.4s | 02 | 3 |
| 48 | `peekaboo` | Just checking if you are still there | Mischief | 4s | 02 | 3 |
| 49 | `balloon-brain` | A head full of helium | Magic | 4s | 02 | 3 |
| 50 | `hula-hoop` | Doctorate in hoopla | Dancing | 1.6s | 02 | 3 |
| 51 | `tap-dance` | The clack department | Dancing | 1.6s | 02 | 3 |
| 52 | `cancan` | No skirt. All can-can. | Dancing | 1.6s | 02 | 3 |
| 53 | `ribbon` | Absolutely not Olympic regulation | Dancing | 2.8s | 02 | 3 |
| 54 | `magnet` | Magnetic personality disorder | Magic | 3.6s | 02 | 3 |
| 55 | `bubbles` | Making the problem more bubbly | Magic | 3.2s | 02 | 3 |
| 56 | `wind-up` | Powered by a very small key | Making | 2.4s | 02 | 3 |
| 57 | `accordion` | Concertina of questionable thoughts | Dancing | 2.4s | 02 | 3 |
| 58 | `confetti` | A completely proportionate celebration | Mischief | 2.8s | 02 | 3 |
| 59 | `hammock` | A rigorous horizontal investigation | Thinking | 4.8s | 02 | 3 |
| 60 | `shoe-vortex` | There is a universe in that shoe | Magic | 3.6s | 02 | 3 |
<!-- MOTION_TABLE_END -->
