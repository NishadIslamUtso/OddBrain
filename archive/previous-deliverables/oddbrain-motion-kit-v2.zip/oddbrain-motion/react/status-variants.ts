// Opt-in alternate takes. Index zero is always the canonical default.
export const statusVariants = {
  "Accomplishing": [
    "type",
    "confetti"
  ],
  "Actioning": [
    "type"
  ],
  "Actualizing": [
    "idea",
    "stretch",
    "confetti"
  ],
  "Architecting": [
    "architect"
  ],
  "Baking": [
    "bake"
  ],
  "Beaming": [
    "sparkle",
    "balloon-brain",
    "confetti"
  ],
  "Beboppin'": [
    "shimmy",
    "cheek-drums"
  ],
  "Befuddling": [
    "eye-roll",
    "pocket-panic"
  ],
  "Billowing": [
    "gust",
    "balloon-brain"
  ],
  "Blanching": [
    "bake",
    "sneeze"
  ],
  "Bloviating": [
    "talk",
    "shoe-phone"
  ],
  "Boogieing": [
    "shimmy",
    "cheek-drums",
    "tap-dance",
    "cancan"
  ],
  "Boondoggling": [
    "forge",
    "brain-kickflip"
  ],
  "Booping": [
    "boop"
  ],
  "Bootstrapping": [
    "type",
    "wind-up"
  ],
  "Brewing": [
    "stir"
  ],
  "Bunning": [
    "bake",
    "balloon-brain"
  ],
  "Burrowing": [
    "tunnel",
    "sneak"
  ],
  "Calculating": [
    "compute"
  ],
  "Canoodling": [
    "boop",
    "noodle-slurp"
  ],
  "Caramelizing": [
    "bake"
  ],
  "Cascading": [
    "gust"
  ],
  "Catapulting": [
    "warp",
    "brain-kickflip"
  ],
  "Cerebrating": [
    "think"
  ],
  "Channeling": [
    "float",
    "shoe-phone"
  ],
  "Channelling": [
    "float",
    "shoe-phone"
  ],
  "Choreographing": [
    "architect",
    "tap-dance"
  ],
  "Churning": [
    "unwind",
    "wind-up",
    "accordion"
  ],
  "Clauding": [
    "type"
  ],
  "Coalescing": [
    "transform",
    "magnet"
  ],
  "Cogitating": [
    "think"
  ],
  "Combobulating": [
    "transform",
    "magnet"
  ],
  "Composing": [
    "architect"
  ],
  "Computing": [
    "compute"
  ],
  "Concocting": [
    "stir"
  ],
  "Considering": [
    "think",
    "glasses-clean",
    "peekaboo"
  ],
  "Contemplating": [
    "think",
    "hammock"
  ],
  "Cooking": [
    "stir",
    "noodle-slurp"
  ],
  "Crafting": [
    "forge"
  ],
  "Creating": [
    "sketch"
  ],
  "Crunching": [
    "compute"
  ],
  "Crystallizing": [
    "transform"
  ],
  "Cultivating": [
    "grow"
  ],
  "Deciphering": [
    "compute",
    "glasses-clean"
  ],
  "Deliberating": [
    "think"
  ],
  "Determining": [
    "compute"
  ],
  "Dilly-dallying": [
    "idle",
    "nap"
  ],
  "Discombobulating": [
    "eye-roll",
    "sneeze"
  ],
  "Doing": [
    "type",
    "peekaboo"
  ],
  "Doodling": [
    "sketch"
  ],
  "Drizzling": [
    "whisk"
  ],
  "Ebbing": [
    "float"
  ],
  "Effecting": [
    "type"
  ],
  "Elucidating": [
    "idea",
    "glasses-clean"
  ],
  "Embellishing": [
    "sketch"
  ],
  "Enchanting": [
    "sparkle",
    "bubbles"
  ],
  "Envisioning": [
    "idea"
  ],
  "Evaporating": [
    "dissolve",
    "shoe-vortex"
  ],
  "Fermenting": [
    "stir",
    "bubbles"
  ],
  "Fiddle-faddling": [
    "juggle-shoes"
  ],
  "Finagling": [
    "juggle-glasses"
  ],
  "Flambéing": [
    "whisk"
  ],
  "Flibbertigibbeting": [
    "chaos"
  ],
  "Flowing": [
    "float",
    "bubbles"
  ],
  "Flummoxing": [
    "eye-roll",
    "pocket-panic"
  ],
  "Fluttering": [
    "gust",
    "ribbon"
  ],
  "Forging": [
    "forge"
  ],
  "Forming": [
    "transform"
  ],
  "Frolicking": [
    "chaos",
    "cancan"
  ],
  "Frosting": [
    "bake"
  ],
  "Gallivanting": [
    "chaos",
    "shoe-skateboard",
    "cancan"
  ],
  "Galloping": [
    "run",
    "cancan"
  ],
  "Garnishing": [
    "whisk"
  ],
  "Generating": [
    "idea"
  ],
  "Gesticulating": [
    "talk"
  ],
  "Germinating": [
    "grow"
  ],
  "Gitifying": [
    "type"
  ],
  "Grooving": [
    "shimmy",
    "cheek-drums"
  ],
  "Gusting": [
    "gust"
  ],
  "Harmonizing": [
    "shimmy",
    "cheek-drums",
    "accordion"
  ],
  "Hashing": [
    "compute"
  ],
  "Hatching": [
    "grow"
  ],
  "Herding": [
    "run"
  ],
  "Honking": [
    "talk",
    "shoe-phone"
  ],
  "Hullaballooing": [
    "chaos",
    "sneeze"
  ],
  "Hyperspacing": [
    "warp",
    "shoe-vortex"
  ],
  "Ideating": [
    "idea"
  ],
  "Imagining": [
    "idea"
  ],
  "Improvising": [
    "juggle-glasses",
    "brain-kickflip"
  ],
  "Incubating": [
    "grow",
    "nap"
  ],
  "Inferring": [
    "compute"
  ],
  "Infusing": [
    "stir"
  ],
  "Ionizing": [
    "dissolve"
  ],
  "Jitterbugging": [
    "shimmy",
    "tap-dance"
  ],
  "Julienning": [
    "whisk"
  ],
  "Kneading": [
    "bake"
  ],
  "Leavening": [
    "bake",
    "stretch"
  ],
  "Levitating": [
    "float",
    "balloon-brain"
  ],
  "Lollygagging": [
    "idle",
    "nap"
  ],
  "Manifesting": [
    "idea",
    "confetti"
  ],
  "Marinating": [
    "stir",
    "noodle-slurp",
    "hammock"
  ],
  "Meandering": [
    "waddle"
  ],
  "Metamorphosing": [
    "transform"
  ],
  "Misting": [
    "dissolve",
    "bubbles"
  ],
  "Moonwalking": [
    "moonwalk",
    "shoe-skateboard"
  ],
  "Moseying": [
    "idle",
    "nap",
    "hammock"
  ],
  "Mulling": [
    "think",
    "hammock"
  ],
  "Mustering": [
    "unwind",
    "stretch",
    "magnet"
  ],
  "Musing": [
    "think",
    "nap"
  ],
  "Nebulizing": [
    "dissolve",
    "bubbles"
  ],
  "Nesting": [
    "grow"
  ],
  "Newspapering": [
    "read"
  ],
  "Noodling": [
    "stir",
    "noodle-slurp"
  ],
  "Nucleating": [
    "transform"
  ],
  "Orbiting": [
    "spin"
  ],
  "Orchestrating": [
    "architect",
    "cheek-drums"
  ],
  "Osmosing": [
    "float"
  ],
  "Perambulating": [
    "waddle",
    "sneak"
  ],
  "Percolating": [
    "stir"
  ],
  "Perusing": [
    "read",
    "glasses-clean",
    "peekaboo"
  ],
  "Philosophising": [
    "think"
  ],
  "Photosynthesizing": [
    "grow"
  ],
  "Pollinating": [
    "grow"
  ],
  "Pondering": [
    "think"
  ],
  "Pontificating": [
    "talk",
    "shoe-phone"
  ],
  "Pouncing": [
    "run",
    "peekaboo"
  ],
  "Precipitating": [
    "gust"
  ],
  "Prestidigitating": [
    "sparkle",
    "ribbon"
  ],
  "Processing": [
    "compute",
    "wind-up"
  ],
  "Proofing": [
    "bake",
    "glasses-clean"
  ],
  "Propagating": [
    "grow"
  ],
  "Puttering": [
    "waddle"
  ],
  "Puzzling": [
    "eye-roll",
    "pocket-panic"
  ],
  "Quantumizing": [
    "spin"
  ],
  "Razzle-dazzling": [
    "sparkle",
    "ribbon"
  ],
  "Razzmatazzing": [
    "chaos",
    "confetti"
  ],
  "Recombobulating": [
    "transform"
  ],
  "Reticulating": [
    "architect",
    "accordion"
  ],
  "Roosting": [
    "grow"
  ],
  "Ruminating": [
    "think",
    "hammock"
  ],
  "Sautéing": [
    "whisk"
  ],
  "Scampering": [
    "run"
  ],
  "Schlepping": [
    "waddle",
    "shoe-skateboard"
  ],
  "Scurrying": [
    "run",
    "sneak"
  ],
  "Seasoning": [
    "whisk"
  ],
  "Shenaniganing": [
    "juggle-body"
  ],
  "Shimmying": [
    "shimmy",
    "hula-hoop"
  ],
  "Simmering": [
    "stir"
  ],
  "Skedaddling": [
    "run",
    "shoe-skateboard"
  ],
  "Sketching": [
    "sketch"
  ],
  "Slithering": [
    "wiggle"
  ],
  "Smooshing": [
    "wiggle",
    "accordion"
  ],
  "Sock-hopping": [
    "moonwalk",
    "tap-dance"
  ],
  "Spelunking": [
    "tunnel",
    "sneak"
  ],
  "Spinning": [
    "spin"
  ],
  "Sprouting": [
    "grow"
  ],
  "Stewing": [
    "stir"
  ],
  "Sublimating": [
    "dissolve",
    "shoe-vortex"
  ],
  "Swirling": [
    "spin"
  ],
  "Swooping": [
    "warp"
  ],
  "Symbioting": [
    "float"
  ],
  "Synthesizing": [
    "transform",
    "accordion"
  ],
  "Tempering": [
    "forge"
  ],
  "Thinking": [
    "think"
  ],
  "Thundering": [
    "gust",
    "sneeze"
  ],
  "Tinkering": [
    "forge"
  ],
  "Tomfoolering": [
    "chaos"
  ],
  "Topsy-turvying": [
    "topsy",
    "brain-kickflip"
  ],
  "Transfiguring": [
    "transform"
  ],
  "Transmuting": [
    "transform"
  ],
  "Twisting": [
    "wiggle",
    "hula-hoop"
  ],
  "Undulating": [
    "wiggle",
    "hula-hoop"
  ],
  "Unfurling": [
    "unwind",
    "stretch",
    "ribbon"
  ],
  "Unravelling": [
    "unwind"
  ],
  "Vibing": [
    "shimmy",
    "hula-hoop"
  ],
  "Waddling": [
    "waddle"
  ],
  "Wandering": [
    "waddle"
  ],
  "Warping": [
    "warp",
    "shoe-vortex"
  ],
  "Whatchamacalliting": [
    "talk",
    "pocket-panic"
  ],
  "Whirlpooling": [
    "spin",
    "shoe-vortex"
  ],
  "Whirring": [
    "spin",
    "wind-up"
  ],
  "Whisking": [
    "whisk"
  ],
  "Wibbling": [
    "wiggle"
  ],
  "Working": [
    "type",
    "wind-up"
  ],
  "Wrangling": [
    "run",
    "magnet"
  ],
  "Zesting": [
    "whisk"
  ],
  "Zigzagging": [
    "warp"
  ],
  "Skateboarding": [
    "shoe-skateboard",
    "moonwalk",
    "waddle",
    "run",
    "chaos"
  ],
  "Coasting": [
    "shoe-skateboard",
    "moonwalk",
    "waddle",
    "run",
    "chaos"
  ],
  "Rolling": [
    "shoe-skateboard",
    "moonwalk",
    "waddle",
    "run",
    "chaos"
  ],
  "Kickflipping": [
    "brain-kickflip",
    "warp",
    "topsy",
    "forge",
    "juggle-glasses"
  ],
  "Headspinning": [
    "brain-kickflip",
    "warp",
    "topsy",
    "forge",
    "juggle-glasses"
  ],
  "Brainstorming": [
    "brain-kickflip",
    "warp",
    "topsy",
    "forge",
    "juggle-glasses"
  ],
  "Sneezing": [
    "sneeze",
    "bake",
    "eye-roll",
    "gust",
    "chaos"
  ],
  "Achooing": [
    "sneeze",
    "bake",
    "eye-roll",
    "gust",
    "chaos"
  ],
  "Sniffling": [
    "sneeze",
    "bake",
    "eye-roll",
    "gust",
    "chaos"
  ],
  "Pocket-patting": [
    "pocket-panic",
    "eye-roll",
    "talk"
  ],
  "Panicking": [
    "pocket-panic",
    "eye-roll",
    "talk"
  ],
  "Double-checking": [
    "pocket-panic",
    "eye-roll",
    "talk"
  ],
  "Dialing": [
    "shoe-phone",
    "float",
    "talk"
  ],
  "Calling": [
    "shoe-phone",
    "float",
    "talk"
  ],
  "Consulting": [
    "shoe-phone",
    "float",
    "talk"
  ],
  "Drumming": [
    "cheek-drums",
    "shimmy",
    "architect"
  ],
  "Beatboxing": [
    "cheek-drums",
    "shimmy",
    "architect"
  ],
  "Percussing": [
    "cheek-drums",
    "shimmy",
    "architect"
  ],
  "Polishing": [
    "glasses-clean",
    "idea",
    "compute",
    "read",
    "think",
    "bake"
  ],
  "Clarifying": [
    "glasses-clean",
    "idea",
    "compute",
    "read",
    "think",
    "bake"
  ],
  "Refocusing": [
    "glasses-clean",
    "idea",
    "compute",
    "read",
    "think",
    "bake"
  ],
  "Slurping": [
    "noodle-slurp",
    "stir",
    "boop"
  ],
  "Snacking": [
    "noodle-slurp",
    "stir",
    "boop"
  ],
  "Recharging": [
    "noodle-slurp",
    "stir",
    "boop"
  ],
  "Snoozing": [
    "nap",
    "idle",
    "think",
    "grow"
  ],
  "Napping": [
    "nap",
    "idle",
    "think",
    "grow"
  ],
  "Dreaming": [
    "nap",
    "idle",
    "think",
    "grow"
  ],
  "Yawning": [
    "stretch",
    "bake",
    "unwind",
    "idea"
  ],
  "Stretching": [
    "stretch",
    "bake",
    "unwind",
    "idea"
  ],
  "Waking": [
    "stretch",
    "bake",
    "unwind",
    "idea"
  ],
  "Sneaking": [
    "sneak",
    "waddle",
    "run",
    "tunnel"
  ],
  "Tiptoeing": [
    "sneak",
    "waddle",
    "run",
    "tunnel"
  ],
  "Slinking": [
    "sneak",
    "waddle",
    "run",
    "tunnel"
  ],
  "Peeking": [
    "peekaboo",
    "read",
    "think",
    "run",
    "type"
  ],
  "Peekabooing": [
    "peekaboo",
    "read",
    "think",
    "run",
    "type"
  ],
  "Checking": [
    "peekaboo",
    "read",
    "think",
    "run",
    "type"
  ],
  "Inflating": [
    "balloon-brain",
    "gust",
    "float",
    "bake",
    "sparkle"
  ],
  "Buoying": [
    "balloon-brain",
    "gust",
    "float",
    "bake",
    "sparkle"
  ],
  "Ballooning": [
    "balloon-brain",
    "gust",
    "float",
    "bake",
    "sparkle"
  ],
  "Hula-hooping": [
    "hula-hoop",
    "shimmy",
    "wiggle"
  ],
  "Waist-wiggling": [
    "hula-hoop",
    "shimmy",
    "wiggle"
  ],
  "Hoopla-ing": [
    "hula-hoop",
    "shimmy",
    "wiggle"
  ],
  "Tap-dancing": [
    "tap-dance",
    "moonwalk",
    "shimmy",
    "architect"
  ],
  "Heel-clicking": [
    "tap-dance",
    "moonwalk",
    "shimmy",
    "architect"
  ],
  "Clacking": [
    "tap-dance",
    "moonwalk",
    "shimmy",
    "architect"
  ],
  "High-kicking": [
    "cancan",
    "chaos",
    "run",
    "shimmy"
  ],
  "Cancanning": [
    "cancan",
    "chaos",
    "run",
    "shimmy"
  ],
  "Legging-it": [
    "cancan",
    "chaos",
    "run",
    "shimmy"
  ],
  "Ribboning": [
    "ribbon",
    "gust",
    "unwind",
    "sparkle"
  ],
  "Twirling": [
    "ribbon",
    "gust",
    "unwind",
    "sparkle"
  ],
  "Flourishing": [
    "ribbon",
    "gust",
    "unwind",
    "sparkle"
  ],
  "Magnetizing": [
    "magnet",
    "transform",
    "unwind",
    "run"
  ],
  "Attracting": [
    "magnet",
    "transform",
    "unwind",
    "run"
  ],
  "Polarizing": [
    "magnet",
    "transform",
    "unwind",
    "run"
  ],
  "Bubbling": [
    "bubbles",
    "float",
    "dissolve",
    "stir",
    "sparkle"
  ],
  "Bubble-blowing": [
    "bubbles",
    "float",
    "dissolve",
    "stir",
    "sparkle"
  ],
  "Effervescing": [
    "bubbles",
    "float",
    "dissolve",
    "stir",
    "sparkle"
  ],
  "Winding-up": [
    "wind-up",
    "type",
    "spin",
    "unwind",
    "compute"
  ],
  "Rewinding": [
    "wind-up",
    "type",
    "spin",
    "unwind",
    "compute"
  ],
  "Clockworking": [
    "wind-up",
    "type",
    "spin",
    "unwind",
    "compute"
  ],
  "Accordioning": [
    "accordion",
    "unwind",
    "wiggle",
    "architect",
    "transform",
    "shimmy"
  ],
  "Concertina-ing": [
    "accordion",
    "unwind",
    "wiggle",
    "architect",
    "transform",
    "shimmy"
  ],
  "Squeezing": [
    "accordion",
    "unwind",
    "wiggle",
    "architect",
    "transform",
    "shimmy"
  ],
  "Celebrating": [
    "confetti",
    "type",
    "idea",
    "sparkle",
    "chaos"
  ],
  "High-fiving": [
    "confetti",
    "type",
    "idea",
    "sparkle",
    "chaos"
  ],
  "Confetti-ing": [
    "confetti",
    "type",
    "idea",
    "sparkle",
    "chaos"
  ],
  "Lounging": [
    "hammock",
    "think",
    "idle",
    "stir"
  ],
  "Hammocking": [
    "hammock",
    "think",
    "idle",
    "stir"
  ],
  "Unwinding": [
    "hammock",
    "think",
    "idle",
    "stir"
  ],
  "Vacuuming": [
    "shoe-vortex",
    "warp",
    "spin",
    "dissolve"
  ],
  "Imploding": [
    "shoe-vortex",
    "warp",
    "spin",
    "dissolve"
  ],
  "Vanishing": [
    "shoe-vortex",
    "warp",
    "spin",
    "dissolve"
  ]
} as const;
