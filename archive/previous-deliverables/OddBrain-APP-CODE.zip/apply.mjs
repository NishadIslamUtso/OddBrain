#!/usr/bin/env node
/** Version-checked, backed-up application of this source patch. Node 22+. */
import { readFile, writeFile, mkdir, stat, lstat, realpath, rename, rm } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { dirname, join, resolve, relative, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const manifest = JSON.parse(await readFile(join(here, 'PATCH-MANIFEST.json'), 'utf8'))
const args = process.argv.slice(2), checkOnly = args.includes('--check')
const destination = args.find(arg => !arg.startsWith('--')) || process.cwd()
let root = await realpath(resolve(destination))
const exists = async path => { try { await stat(path); return true } catch { return false } }
if (!await exists(join(root, 'apps', '03_oddbrain', 'package.json'))) {
  if (await exists(join(root, 'src', 'renderer', 'src', 'App.tsx')) && await exists(join(root, 'package.json'))) root = await realpath(resolve(root, '..', '..'))
  else throw Error('Choose the OddBrain repository root (the folder containing apps/03_oddbrain).')
}
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
const textDigest = bytes => digest(Buffer.from(bytes.toString('utf8').replace(/\r\n/g, '\n')))
const matches = (bytes, raw, text) => digest(bytes) === raw || !!text && textDigest(bytes) === text
async function safeTarget(name) {
  if (typeof name !== 'string' || !name.startsWith('apps/03_oddbrain/') || name.includes('..') || name.includes('\\')) throw Error('Invalid patch path.')
  const target = resolve(root, name)
  if (!target.startsWith(root + sep)) throw Error('Patch path escapes the repository.')
  let parent = dirname(target)
  while (parent !== root) {
    try { if ((await lstat(parent)).isSymbolicLink()) throw Error('A patch destination is a symbolic link: ' + relative(root, parent)) }
    catch (error) { if (error.code !== 'ENOENT') throw error }
    parent = dirname(parent)
  }
  try { if ((await lstat(target)).isSymbolicLink()) throw Error('Refusing to replace a symbolic link: ' + name) }
  catch (error) { if (error.code !== 'ENOENT') throw error }
  return target
}
const conflicts = [], plans = [], skipped = []
for (const entry of manifest.files) {
  const target = await safeTarget(entry.path), source = join(here, 'files', ...entry.path.split('/'))
  const incoming = await readFile(source)
  if (digest(incoming) !== entry.afterSha256) throw Error('The package is incomplete or corrupt: ' + entry.path)
  const current = await exists(target) ? await readFile(target) : null
  if (current && matches(current, entry.afterSha256, entry.afterTextSha256)) { skipped.push(entry.path); continue }
  const accepted = current && (matches(current, entry.beforeSha256, entry.beforeTextSha256) || (entry.acceptedBefore || []).some(old => matches(current, old.sha256, old.textSha256)))
  if (entry.beforeSha256 ? !accepted : current !== null && !accepted) { conflicts.push(entry.path); continue }
  plans.push({ entry, target, incoming, current })
}
for (const item of manifest.compatibility) {
  const target = await safeTarget(item.path)
  if (!await exists(target) || !matches(await readFile(target), item.sha256, item.textSha256)) conflicts.push(item.path + ' (compatibility dependency)')
}
if (conflicts.length) {
  console.error('NOT APPLIED: this source does not match the reviewed baseline, or contains other edits. No file was changed.\n' + [...new Set(conflicts)].map(p => '  ' + p).join('\n'))
  console.error('Have the app agent rebase OddBrain-App-UI.patch onto the current branch. Do not force overwrite.')
  process.exitCode = 2
} else if (checkOnly) console.log(`Compatible: ${plans.length} files to apply, ${skipped.length} already applied. Nothing changed.`)
else if (!plans.length) console.log('Already applied. No files changed.')
else {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-'), backup = join(root, '_oddbrain-ui-backup-' + stamp)
  await mkdir(backup, { recursive: true })
  await writeFile(join(backup, 'backup.json'), JSON.stringify({ baseline: manifest.baseline, files: plans.map(p => ({ path: p.entry.path, existed: p.current !== null })) }, null, 2))
  for (const plan of plans) if (plan.current !== null) { const file = join(backup, plan.entry.path); await mkdir(dirname(file), { recursive: true }); await writeFile(file, plan.current) }
  const written = [], temps = []
  try {
    for (const plan of plans) {
      await mkdir(dirname(plan.target), { recursive: true })
      // Preserve a Windows checkout's line endings; matching is content-strict
      // apart from CRLF/LF, never a fuzzy overwrite of edited source.
      const oldText = plan.current?.toString('utf8') || ''
      const bytes = plan.entry.afterTextSha256 && /\r\n/.test(oldText) ? Buffer.from(plan.incoming.toString('utf8').replace(/\r?\n/g, '\r\n')) : plan.incoming
      const temp = plan.target + '.oddbrain-ui-tmp-' + process.pid; temps.push(temp)
      await writeFile(temp, bytes); await rename(temp, plan.target); written.push(plan)
    }
    console.log(`Applied ${written.length} app source files. Backup: ${backup}`)
    console.log('Next, in apps/03_oddbrain with Node 22+: npm ci && npm run typecheck && npm test && npm run build')
    console.log('This changes source only. Build and check the Windows installer before installing it.')
  } catch (error) {
    for (const plan of written.reverse()) { if (plan.current !== null) await writeFile(plan.target, plan.current); else await rm(plan.target, { force: true }) }
    console.error('Write failed; changed files were rolled back. Original backup: ' + backup)
    throw error
  } finally { for (const temp of temps) await rm(temp, { force: true }) }
}
