// Opt-in alternate takes. Index zero is always the canonical default.
export const statusVariants = {
  "Accomplishing": [
    "type",
    "confetti"
  ],
  "Actioning": [
    "type"
  ],
  "Actualizing": [
    "idea",
    "stretch",
    "confetti"
  ],
  "Architecting": [
    "architect"
  ],
  "Baking": [
    "bake",
    "pan-flip"
  ],
  "Beaming": [
    "sparkle",
    "balloon-brain",
    "confetti",
    "self-hug"
  ],
  "Beboppin'": [
    "shimmy",
    "cheek-drums"
  ],
  "Befuddling": [
    "eye-roll",
    "pocket-panic"
  ],
  "Billowing": [
    "gust",
    "balloon-brain",
    "rain-check"
  ],
  "Blanching": [
    "bake",
    "sneeze"
  ],
  "Bloviating": [
    "talk",
    "shoe-phone",
    "megaphone"
  ],
  "Boogieing": [
    "shimmy",
    "cheek-drums",
    "tap-dance",
    "cancan"
  ],
  "Boondoggling": [
    "forge",
    "brain-kickflip"
  ],
  "Booping": [
    "boop"
  ],
  "Bootstrapping": [
    "type",
    "wind-up"
  ],
  "Brewing": [
    "stir"
  ],
  "Bunning": [
    "bake",
    "balloon-brain"
  ],
  "Burrowing": [
    "tunnel",
    "sneak"
  ],
  "Calculating": [
    "compute"
  ],
  "Canoodling": [
    "boop",
    "noodle-slurp",
    "self-hug"
  ],
  "Caramelizing": [
    "bake",
    "pan-flip"
  ],
  "Cascading": [
    "gust"
  ],
  "Catapulting": [
    "warp",
    "brain-kickflip"
  ],
  "Cerebrating": [
    "think"
  ],
  "Channeling": [
    "float",
    "shoe-phone",
    "lotus-float"
  ],
  "Channelling": [
    "float",
    "shoe-phone"
  ],
  "Choreographing": [
    "architect",
    "tap-dance",
    "maestro"
  ],
  "Churning": [
    "unwind",
    "wind-up",
    "accordion"
  ],
  "Clauding": [
    "type"
  ],
  "Coalescing": [
    "transform",
    "magnet"
  ],
  "Cogitating": [
    "think"
  ],
  "Combobulating": [
    "transform",
    "magnet",
    "branch-merge"
  ],
  "Composing": [
    "architect",
    "maestro"
  ],
  "Computing": [
    "compute",
    "branch-merge"
  ],
  "Concocting": [
    "stir"
  ],
  "Considering": [
    "think",
    "glasses-clean",
    "peekaboo",
    "lens-inspector"
  ],
  "Contemplating": [
    "think",
    "hammock",
    "lotus-float"
  ],
  "Cooking": [
    "stir",
    "noodle-slurp",
    "pan-flip"
  ],
  "Crafting": [
    "forge"
  ],
  "Creating": [
    "sketch"
  ],
  "Crunching": [
    "compute"
  ],
  "Crystallizing": [
    "transform",
    "snow-shiver"
  ],
  "Cultivating": [
    "grow",
    "bee-bloom"
  ],
  "Deciphering": [
    "compute",
    "glasses-clean",
    "lens-inspector",
    "hinge-tune",
    "flashlight-search"
  ],
  "Deliberating": [
    "think"
  ],
  "Determining": [
    "compute",
    "hinge-tune"
  ],
  "Dilly-dallying": [
    "idle",
    "nap",
    "mochi-melt"
  ],
  "Discombobulating": [
    "eye-roll",
    "sneeze"
  ],
  "Doing": [
    "type",
    "peekaboo"
  ],
  "Doodling": [
    "sketch"
  ],
  "Drizzling": [
    "whisk"
  ],
  "Ebbing": [
    "float"
  ],
  "Effecting": [
    "type"
  ],
  "Elucidating": [
    "idea",
    "glasses-clean",
    "flashlight-search"
  ],
  "Embellishing": [
    "sketch"
  ],
  "Enchanting": [
    "sparkle",
    "bubbles"
  ],
  "Envisioning": [
    "idea"
  ],
  "Evaporating": [
    "dissolve",
    "shoe-vortex"
  ],
  "Fermenting": [
    "stir",
    "bubbles"
  ],
  "Fiddle-faddling": [
    "juggle-shoes"
  ],
  "Finagling": [
    "juggle-glasses",
    "shoe-lasso",
    "hinge-tune"
  ],
  "Flambéing": [
    "whisk",
    "pan-flip"
  ],
  "Flibbertigibbeting": [
    "chaos"
  ],
  "Flowing": [
    "float",
    "bubbles"
  ],
  "Flummoxing": [
    "eye-roll",
    "pocket-panic"
  ],
  "Fluttering": [
    "gust",
    "ribbon"
  ],
  "Forging": [
    "forge"
  ],
  "Forming": [
    "transform"
  ],
  "Frolicking": [
    "chaos",
    "cancan",
    "belly-laugh"
  ],
  "Frosting": [
    "bake",
    "snow-shiver"
  ],
  "Gallivanting": [
    "chaos",
    "shoe-skateboard",
    "cancan"
  ],
  "Galloping": [
    "run",
    "cancan"
  ],
  "Garnishing": [
    "whisk"
  ],
  "Generating": [
    "idea"
  ],
  "Gesticulating": [
    "talk",
    "megaphone"
  ],
  "Germinating": [
    "grow",
    "bee-bloom"
  ],
  "Gitifying": [
    "type",
    "branch-merge"
  ],
  "Grooving": [
    "shimmy",
    "cheek-drums"
  ],
  "Gusting": [
    "gust",
    "rain-check"
  ],
  "Harmonizing": [
    "shimmy",
    "cheek-drums",
    "accordion",
    "maestro"
  ],
  "Hashing": [
    "compute"
  ],
  "Hatching": [
    "grow"
  ],
  "Herding": [
    "run",
    "shoe-lasso"
  ],
  "Honking": [
    "talk",
    "shoe-phone",
    "megaphone"
  ],
  "Hullaballooing": [
    "chaos",
    "sneeze",
    "belly-laugh"
  ],
  "Hyperspacing": [
    "warp",
    "shoe-vortex"
  ],
  "Ideating": [
    "idea"
  ],
  "Imagining": [
    "idea"
  ],
  "Improvising": [
    "juggle-glasses",
    "brain-kickflip"
  ],
  "Incubating": [
    "grow",
    "nap"
  ],
  "Inferring": [
    "compute",
    "flashlight-search"
  ],
  "Infusing": [
    "stir"
  ],
  "Ionizing": [
    "dissolve"
  ],
  "Jitterbugging": [
    "shimmy",
    "tap-dance"
  ],
  "Julienning": [
    "whisk"
  ],
  "Kneading": [
    "bake"
  ],
  "Leavening": [
    "bake",
    "stretch"
  ],
  "Levitating": [
    "float",
    "balloon-brain",
    "lotus-float"
  ],
  "Lollygagging": [
    "idle",
    "nap",
    "mochi-melt"
  ],
  "Manifesting": [
    "idea",
    "confetti"
  ],
  "Marinating": [
    "stir",
    "noodle-slurp",
    "hammock"
  ],
  "Meandering": [
    "waddle"
  ],
  "Metamorphosing": [
    "transform"
  ],
  "Misting": [
    "dissolve",
    "bubbles"
  ],
  "Moonwalking": [
    "moonwalk",
    "shoe-skateboard"
  ],
  "Moseying": [
    "idle",
    "nap",
    "hammock",
    "mochi-melt"
  ],
  "Mulling": [
    "think",
    "hammock",
    "lotus-float"
  ],
  "Mustering": [
    "unwind",
    "stretch",
    "magnet",
    "shoe-lasso"
  ],
  "Musing": [
    "think",
    "nap",
    "mochi-melt",
    "lotus-float"
  ],
  "Nebulizing": [
    "dissolve",
    "bubbles"
  ],
  "Nesting": [
    "grow"
  ],
  "Newspapering": [
    "read"
  ],
  "Noodling": [
    "stir",
    "noodle-slurp"
  ],
  "Nucleating": [
    "transform"
  ],
  "Orbiting": [
    "spin"
  ],
  "Orchestrating": [
    "architect",
    "cheek-drums",
    "maestro"
  ],
  "Osmosing": [
    "float"
  ],
  "Perambulating": [
    "waddle",
    "sneak"
  ],
  "Percolating": [
    "stir"
  ],
  "Perusing": [
    "read",
    "glasses-clean",
    "peekaboo",
    "lens-inspector",
    "flashlight-search"
  ],
  "Philosophising": [
    "think"
  ],
  "Photosynthesizing": [
    "grow",
    "bee-bloom"
  ],
  "Pollinating": [
    "grow",
    "bee-bloom"
  ],
  "Pondering": [
    "think"
  ],
  "Pontificating": [
    "talk",
    "shoe-phone",
    "megaphone"
  ],
  "Pouncing": [
    "run",
    "peekaboo"
  ],
  "Precipitating": [
    "gust",
    "rain-check",
    "snow-shiver"
  ],
  "Prestidigitating": [
    "sparkle",
    "ribbon"
  ],
  "Processing": [
    "compute",
    "wind-up"
  ],
  "Proofing": [
    "bake",
    "glasses-clean"
  ],
  "Propagating": [
    "grow"
  ],
  "Puttering": [
    "waddle"
  ],
  "Puzzling": [
    "eye-roll",
    "pocket-panic",
    "lens-inspector"
  ],
  "Quantumizing": [
    "spin"
  ],
  "Razzle-dazzling": [
    "sparkle",
    "ribbon"
  ],
  "Razzmatazzing": [
    "chaos",
    "confetti",
    "belly-laugh"
  ],
  "Recombobulating": [
    "transform",
    "branch-merge"
  ],
  "Reticulating": [
    "architect",
    "accordion"
  ],
  "Roosting": [
    "grow"
  ],
  "Ruminating": [
    "think",
    "hammock"
  ],
  "Sautéing": [
    "whisk",
    "pan-flip"
  ],
  "Scampering": [
    "run"
  ],
  "Schlepping": [
    "waddle",
    "shoe-skateboard"
  ],
  "Scurrying": [
    "run",
    "sneak"
  ],
  "Seasoning": [
    "whisk"
  ],
  "Shenaniganing": [
    "juggle-body",
    "belly-laugh"
  ],
  "Shimmying": [
    "shimmy",
    "hula-hoop"
  ],
  "Simmering": [
    "stir"
  ],
  "Skedaddling": [
    "run",
    "shoe-skateboard"
  ],
  "Sketching": [
    "sketch"
  ],
  "Slithering": [
    "wiggle"
  ],
  "Smooshing": [
    "wiggle",
    "accordion"
  ],
  "Sock-hopping": [
    "moonwalk",
    "tap-dance"
  ],
  "Spelunking": [
    "tunnel",
    "sneak",
    "flashlight-search"
  ],
  "Spinning": [
    "spin"
  ],
  "Sprouting": [
    "grow",
    "bee-bloom"
  ],
  "Stewing": [
    "stir"
  ],
  "Sublimating": [
    "dissolve",
    "shoe-vortex"
  ],
  "Swirling": [
    "spin"
  ],
  "Swooping": [
    "warp"
  ],
  "Symbioting": [
    "float",
    "self-hug"
  ],
  "Synthesizing": [
    "transform",
    "accordion",
    "branch-merge"
  ],
  "Tempering": [
    "forge",
    "snow-shiver"
  ],
  "Thinking": [
    "think"
  ],
  "Thundering": [
    "gust",
    "sneeze",
    "rain-check"
  ],
  "Tinkering": [
    "forge",
    "hinge-tune"
  ],
  "Tomfoolering": [
    "chaos"
  ],
  "Topsy-turvying": [
    "topsy",
    "brain-kickflip"
  ],
  "Transfiguring": [
    "transform"
  ],
  "Transmuting": [
    "transform"
  ],
  "Twisting": [
    "wiggle",
    "hula-hoop"
  ],
  "Undulating": [
    "wiggle",
    "hula-hoop"
  ],
  "Unfurling": [
    "unwind",
    "stretch",
    "ribbon"
  ],
  "Unravelling": [
    "unwind"
  ],
  "Vibing": [
    "shimmy",
    "hula-hoop",
    "self-hug"
  ],
  "Waddling": [
    "waddle"
  ],
  "Wandering": [
    "waddle"
  ],
  "Warping": [
    "warp",
    "shoe-vortex"
  ],
  "Whatchamacalliting": [
    "talk",
    "pocket-panic"
  ],
  "Whirlpooling": [
    "spin",
    "shoe-vortex"
  ],
  "Whirring": [
    "spin",
    "wind-up"
  ],
  "Whisking": [
    "whisk"
  ],
  "Wibbling": [
    "wiggle"
  ],
  "Working": [
    "type",
    "wind-up",
    "hinge-tune"
  ],
  "Wrangling": [
    "run",
    "magnet",
    "shoe-lasso"
  ],
  "Zesting": [
    "whisk"
  ],
  "Zigzagging": [
    "warp"
  ],
  "Skateboarding": [
    "shoe-skateboard",
    "moonwalk",
    "waddle",
    "run",
    "chaos"
  ],
  "Coasting": [
    "shoe-skateboard",
    "moonwalk",
    "waddle",
    "run",
    "chaos"
  ],
  "Rolling": [
    "shoe-skateboard",
    "moonwalk",
    "waddle",
    "run",
    "chaos"
  ],
  "Kickflipping": [
    "brain-kickflip",
    "warp",
    "topsy",
    "forge",
    "juggle-glasses"
  ],
  "Headspinning": [
    "brain-kickflip",
    "warp",
    "topsy",
    "forge",
    "juggle-glasses"
  ],
  "Brainstorming": [
    "brain-kickflip",
    "warp",
    "topsy",
    "forge",
    "juggle-glasses"
  ],
  "Sneezing": [
    "sneeze",
    "bake",
    "eye-roll",
    "gust",
    "chaos"
  ],
  "Achooing": [
    "sneeze",
    "bake",
    "eye-roll",
    "gust",
    "chaos"
  ],
  "Sniffling": [
    "sneeze",
    "bake",
    "eye-roll",
    "gust",
    "chaos"
  ],
  "Pocket-patting": [
    "pocket-panic",
    "eye-roll",
    "talk"
  ],
  "Panicking": [
    "pocket-panic",
    "eye-roll",
    "talk"
  ],
  "Double-checking": [
    "pocket-panic",
    "eye-roll",
    "talk"
  ],
  "Dialing": [
    "shoe-phone",
    "float",
    "talk"
  ],
  "Calling": [
    "shoe-phone",
    "float",
    "talk",
    "megaphone"
  ],
  "Consulting": [
    "shoe-phone",
    "float",
    "talk"
  ],
  "Drumming": [
    "cheek-drums",
    "shimmy",
    "architect"
  ],
  "Beatboxing": [
    "cheek-drums",
    "shimmy",
    "architect"
  ],
  "Percussing": [
    "cheek-drums",
    "shimmy",
    "architect"
  ],
  "Polishing": [
    "glasses-clean",
    "idea",
    "compute",
    "read",
    "think",
    "bake"
  ],
  "Clarifying": [
    "glasses-clean",
    "idea",
    "compute",
    "read",
    "think",
    "bake"
  ],
  "Refocusing": [
    "glasses-clean",
    "idea",
    "compute",
    "read",
    "think",
    "bake"
  ],
  "Slurping": [
    "noodle-slurp",
    "stir",
    "boop"
  ],
  "Snacking": [
    "noodle-slurp",
    "stir",
    "boop"
  ],
  "Recharging": [
    "noodle-slurp",
    "stir",
    "boop"
  ],
  "Snoozing": [
    "nap",
    "idle",
    "think",
    "grow"
  ],
  "Napping": [
    "nap",
    "idle",
    "think",
    "grow",
    "mochi-melt"
  ],
  "Dreaming": [
    "nap",
    "idle",
    "think",
    "grow"
  ],
  "Yawning": [
    "stretch",
    "bake",
    "unwind",
    "idea"
  ],
  "Stretching": [
    "stretch",
    "bake",
    "unwind",
    "idea"
  ],
  "Waking": [
    "stretch",
    "bake",
    "unwind",
    "idea"
  ],
  "Sneaking": [
    "sneak",
    "waddle",
    "run",
    "tunnel"
  ],
  "Tiptoeing": [
    "sneak",
    "waddle",
    "run",
    "tunnel"
  ],
  "Slinking": [
    "sneak",
    "waddle",
    "run",
    "tunnel"
  ],
  "Peeking": [
    "peekaboo",
    "read",
    "think",
    "run",
    "type"
  ],
  "Peekabooing": [
    "peekaboo",
    "read",
    "think",
    "run",
    "type"
  ],
  "Checking": [
    "peekaboo",
    "read",
    "think",
    "run",
    "type",
    "lens-inspector"
  ],
  "Inflating": [
    "balloon-brain",
    "gust",
    "float",
    "bake",
    "sparkle"
  ],
  "Buoying": [
    "balloon-brain",
    "gust",
    "float",
    "bake",
    "sparkle"
  ],
  "Ballooning": [
    "balloon-brain",
    "gust",
    "float",
    "bake",
    "sparkle"
  ],
  "Hula-hooping": [
    "hula-hoop",
    "shimmy",
    "wiggle"
  ],
  "Waist-wiggling": [
    "hula-hoop",
    "shimmy",
    "wiggle"
  ],
  "Hoopla-ing": [
    "hula-hoop",
    "shimmy",
    "wiggle"
  ],
  "Tap-dancing": [
    "tap-dance",
    "moonwalk",
    "shimmy",
    "architect"
  ],
  "Heel-clicking": [
    "tap-dance",
    "moonwalk",
    "shimmy",
    "architect"
  ],
  "Clacking": [
    "tap-dance",
    "moonwalk",
    "shimmy",
    "architect"
  ],
  "High-kicking": [
    "cancan",
    "chaos",
    "run",
    "shimmy"
  ],
  "Cancanning": [
    "cancan",
    "chaos",
    "run",
    "shimmy"
  ],
  "Legging-it": [
    "cancan",
    "chaos",
    "run",
    "shimmy"
  ],
  "Ribboning": [
    "ribbon",
    "gust",
    "unwind",
    "sparkle"
  ],
  "Twirling": [
    "ribbon",
    "gust",
    "unwind",
    "sparkle"
  ],
  "Flourishing": [
    "ribbon",
    "gust",
    "unwind",
    "sparkle"
  ],
  "Magnetizing": [
    "magnet",
    "transform",
    "unwind",
    "run"
  ],
  "Attracting": [
    "magnet",
    "transform",
    "unwind",
    "run"
  ],
  "Polarizing": [
    "magnet",
    "transform",
    "unwind",
    "run"
  ],
  "Bubbling": [
    "bubbles",
    "float",
    "dissolve",
    "stir",
    "sparkle"
  ],
  "Bubble-blowing": [
    "bubbles",
    "float",
    "dissolve",
    "stir",
    "sparkle"
  ],
  "Effervescing": [
    "bubbles",
    "float",
    "dissolve",
    "stir",
    "sparkle"
  ],
  "Winding-up": [
    "wind-up",
    "type",
    "spin",
    "unwind",
    "compute"
  ],
  "Rewinding": [
    "wind-up",
    "type",
    "spin",
    "unwind",
    "compute"
  ],
  "Clockworking": [
    "wind-up",
    "type",
    "spin",
    "unwind",
    "compute"
  ],
  "Accordioning": [
    "accordion",
    "unwind",
    "wiggle",
    "architect",
    "transform",
    "shimmy"
  ],
  "Concertina-ing": [
    "accordion",
    "unwind",
    "wiggle",
    "architect",
    "transform",
    "shimmy"
  ],
  "Squeezing": [
    "accordion",
    "unwind",
    "wiggle",
    "architect",
    "transform",
    "shimmy"
  ],
  "Celebrating": [
    "confetti",
    "type",
    "idea",
    "sparkle",
    "chaos"
  ],
  "High-fiving": [
    "confetti",
    "type",
    "idea",
    "sparkle",
    "chaos"
  ],
  "Confetti-ing": [
    "confetti",
    "type",
    "idea",
    "sparkle",
    "chaos"
  ],
  "Lounging": [
    "hammock",
    "think",
    "idle",
    "stir"
  ],
  "Hammocking": [
    "hammock",
    "think",
    "idle",
    "stir"
  ],
  "Unwinding": [
    "hammock",
    "think",
    "idle",
    "stir"
  ],
  "Vacuuming": [
    "shoe-vortex",
    "warp",
    "spin",
    "dissolve"
  ],
  "Imploding": [
    "shoe-vortex",
    "warp",
    "spin",
    "dissolve"
  ],
  "Vanishing": [
    "shoe-vortex",
    "warp",
    "spin",
    "dissolve"
  ],
  "Mochifying": [
    "mochi-melt",
    "idle",
    "think",
    "nap"
  ],
  "Melting": [
    "mochi-melt",
    "idle",
    "think",
    "nap"
  ],
  "Dozing": [
    "mochi-melt",
    "idle",
    "think",
    "nap"
  ],
  "Conducting": [
    "maestro",
    "architect",
    "shimmy"
  ],
  "Cueing": [
    "maestro",
    "architect",
    "shimmy"
  ],
  "Syncopating": [
    "maestro",
    "architect",
    "shimmy"
  ],
  "Dripping": [
    "rain-check",
    "gust"
  ],
  "Weathering": [
    "rain-check",
    "gust"
  ],
  "Sheltering": [
    "rain-check",
    "gust"
  ],
  "Inspecting": [
    "lens-inspector",
    "read",
    "compute",
    "eye-roll",
    "think",
    "peekaboo"
  ],
  "Examining": [
    "lens-inspector",
    "read",
    "compute",
    "eye-roll",
    "think",
    "peekaboo"
  ],
  "Investigating": [
    "lens-inspector",
    "read",
    "compute",
    "eye-roll",
    "think",
    "peekaboo"
  ],
  "Laughing": [
    "belly-laugh",
    "chaos",
    "juggle-body"
  ],
  "Chuckling": [
    "belly-laugh",
    "chaos",
    "juggle-body"
  ],
  "Snickering": [
    "belly-laugh",
    "chaos",
    "juggle-body"
  ],
  "Blooming": [
    "bee-bloom",
    "grow"
  ],
  "Buzzing": [
    "bee-bloom",
    "grow"
  ],
  "Cross-pollinating": [
    "bee-bloom",
    "grow"
  ],
  "Lassoing": [
    "shoe-lasso",
    "run",
    "unwind",
    "juggle-glasses"
  ],
  "Rounding-up": [
    "shoe-lasso",
    "run",
    "unwind",
    "juggle-glasses"
  ],
  "Retrieving": [
    "shoe-lasso",
    "run",
    "unwind",
    "juggle-glasses"
  ],
  "Branching": [
    "branch-merge",
    "type",
    "compute",
    "transform"
  ],
  "Merging": [
    "branch-merge",
    "type",
    "compute",
    "transform"
  ],
  "Reconciling": [
    "branch-merge",
    "type",
    "compute",
    "transform"
  ],
  "Adjusting": [
    "hinge-tune",
    "forge",
    "juggle-glasses",
    "compute",
    "type"
  ],
  "Tightening": [
    "hinge-tune",
    "forge",
    "juggle-glasses",
    "compute",
    "type"
  ],
  "Troubleshooting": [
    "hinge-tune",
    "forge",
    "juggle-glasses",
    "compute",
    "type"
  ],
  "Shivering": [
    "snow-shiver",
    "transform",
    "forge",
    "bake",
    "gust"
  ],
  "Chattering": [
    "snow-shiver",
    "transform",
    "forge",
    "bake",
    "gust"
  ],
  "Defrosting": [
    "snow-shiver",
    "transform",
    "forge",
    "bake",
    "gust"
  ],
  "Flipping": [
    "pan-flip",
    "whisk",
    "stir",
    "bake"
  ],
  "Pan-tossing": [
    "pan-flip",
    "whisk",
    "stir",
    "bake"
  ],
  "Searing": [
    "pan-flip",
    "whisk",
    "stir",
    "bake"
  ],
  "Meditating": [
    "lotus-float",
    "float",
    "think"
  ],
  "Centering": [
    "lotus-float",
    "float",
    "think"
  ],
  "Attuning": [
    "lotus-float",
    "float",
    "think"
  ],
  "Announcing": [
    "megaphone",
    "talk",
    "shoe-phone"
  ],
  "Amplifying": [
    "megaphone",
    "talk",
    "shoe-phone"
  ],
  "Broadcasting": [
    "megaphone",
    "talk",
    "shoe-phone"
  ],
  "Hugging": [
    "self-hug",
    "boop",
    "sparkle",
    "shimmy",
    "float"
  ],
  "Appreciating": [
    "self-hug",
    "boop",
    "sparkle",
    "shimmy",
    "float"
  ],
  "Heartwarming": [
    "self-hug",
    "boop",
    "sparkle",
    "shimmy",
    "float"
  ],
  "Searching": [
    "flashlight-search",
    "tunnel",
    "read",
    "compute",
    "idea"
  ],
  "Scanning": [
    "flashlight-search",
    "tunnel",
    "read",
    "compute",
    "idea"
  ],
  "Illuminating": [
    "flashlight-search",
    "tunnel",
    "read",
    "compute",
    "idea"
  ]
} as const;
