// For hosts without their own CSS side-effect import declarations.
// Vite / Next.js projects usually already supply this type.
declare module '*.css';
