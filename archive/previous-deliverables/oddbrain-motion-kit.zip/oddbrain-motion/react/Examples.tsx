'use client';

import { useState } from 'react';
import { Oddbrain, OddbrainLoader } from './Oddbrain';
import { motionSrc } from './resolve-motion';

export function AnotherTake() {
  const [take, setTake] = useState(0);
  return (
    <div>
      <Oddbrain word="Befuddling" variant={take} size={140} />
      <span role="status">Befuddling…</span>
      <button onClick={() => setTake(n => n + 1)}>Another take</button>
    </div>
  );
}

export function NewSlapstick() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
      <Oddbrain motion="shoe-skateboard" size={160} label="Skateboarding on its own shoe" />
      <Oddbrain motion="cheek-drums" size={160} label="Playing its own brain cheeks as bongos" />
      <Oddbrain motion="hammock" size={160} label="Lounging in a tiny hammock" />
    </div>
  );
}

export function ChatStatus({ word = 'Brewing' }: { word?: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <Oddbrain word={word} size={72} />
      {/* The picture is decorative; the adjacent text carries the status. */}
      <span role="status" aria-live="polite">{word}…</span>
    </div>
  );
}

export function CompactStatus() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <OddbrainLoader size={32} label="" />
      <span role="status">Befuddling…</span>
    </div>
  );
}

export function Welcome() {
  const [replay, setReplay] = useState(0);
  return (
    <section>
      <Oddbrain motion="assemble" size={260} replayKey={replay} label="A brain mascot assembling itself" />
      <button onClick={() => setReplay(n => n + 1)}>Replay entrance</button>
    </section>
  );
}

export function LightweightStatus({ word }: { word: string }) {
  // For this version, copy svg/*.svg to public/oddbrain/.
  // Import motionSrc from './resolve-motion' directly to avoid bundling SVG markup.
  return <img src={motionSrc(word)} width={72} height={72} alt="" />;
}


export function ReferenceRebuilds() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24, flexWrap: 'wrap' }}>
      <Oddbrain motion="mochi-melt" size={180} label="A sleepy brain flattened into mochi" />
      <Oddbrain motion="maestro" size={160} label="Conducting three uncooperative notes" />
      <Oddbrain motion="shoe-lasso" size={180} label="Retrieving its runaway shoe" />
    </div>
  );
}

export function CompletionCue() {
  const [replay, setReplay] = useState(0);
  return (
    <section>
      <Oddbrain motion="shades-drop" size={180} replayKey={replay} label="Done. Naturally." />
      <p role="status">All done.</p>
      <button onClick={() => setReplay(n => n + 1)}>Replay completion</button>
    </section>
  );
}
