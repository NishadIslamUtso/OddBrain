import { statusToMotion, type FullMotionId } from './status-map';
import { statusVariants } from './status-variants';

/** Case-, accent-, punctuation-, and trailing-ellipsis-insensitive. */
export function normalizeStatus(value: string): string {
  return value
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

const lookup = new Map<string, FullMotionId>(
  Object.entries(statusToMotion).map(([word, motion]) => [normalizeStatus(word), motion]),
);
const alternateLookup = new Map<string, readonly FullMotionId[]>(
  Object.entries(statusVariants).map(([word, motions]) => [normalizeStatus(word), motions]),
);

/** Original defaults are stable; unknown words have an intentional, calm fallback. */
export function resolveMotion(word: string, fallback: FullMotionId = 'think'): FullMotionId {
  return lookup.get(normalizeStatus(word)) ?? fallback;
}

/** Alternate takes are opt-in. The first item always matches resolveMotion(word). */
export function motionVariants(word: string, fallback: FullMotionId = 'think'): readonly FullMotionId[] {
  return alternateLookup.get(normalizeStatus(word)) ?? [resolveMotion(word, fallback)];
}

/** Deterministic across server/client renders: select once per request, not every render. */
export function resolveMotionVariant(word: string, variant = 0, fallback: FullMotionId = 'think'): FullMotionId {
  const pool = motionVariants(word, fallback);
  const index = Number.isFinite(variant) ? Math.trunc(variant) : 0;
  return pool[((index % pool.length) + pool.length) % pool.length];
}

/** Copy svg/ into public/oddbrain/. No SVG strings are imported by this module. */
export function motionSrc(word: string, basePath = '/oddbrain', variant = 0): string {
  return `${basePath.replace(/\/$/, '')}/${resolveMotionVariant(word, variant)}.svg`;
}
