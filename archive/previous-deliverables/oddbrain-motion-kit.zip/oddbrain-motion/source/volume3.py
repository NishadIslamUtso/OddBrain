"""Volume 03: high-level ideas curated from the user's references, rebuilt in our rig.
No reference SVG, prop geometry, keyframes, styling, scripts, or fonts are imported.
The base artwork remains the user's original source/original-mascot.svg.
"""
import math


def register(add, star, dot):
    INK, PURPLE, PINK = '#393A35', '#8C6AA7', '#FF98A5'
    CREAM, YELLOW, GREEN = '#FFF9F1', '#EDC77E', '#9AAD8E'
    new = []

    def reg(slug, name, category, seconds, description, words, suggested, concept, twist, energy='medium', **kw):
        c = add(slug, name, category, seconds, description, words.split('|')[0] if words else 'Done. Naturally', energy, **kw)
        c.volume = 3
        c.added_words = words.split('|') if words else []
        c.suggested_words = suggested.split('|') if suggested else []
        c.reference_idea, c.rebuilt_twist = concept, twist
        new.append(c)
        return c

    def lids():
        return '<g stroke="#393A35" stroke-width="5" stroke-linecap="round"><path d="M273 271q21 16 42 0m134 0q21 16 42 0"/></g>'

    def mitt(x, y, r=25):
        return f'<ellipse cx="{x}" cy="{y}" rx="{r}" ry="{r+1}" fill="{INK}"/><circle cx="{x-11}" cy="{y-17}" r="11" fill="{INK}"/>'

    def snowflake(x,y,r=10,cls=''):
        return f'<g class="{cls}" stroke="#B9A7CA" stroke-width="3.5" stroke-linecap="round"><path d="M{x-r} {y}h{2*r}m{-r} {-r}v{2*r}m{-r*.7:g} {-r*1.7:g}l{r*1.4:g} {r*1.4:g}m{-r*1.4:g} 0l{r*1.4:g} {-r*1.4:g}"/></g>'

    # 61. Flat resting geometry, with the hands, glasses and bubble staged together.
    c = reg('mochi-melt','Out of office. Out of bones.','Thinking',4.8,
        'Melts into a low sleepy brain-pancake, shoes kicked aside, while a pearl-lilac sleep bubble slowly grows and lets go',
        'Mochifying|Melting|Dozing','Lollygagging|Moseying|Musing|Dilly-dallying|Napping',
        'Pasted mochi SVG: flattened sleep and kicked-off shoes',
        'A genuinely low floor pose, visible shoes, closed lids, and a bubble attached to the breathing face', 'low')
    c.detached_shoes = {'left','right'}
    c.anim('.rig-head',4.8,{'0%,100%':'transform:translateY(165px) scale(1.015,.55);','50%':'transform:translateY(159px) scale(1,.58);'})
    c.style('.rig-glasses','transform:translate(-4px,-99px) rotate(-9deg) scale(.88);')
    c.mouth_markup = '<ellipse cx="379" cy="342" rx="10" ry="6" fill="#393A35"/>'
    c.head_extra += lids()
    c.left_arm_markup = '<path d="M145 551 C113 587 146 625 190 621" stroke="#393A35" stroke-width="21" stroke-linecap="round"/>'+mitt(190,621)
    c.right_arm_markup = '<path d="M580 551 C611 587 583 625 540 621" stroke="#393A35" stroke-width="20" stroke-linecap="round"/>'+mitt(540,621)
    for arm in ['.rig-left-arm','.rig-right-arm']:
        c.anim(arm,4.8,{'0%,100%':'transform:translateY(0);','50%':'transform:translateY(-4px);'})
    c.style('.rig-left-leg','transform:translate(7px,150px) scaleY(.13);')
    c.style('.rig-right-leg','transform:translate(-7px,150px) scaleY(.13);')
    c.style('.rig-shoe-left','transform:translate(-157px,15px) rotate(-22deg) scale(.85);')
    c.style('.rig-shoe-right','transform:translate(217px,17px) rotate(18deg) scale(.85);')
    c.rig_extra += '<g class="prop-bubble-anchor"><g class="prop-mochi-bubble"><circle cx="409" cy="551" r="24" fill="#EEE5F4" fill-opacity=".3" stroke="#B79BC9" stroke-width="3.5"/><path d="M399 537q10-8 18 0" stroke="#FFF9F1" stroke-width="5" stroke-linecap="round"/></g></g>'
    c.anim('.prop-bubble-anchor',4.8,{'0%,100%':'transform:translateY(0);','50%':'transform:translateY(-9px);'})
    c.style('.prop-mochi-bubble','transform-origin:383px 555px;')
    c.anim('.prop-mochi-bubble',4.8,{'0%,100%':'transform:scale(.22);opacity:.15;','58%':'transform:scale(1.35);opacity:.8;','77%':'transform:scale(1.55);opacity:.65;','84%':'transform:translate(13px,-16px) scale(1.6);opacity:0;','97%':'transform:scale(.22);opacity:0;'})
    c.back += '<g class="fx-mochi-z" stroke="#B09AC0" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"><path d="M523 355h22l-22 24h22m14-57h27l-27 29h27"/></g>'
    c.anim('.fx-mochi-z',4.8,{'0%,100%':'transform:translateY(7px);opacity:.15;','60%':'transform:translateY(-16px);opacity:.7;'})
    c.style('.rig-ground','transform:translateY(-2px) scaleX(1.45);transform-origin:356px 658px;')

    # 62. Wand and hand share a shoulder transform, so they cannot drift apart.
    c = reg('maestro','A very small, very serious maestro','Dancing',2.8,
        'Conducts three unruly notes with a tiny baton, cueing them back into line with an unnecessarily stern nod',
        'Conducting|Cueing|Syncopating','Orchestrating|Harmonizing|Composing|Choreographing',
        '17-scene reference: conducting musical notes',
        'A shoulder-linked baton, off-beat note responses and a smugly serious head nod', 'medium')
    arm_frames={'0%,100%':'transform:rotate(106deg);','25%':'transform:rotate(126deg);','49%':'transform:rotate(99deg);','72%':'transform:rotate(119deg);'}
    c.anim('.rig-right-arm',2.8,arm_frames)
    c.rig_extra += '<g class="prop-baton"><path d="M638 480L498 484" stroke="#FFF9F1" stroke-width="8" stroke-linecap="round"/><path d="M638 480l-31 1" stroke="#8C6AA7" stroke-width="11" stroke-linecap="round"/></g>'
    c.style('.prop-baton','transform-origin:580px 358px;')
    c.anim('.prop-baton',2.8,arm_frames)
    c.anim('.rig-left-arm',2.8,{'0%,100%':'transform:rotate(-61deg);','25%':'transform:rotate(-110deg);','50%':'transform:rotate(-74deg);','75%':'transform:rotate(-119deg);'})
    c.anim('.rig-head',2.8,{'0%,100%':'transform:rotate(-2deg);','25%':'transform:translateY(5px) rotate(3deg);','75%':'transform:translateY(3px) rotate(-3deg);'})
    for i,(x,y) in enumerate([(116,201),(569,106),(655,242)]):
        c.front += f'<g class="fx-score-{i}" fill="{[PURPLE,"#D9A1AE",YELLOW][i]}"><path d="M{x} {y}v-45l28-7v13l-21 5v34Z"/><ellipse cx="{x-5}" cy="{y}" rx="12" ry="8"/></g>'
        c.style(f'.fx-score-{i}',f'transform-origin:{x}px {y}px;')
        c.anim(f'.fx-score-{i}',2.8,{'0%,100%':'transform:translateY(4px) rotate(-7deg);opacity:.35;','25%':'transform:translateY(-15px) rotate(7deg);opacity:1;','55%':'transform:translateY(1px) rotate(-3deg);opacity:.65;'},delay=-i*.35)
    c.anim('.rig-shoe-left',1.4,{'0%,100%':'transform:rotate(0);','45%':'transform:rotate(-8deg);'})

    # 63. A personal cloud and a genuinely inadequate off-centre umbrella.
    c = reg('rain-check','The umbrella is mostly decorative','Magic',3.6,
        'Carries a tiny off-centre umbrella beneath its own raincloud, protecting one cheek and leaving the other mildly offended',
        'Dripping|Weathering|Sheltering','Gusting|Thundering|Precipitating|Billowing',
        '17-scene raincloud + 79-loop umbrella idea',
        'Small lilac umbrella, quiet gray rain, no lightning flashes, and an unamused bare-brain stance', 'low')
    c.mouth_markup = '<path d="M351 347q27-15 54-3" stroke="#393A35" stroke-width="6" stroke-linecap="round"/>'
    c.style('.rig-right-arm','transform:rotate(81deg);')
    c.anim('.rig-left-arm',3.6,{'0%,100%':'transform:rotate(10deg);','50%':'transform:rotate(-17deg);'})
    c.anim('.rig-head',3.6,{'0%,100%':'transform:rotate(-2deg);','50%':'transform:rotate(1deg) translateY(3px);'})
    c.back += '<g class="prop-cloud" fill="#D2C8DB"><path d="M268 101 C243 100 243 68 267 65 C268 35 311 29 325 48 C342 19 387 25 396 49 C424 31 456 51 451 77 C479 81 475 106 449 106H272Z"/></g>'
    c.anim('.prop-cloud',3.6,{'0%,100%':'transform:translateX(-7px);','50%':'transform:translateX(7px);'})
    c.rig_extra += '<g class="prop-umbrella"><path d="M470 435L499 144" stroke="#8C6AA7" stroke-width="7" stroke-linecap="round"/><path d="M403 176 Q498 32 594 176 Q561 159 548 180 Q521 159 499 180 Q473 158 451 180 Q427 161 403 176Z" fill="#D8C6E4" stroke="#AC8DBF" stroke-width="5" stroke-linejoin="round"/><path d="M499 144q-28 3-48 36m48-36q29 2 49 36" stroke="#B79DC9" stroke-width="3"/></g>'
    for i,(x,y) in enumerate([(252,129),(292,139),(338,120),(381,133),(263,122)]):
        c.front += f'<path class="fx-rain-{i}" d="M{x} {y}l-5 16" stroke="#A7A4BC" stroke-width="4" stroke-linecap="round"/>'
        c.anim(f'.fx-rain-{i}',1.2,{'0%':'transform:translateY(0);opacity:0;','20%':'opacity:.65;','100%':'transform:translate(-16px,195px);opacity:0;'},'linear',delay=-i*.23)
    c.rig_extra += '<g class="fx-wet" stroke="#B5A7C4" stroke-width="4" stroke-linecap="round"><path d="M105 321l-4 13m20-7-1 8"/></g>'
    c.anim('.fx-wet',3.6,{'0%,100%':'opacity:0;','45%':'opacity:.7;','70%':'opacity:0;'})

    # 64. The magnified eye is rebuilt inside a clipped lens, not pasted over opaque shades.
    c = reg('lens-inspector','Enhance. No, the other wrinkle.','Thinking',3.6,
        'Lifts its sunglasses and inspects one enormous magnified eye, scratching the other brain cheek as if that will help',
        'Inspecting|Examining|Investigating','Perusing|Deciphering|Puzzling|Considering|Checking',
        '14-clip reference: detective magnifier',
        'Original eyes and wrinkles retained; one optical lens enlarges one eye and the arm grips its handle', 'low', eyes=True)
    c.style('.rig-glasses','transform:translate(0,-104px) rotate(2deg) scale(.88);')
    c.right_arm_markup = '<path d="M580 358 Q612 421 553 402" stroke="#393A35" stroke-width="20" stroke-linecap="round"/>'+mitt(543,393)
    c.anim('.rig-left-arm',1.8,{'0%,100%':'transform:rotate(-159deg);','40%':'transform:rotate(-165deg);','70%':'transform:rotate(-161deg);'})
    c.extra_defs = '<clipPath id="inspection-lens"><circle cx="470" cy="274" r="53"/></clipPath>'
    c.rig_extra += '<g class="prop-magnifier"><path d="M507 315l36 78" stroke="#8C6AA7" stroke-width="14" stroke-linecap="round"/><g clip-path="url(#inspection-lens)"><circle cx="470" cy="274" r="44" fill="#FFF9F1"/><g class="prop-enlarged-pupil"><circle cx="470" cy="267" r="17" fill="#393A35"/><circle cx="465" cy="262" r="5" fill="#FFF9F1"/></g></g><circle cx="470" cy="274" r="58" fill="#E9E0F2" fill-opacity=".08" stroke="#8C6AA7" stroke-width="9"/><path d="M434 245q16-21 39-20" stroke="#FFF9F1" stroke-width="5" stroke-linecap="round" opacity=".85"/></g>'
    c.anim('.prop-magnifier',3.6,{'0%,100%':'transform:translateX(-3px);','50%':'transform:translateX(4px);'})
    c.anim('.rig-right-arm',3.6,{'0%,100%':'transform:translateX(-3px);','50%':'transform:translateX(4px);'})
    c.anim('.prop-enlarged-pupil',3.6,{'0%,100%':'transform:translate(-6px,0);','50%':'transform:translate(7px,6px);'})
    c.anim('.pupil-left',3.6,{'0%,100%':'transform:translate(8px,14px);','50%':'transform:translate(-5px,14px);'})

    # 65. Laughter is a squash-and-release, not a full-body high-frequency vibration.
    c = reg('belly-laugh','An entirely unreasonable chuckle','Mischief',2.8,
        'Laughs from both brain cheeks, hugging its own lower lobes while the sunglasses bounce half a beat behind',
        'Laughing|Chuckling|Snickering','Frolicking|Hullaballooing|Razzmatazzing|Shenaniganing',
        '14-clip reference: belly laughter',
        'Soft cheek squash, restrained joy droplets, original glasses, and a delayed recovery breath', 'high', split=True)
    c.mouth_markup = '<path d="M331 327 Q379 337 427 327 C427 398 331 398 331 327Z" fill="#393A35"/><path d="M341 337q38 6 76 0l-4 11q-34 5-68 0Z" fill="#FFF9F1"/><path d="M353 375q27-13 52 0" stroke="#FF98A5" stroke-width="10" stroke-linecap="round"/>'
    c.anim('.rig-root',1.4,{'0%,100%':'transform:translateY(2px) rotate(-2deg);','40%':'transform:translateY(-10px) rotate(3deg);','72%':'transform:translateY(4px) rotate(-1deg);'})
    c.anim('.lobe-left',.7,{'0%,100%':'transform:scale(1);','45%':'transform:scale(1.025,.965);'})
    c.anim('.lobe-right',.7,{'0%,100%':'transform:scale(1);','45%':'transform:scale(1.025,.965);'})
    c.anim('.rig-left-arm',.7,{'0%,100%':'transform:rotate(-62deg);','45%':'transform:rotate(-79deg);'})
    c.anim('.rig-right-arm',.7,{'0%,100%':'transform:rotate(79deg);','45%':'transform:rotate(62deg);'})
    c.anim('.rig-mouth',.7,{'0%,100%':'transform:scale(1,.65);','45%':'transform:scale(1.05,1);'})
    c.anim('.rig-glasses',1.4,{'0%,100%':'transform:translateY(0) rotate(0);','46%':'transform:translateY(-12px) rotate(-3deg);','73%':'transform:translateY(3px) rotate(2deg);'},delay=-.07)
    for i,(x,y,dx) in enumerate([(233,291,-20),(530,281,22)]):
        c.front += f'<path class="fx-joy-{i}" d="M{x} {y}q-12 17 0 20q12-3 0-20Z" fill="#B6A2C8"/>'
        c.anim(f'.fx-joy-{i}',1.4,{'0%':'opacity:0;transform:translate(0,0);','25%':'opacity:.65;','100%':f'opacity:0;transform:translate({dx}px,34px);'},delay=-i*.7)

    # 66. One-shot completion cue: the body is already assembled. Holds the final pose.
    c = reg('shades-drop','Done. Naturally.','Special',2.2,
        'Waits for its sunglasses to drop into place, gives a tiny satisfied lean, and stays smug without restarting',
        '', '', '14-clip reference: sunglasses-drop confidence cue',
        'A brief completion microinteraction, original shades, no costume or power aura', 'low', loop=False, eyes=True)
    c.anim('.rig-glasses',2.2,{'0%,18%':'transform:translateY(-185px) rotate(-10deg) scale(.95);','57%':'transform:translateY(8px) rotate(3deg) scale(1);','70%':'transform:translateY(-5px) rotate(-2deg);','84%,100%':'transform:translateY(0) rotate(0);'})
    for sel in ['.pupil-left','.pupil-right']:
        c.anim(sel,2.2,{'0%,35%':'transform:translateY(-2px);','60%,100%':'transform:translateY(10px);'})
    c.anim('.rig-root',2.2,{'0%,45%':'transform:rotate(0);','74%':'transform:rotate(-3deg);','100%':'transform:rotate(-1deg);'})
    c.anim('.rig-right-arm',2.2,{'0%,42%':'transform:rotate(0);','70%':'transform:rotate(28deg);','100%':'transform:rotate(12deg);'})
    c.rig_extra += star(530,242,13,CREAM,'fx-shades-glint')
    c.style('.fx-shades-glint','opacity:0;')
    c.anim('.fx-shades-glint',2.2,{'0%,62%,100%':'opacity:0;','74%':'opacity:.8;','90%':'opacity:0;'})

    # 67. Bee trajectory is hand-authored around a new little head-flower.
    c = reg('bee-bloom','Your thought has attracted a bee','Making',4.4,
        'Grows a small flower from its central cleft, then politely fails to shoo away a bee that wants to inspect it',
        'Blooming|Buzzing|Cross-pollinating','Cultivating|Germinating|Pollinating|Photosynthesizing|Sprouting',
        '17-scene reference: sprout, flower and bee',
        'A tiny head-flower, a coherent landing arc, and an annoyed polite shoo instead of a new outfit', 'medium')
    c.head_extra += '<g class="prop-head-flower"><path d="M356 149q-6-34 0-60" stroke="#91A280" stroke-width="7" stroke-linecap="round"/><path d="M355 122q-36 5-30-20q27-3 30 20" fill="#A5B697"/><g fill="#CFB5DA"><ellipse cx="356" cy="75" rx="13" ry="22"/><ellipse cx="356" cy="75" rx="13" ry="22" transform="rotate(60 356 75)"/><ellipse cx="356" cy="75" rx="13" ry="22" transform="rotate(120 356 75)"/></g><circle cx="356" cy="75" r="10" fill="#EDC77E"/></g>'
    c.rig_extra += '<g class="prop-bee"><ellipse cx="0" cy="0" rx="17" ry="12" fill="#E2C07F" stroke="#393A35" stroke-width="3"/><path d="M-6-10v20m10-20v20" stroke="#393A35" stroke-width="5"/><circle cx="14" cy="-2" r="7" fill="#393A35"/><g class="prop-bee-wings" fill="#FFF9F1" fill-opacity=".85" stroke="#CDBDDA" stroke-width="2"><ellipse cx="-7" cy="-17" rx="8" ry="13" transform="rotate(-25 -7 -17)"/><ellipse cx="5" cy="-18" rx="8" ry="13" transform="rotate(20 5 -18)"/></g></g>'
    c.style('.prop-bee','transform-origin:0px 0px;')
    c.style('.prop-bee-wings','transform-origin:0px -7px;')
    frames={}
    for step in range(49):
        t=step/48
        if t<.42:
            u=t/.42; x=604+(366-604)*u; y=170+(68-170)*u-65*math.sin(math.pi*u)
        elif t<.57:
            u=(t-.42)/.15; x=366+3*math.sin(u*math.pi*2); y=68+2*math.sin(u*math.pi*2)
        else:
            u=(t-.57)/.43; x=366+(604-366)*u; y=68+(170-68)*u-55*math.sin(math.pi*u)
        frames[f'{t*100:g}%']=f'transform:translate({x:.2f}px,{y:.2f}px) rotate({5*math.sin(t*math.pi*2):.2f}deg);'
    c.anim('.prop-bee',4.4,frames,'linear')
    c.anim('.prop-bee-wings',.2,{'0%,100%':'transform:scaleY(1);','50%':'transform:scaleY(.35);'})
    c.anim('.rig-head',4.4,{'0%,100%':'transform:rotate(0);','43%,57%':'transform:rotate(-3deg);'})
    c.anim('.rig-right-arm',4.4,{'0%,100%':'transform:rotate(0);','43%':'transform:rotate(142deg);','50%':'transform:rotate(127deg);','57%':'transform:rotate(145deg);','70%':'transform:rotate(10deg);'})

    # 68. Sampled rope geometry keeps the curve tied to both the hand and moving loop.
    c = reg('shoe-lasso','Retrieving one uncooperative shoe','Mischief',4.8,
        'Lets a purple shoe escape, catches it with a little lasso, and reels it back onto the waiting sock',
        'Lassoing|Rounding-up|Retrieving','Wrangling|Herding|Mustering|Finagling',
        '79-loop reference: lasso and herding',
        'The runaway is its own shoe; an eight-segment sampled rope stays connected throughout the catch', 'high')
    c.detached_shoes = {'right'}
    c.style('.rig-right-arm','transform:rotate(90deg);')
    c.anim('.rig-left-arm',4.8,{'0%,100%':'transform:rotate(8deg);','36%':'transform:rotate(-30deg);','73%':'transform:rotate(-61deg);'})
    c.anim('.rig-head',4.8,{'0%,100%':'transform:rotate(0);','28%,46%':'transform:rotate(3deg);','74%':'transform:rotate(-2deg);'})
    c.rig_extra += '<g class="prop-lasso-loop"><ellipse cx="450" cy="95" rx="128" ry="42" stroke="#B59DBA" stroke-width="5"/></g>'
    c.style('.prop-lasso-loop','transform-origin:450px 95px;')
    for i in range(8):
        c.rig_back += f'<path class="prop-rope-{i}" d="M0 0H100" stroke="#B59DBA" stroke-width="4" stroke-linecap="round"/>'
        c.style(f'.prop-rope-{i}','transform-origin:0px 0px;')
    def motion(t):
        if t<.24:
            cx,cy,scale,angle=450,95,.85,12*math.sin(t/.24*math.pi*2)
        elif t<.4:
            u=(t-.24)/.16;cx=450+153*u;cy=95+495*u*u;scale=.85-.43*u;angle=0
        elif t<.48:cx,cy,scale,angle=603,590,.42,0
        elif t<.78:
            u=(t-.48)/.3;cx=603-180*u;cy=590-18*math.sin(math.pi*u);scale=.42;angle=0
        elif t<.88:cx,cy,scale,angle=423,590,.42,0
        else:cx,cy,scale,angle=450,95,.85,0
        opacity=1 if t<.82 else max(0,1-(t-.82)/.05) if t<.87 else 0 if t<.94 else (t-.94)/.06
        return cx,cy,scale,angle,opacity
    loop_frames,shoe_frames={},{}
    ropes=[{} for _ in range(8)]
    for step in range(81):
        t=step/80;key=f'{t*100:g}%';cx,cy,scale,angle,op=motion(t);a=math.radians(angle)
        loop_frames[key]=f'transform:translate({cx-450:.3f}px,{cy-95:.3f}px) rotate({angle:.3f}deg) scale({scale:.4f});opacity:{op:.3f};'
        if t<.08:sx,sy,rot=423,610,0
        elif t<.24:
            u=(t-.08)/.16;sx=423+180*u;sy=610-78*math.sin(math.pi*u);rot=18*math.sin(math.pi*u)
        elif t<.48:sx,sy,rot=603,610,0
        elif t<.78:sx,sy,rot=cx,cy+20,0
        else:sx,sy,rot=423,610,0
        shoe_frames[key]=f'transform:translate({sx-423:.3f}px,{sy-610:.3f}px) rotate({rot:.3f}deg);'
        end=(cx-42*scale*math.sin(a),cy+42*scale*math.cos(a));start=(458,415)
        control=((start[0]+end[0])/2-35,(start[1]+end[1])/2+30)
        pts=[]
        for j in range(9):
            u=j/8;pts.append(((1-u)**2*start[0]+2*(1-u)*u*control[0]+u*u*end[0],(1-u)**2*start[1]+2*(1-u)*u*control[1]+u*u*end[1]))
        for j in range(8):
            x,y=pts[j];dx,dy=pts[j+1][0]-x,pts[j+1][1]-y;l=math.hypot(dx,dy) or 1
            ropes[j][key]=f'transform:matrix({dx/100:.6f},{dy/100:.6f},{-dy/l:.6f},{dx/l:.6f},{x:.4f},{y:.4f});opacity:{op:.3f};'
    c.anim('.prop-lasso-loop',4.8,loop_frames,'linear')
    c.anim('.rig-shoe-right',4.8,shoe_frames,'linear')
    for j in range(8):c.anim(f'.prop-rope-{j}',4.8,ropes[j],'linear')

    # 69. A readable fork/merge task, with three deliberately timed stages.
    c = reg('branch-merge','Two ideas. One slightly better idea.','Making',3.6,
        'Pulls a little branch graph into two paths, watches them diverge, then merges them into a single satisfied dot',
        'Branching|Merging|Reconciling','Gitifying|Computing|Combobulating|Recombobulating|Synthesizing',
        '79-loop reference: branching / Gitifying',
        'A small cream graph card, explicit fork-and-merge timing, and no imported product logo', 'medium')
    c.style('.rig-left-arm','transform:rotate(-77deg);')
    c.style('.rig-right-arm','transform:rotate(77deg);')
    c.rig_extra += '<g class="prop-merge-card"><rect x="247" y="425" width="238" height="133" rx="17" fill="#FFF9F1" stroke="#C4AFD0" stroke-width="5"/><path class="prop-branch-a" d="M281 492H307Q322 492 322 465V457H393Q411 457 411 478V492H453" stroke="#B99ACB" stroke-width="6" stroke-linecap="round" pathLength="100" stroke-dasharray="100"/><path class="prop-branch-b" d="M307 492Q322 492 322 521H393Q411 521 411 499V492" stroke="#D9A8B6" stroke-width="6" stroke-linecap="round" pathLength="100" stroke-dasharray="100"/><circle cx="281" cy="492" r="10" fill="#8C6AA7"/><circle class="prop-branch-node-a" cx="354" cy="457" r="9" fill="#C6ADD5"/><circle class="prop-branch-node-b" cx="354" cy="521" r="9" fill="#E3BBC5"/><circle class="prop-merged-node" cx="453" cy="492" r="12" fill="#EDC77E"/></g>'
    for sel,delay in [('.prop-branch-a',0),('.prop-branch-b',-.18)]:
        c.anim(sel,3.6,{'0%,100%':'stroke-dashoffset:100;opacity:0;','8%':'opacity:1;','63%,87%':'stroke-dashoffset:0;opacity:1;','98%':'stroke-dashoffset:0;opacity:0;'},'linear',delay=delay)
    for sel in ['.prop-branch-node-a','.prop-branch-node-b']:
        c.anim(sel,3.6,{'0%,22%,100%':'opacity:.12;','44%,80%':'opacity:1;','96%':'opacity:.12;'})
    c.style('.prop-merged-node','transform-origin:453px 492px;')
    c.anim('.prop-merged-node',3.6,{'0%,58%,100%':'transform:scale(.3);opacity:.2;','74%':'transform:scale(1.2);opacity:1;','86%':'transform:scale(1);opacity:1;','98%':'opacity:.2;'})
    c.anim('.rig-head',3.6,{'0%,100%':'transform:rotate(-2deg);','73%':'transform:translateY(-5px) rotate(3deg);'})

    # 70. The spanner actually pivots on the original left spectacle hinge.
    c = reg('hinge-tune','Self-service, no warranty','Making',3.2,
        'Tightens its own sunglasses hinge with a little spanner, checking the fit after three overconfident turns',
        'Adjusting|Tightening|Troubleshooting','Tinkering|Finagling|Deciphering|Determining|Working',
        '79-loop reference: wrench / tinkering',
        'The repair target is the mascot itself: a shoulder-linked hand and a spanner seated on its spectacle hinge', 'medium')
    c.anim('.rig-left-arm',.8,{'0%,100%':'transform:rotate(-125deg);','50%':'transform:rotate(-128deg);'})
    c.rig_extra += '<g class="prop-spanner"><path d="M262 318l-37-61" stroke="#BDA7CA" stroke-width="13" stroke-linecap="round"/><path d="M219 228 C204 230 203 247 213 257 C223 266 240 262 243 249L230 251L224 241L231 229Z" fill="#D7C8E1" stroke="#8C6AA7" stroke-width="4" stroke-linejoin="round"/><circle cx="263" cy="318" r="3" fill="#FFF9F1"/></g>'
    c.style('.prop-spanner','transform-origin:225px 246px;')
    c.anim('.prop-spanner',.8,{'0%,100%':'transform:rotate(-5deg);','50%':'transform:rotate(7deg);'})
    c.style('.rig-glasses','transform-origin:225px 246px;')
    c.anim('.rig-glasses',3.2,{'0%,100%':'transform:rotate(0);','25%':'transform:rotate(-1deg);','50%':'transform:rotate(1deg);','75%':'transform:rotate(-1deg);'})
    c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(0);','75%':'transform:rotate(19deg);'})

    # 71. Pink stays pink. Cold is communicated by gesture, breath and a few quiet flakes.
    c = reg('snow-shiver','Still refusing to wear an outfit','Magic',3.6,
        'Shivers through a few lilac snowflakes, hugging its brain cheeks and tapping its purple toes for warmth',
        'Shivering|Chattering|Defrosting','Crystallizing|Tempering|Frosting|Precipitating',
        '79-loop reference: frost / snow',
        'No blue recolour, coat or hat: quiet flakes, a little breath puff and warm original pink artwork', 'medium')
    c.anim('.rig-root',.9,{'0%,100%':'transform:translateX(-2px) rotate(-.6deg);','25%':'transform:translateX(2px) rotate(.6deg);','50%':'transform:translateX(-1px) rotate(-.4deg);','75%':'transform:translateX(1px) rotate(.4deg);'})
    c.style('.rig-left-arm','transform:rotate(-76deg);')
    c.style('.rig-right-arm','transform:rotate(76deg);')
    c.mouth_markup = '<rect x="361" y="337" width="37" height="15" rx="7" fill="#FFF9F1" stroke="#393A35" stroke-width="4"/><path d="M370 338v12m9-12v12m9-12v12" stroke="#393A35" stroke-width="2"/>'
    c.anim('.rig-mouth',.45,{'0%,100%':'transform:scaleY(.65);','50%':'transform:scaleY(1);'})
    c.anim('.rig-shoe-left',1.8,{'0%,100%':'transform:rotate(0);','25%':'transform:rotate(-10deg);','50%':'transform:rotate(0);'})
    c.anim('.rig-shoe-right',1.8,{'0%,50%,100%':'transform:rotate(0);','75%':'transform:rotate(-10deg);'})
    for i,(x,y,r) in enumerate([(88,140,10),(205,72,8),(551,78,10),(653,229,9)]):
        c.front += snowflake(x,y,r,f'fx-snow-{i}')
        c.anim(f'.fx-snow-{i}',3.6,{'0%':'transform:translate(-4px,0);opacity:0;','18%':'opacity:.65;','100%':'transform:translate(15px,98px);opacity:0;'},'linear',delay=-i*.8)
    c.front += '<g class="fx-cold-breath" fill="#E4DCEC" opacity="0"><ellipse cx="426" cy="347" rx="17" ry="8"/><ellipse cx="447" cy="344" rx="11" ry="10"/></g>'
    c.anim('.fx-cold-breath',3.6,{'0%,100%':'transform:translate(0,0);opacity:0;','40%':'opacity:.65;','75%':'transform:translate(28px,-8px);opacity:0;'})

    # 72. A pan toss, not another stir loop. The pancake is a newly drawn tiny prop.
    c = reg('pan-flip','A highly avoidable pancake incident','Cooking',3.2,
        'Flips a little golden pancake high above a tiny pan, catches it with unnecessary swagger, and ignores one small flame',
        'Flipping|Pan-tossing|Searing','Flambéing|Sautéing|Cooking|Caramelizing|Baking',
        '79-loop reference: sauté / flambé',
        'An actual toss-and-catch with a hand-held pan, one restrained warm flame, and no chef costume', 'medium')
    c.style('.rig-left-arm','transform:rotate(-70deg);')
    c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(78deg);','23%':'transform:rotate(85deg);','37%':'transform:rotate(73deg);','75%':'transform:rotate(82deg);'})
    c.rig_extra += '<g class="prop-warm-flame"><path d="M330 537 C305 511 336 502 333 482 C358 502 347 511 360 506 C374 529 354 542 330 537Z" fill="#E6C18A" opacity=".65"/></g><g class="prop-pancake"><ellipse cx="351" cy="467" rx="47" ry="9" fill="#EDC77E" stroke="#C6A06C" stroke-width="4"/><path d="M328 465q20-7 42 0" stroke="#FFF0CB" stroke-width="4" stroke-linecap="round"/></g><g class="prop-frying-pan"><path d="M270 481 Q282 522 350 522 Q419 522 433 481Z" fill="#AA8DBB" stroke="#8C6AA7" stroke-width="5"/><ellipse cx="351" cy="481" rx="82" ry="16" fill="#FFF1D7" stroke="#8C6AA7" stroke-width="5"/><path d="M431 478l41-40" stroke="#393A35" stroke-width="12" stroke-linecap="round"/></g>'
    c.style('.prop-pancake','transform-origin:351px 467px;')
    c.anim('.prop-pancake',3.2,{'0%':'transform:translateY(0) rotate(0);','23%':'transform:translateY(2px) rotate(0);','44%':'transform:translate(-8px,-157px) rotate(150deg);','54%':'transform:translate(-5px,-171px) rotate(220deg);','73%':'transform:translateY(0) rotate(360deg);','84%':'transform:translateY(-5px) rotate(360deg);','100%':'transform:translateY(0) rotate(360deg);'})
    c.style('.prop-frying-pan','transform-origin:472px 438px;')
    c.anim('.prop-frying-pan',3.2,{'0%,100%':'transform:rotate(0);','23%':'transform:rotate(-7deg);','37%':'transform:rotate(6deg);','73%':'transform:rotate(-4deg);','87%':'transform:rotate(0);'})
    c.style('.prop-warm-flame','transform-origin:342px 539px;')
    c.anim('.prop-warm-flame',1.6,{'0%,100%':'transform:scale(.9,1);','50%':'transform:scale(1.05,.85);'})
    c.anim('.rig-head',3.2,{'0%,100%':'transform:rotate(0);','48%':'transform:rotate(-4deg);','78%':'transform:rotate(2deg);'})

    # 73. Crossed legs are new paths; the original shoes remain the original shoe artwork.
    c = reg('lotus-float','Achieving absolutely nothing, serenely','Thinking',4.8,
        'Folds its purple-shoed legs into a little levitating meditation pose, with closed lids and one slow breathing ripple',
        'Meditating|Centering|Attuning','Levitating|Musing|Mulling|Contemplating|Channeling',
        '14-clip reference: crossed-leg zen levitation',
        'Quiet lilac ripple instead of glow; no guru outfit, no new face, original shoes and wrinkles', 'low')
    c.detached_shoes = {'left','right'}
    for leg in ['.rig-left-leg','.rig-right-leg']:c.style(leg,'visibility:hidden;')
    c.style('.rig-glasses','transform:translateY(-103px) rotate(-2deg) scale(.88);')
    c.head_extra += lids()
    c.style('.rig-shoe-left','transform:translate(152px,-44px) rotate(-16deg) scale(.85);')
    c.style('.rig-shoe-right','transform:translate(-115px,-36px) rotate(16deg) scale(.85);')
    c.rig_back += '<g class="prop-lotus-legs" stroke="#393A35" stroke-width="23" stroke-linecap="round"><path d="M259 481 Q218 552 410 548"/><path d="M418 480 Q470 550 308 558"/></g>'
    c.anim('.rig-root',4.8,{'0%,100%':'transform:translateY(-35px) scale(.9);','50%':'transform:translateY(-52px) scale(.91,.9);'})
    c.style('.rig-left-arm','transform:rotate(-35deg);')
    c.style('.rig-right-arm','transform:rotate(35deg);')
    c.back += '<g class="fx-zen-ripple"><ellipse cx="356" cy="630" rx="206" ry="31" stroke="#C3AFD1" stroke-width="3"/><ellipse cx="356" cy="630" rx="151" ry="20" stroke="#DFD1E8" stroke-width="3"/></g>'
    c.style('.fx-zen-ripple','transform-origin:356px 630px;')
    c.anim('.fx-zen-ripple',4.8,{'0%,100%':'transform:scale(.9);opacity:.28;','50%':'transform:scale(1.04);opacity:.65;'})
    c.style('.rig-ground','opacity:.035;')

    # 74. Announcing nothing at a perfectly reasonable volume, visually.
    c = reg('megaphone','An announcement about the announcement','Mischief',3.2,
        'Holds a little lilac megaphone and solemnly announces absolutely nothing, with three quiet drawn sound waves',
        'Announcing|Amplifying|Broadcasting','Bloviating|Honking|Pontificating|Gesticulating|Calling',
        '79-loop reference: megaphone',
        'Soft sound arcs, a short speaking rhythm, and an oversized opinion without an outfit or flashing text', 'medium')
    c.open_mouth = True
    c.style('.rig-right-arm','transform:rotate(105deg);')
    c.anim('.rig-left-arm',3.2,{'0%,100%':'transform:rotate(-10deg);','40%':'transform:rotate(-52deg);','70%':'transform:rotate(-24deg);'})
    c.rig_extra += '<g class="prop-horn"><path d="M428 335L560 284V390L428 361Z" fill="#D5C1E2" stroke="#8C6AA7" stroke-width="5" stroke-linejoin="round"/><ellipse cx="560" cy="337" rx="13" ry="53" fill="#F1E6F6" stroke="#8C6AA7" stroke-width="5"/><path d="M466 367l5 32h19l-6-28" fill="#B397C4" stroke="#8C6AA7" stroke-width="4"/><path d="M418 347h16" stroke="#393A35" stroke-width="10" stroke-linecap="round"/></g>'
    c.anim('.rig-mouth',.8,{'0%,100%':'transform:scale(.7,.2);','35%':'transform:scale(.8,.9);','65%':'transform:scale(1,.4);'})
    c.anim('.rig-head',3.2,{'0%,100%':'transform:rotate(-1deg);','50%':'transform:rotate(2deg);'})
    for i,(x,dy) in enumerate([(589,34),(619,53),(651,70)]):
        c.front += f'<path class="fx-horn-wave-{i}" d="M{x} {337-dy}q{dy*.75:g} {dy} 0 {dy*2}" stroke="#B9A0CA" stroke-width="5" stroke-linecap="round"/>'
        c.anim(f'.fx-horn-wave-{i}',1.6,{'0%,100%':'opacity:0;','35%':'opacity:.65;','80%':'opacity:0;'},delay=-i*.25)

    # 75. The longer arms cross in a genuine hug; the original silhouette stays intact.
    c = reg('self-hug','A little self-appreciation','Mischief',3.6,
        'Wraps two long rubbery arms around its own brain cheeks, squeezes gently, and releases one small pink heart',
        'Hugging|Appreciating|Heartwarming','Canoodling|Beaming|Vibing|Symbioting',
        '79-loop reference: floating hearts',
        'An actual self-hug rather than a heart particle pasted over a generic bob', 'low', split=True)
    c.left_arm_markup = '<path d="M151 358 Q152 489 409 448" stroke="#393A35" stroke-width="21" stroke-linecap="round"/>'+mitt(422,438)
    c.right_arm_markup = '<path d="M580 358 Q571 489 328 448" stroke="#393A35" stroke-width="20" stroke-linecap="round"/>'+mitt(315,438)
    c.anim('.lobe-left',3.6,{'0%,100%':'transform:translateX(0);','45%,65%':'transform:translateX(5px) scale(.99);'})
    c.anim('.lobe-right',3.6,{'0%,100%':'transform:translateX(0);','45%,65%':'transform:translateX(-5px) scale(.99);'})
    c.anim('.rig-left-arm',3.6,{'0%,100%':'transform:translateX(-9px);','45%,65%':'transform:translateX(6px);'})
    c.anim('.rig-right-arm',3.6,{'0%,100%':'transform:translateX(9px);','45%,65%':'transform:translateX(-6px);'})
    c.anim('.rig-head',3.6,{'0%,100%':'transform:rotate(-2deg);','50%':'transform:rotate(2deg) translateY(3px);'})
    c.front += '<g class="fx-one-heart"><path d="M588 153 C557 132 564 105 584 112 C598 91 624 110 611 132Z" fill="#E4ABB9"/></g>'
    c.style('.fx-one-heart','transform-origin:589px 133px;')
    c.anim('.fx-one-heart',3.6,{'0%,30%,100%':'transform:translateY(12px) scale(.5);opacity:0;','55%':'transform:translateY(0) scale(1);opacity:.85;','85%':'transform:translateY(-28px) scale(1.1);opacity:0;'})

    # 76. The light cone and flashlight rotate as one object about the gripping hand.
    c = reg('flashlight-search','Looking for the missing thought','Thinking',3.6,
        'Sweeps a tiny flashlight across an empty corner while its uncovered eyes follow the soft beam, finding mostly dust',
        'Searching|Scanning|Illuminating','Spelunking|Perusing|Inferring|Elucidating|Deciphering',
        '79-loop reference: spelunking lamp',
        'A hand-anchored moving lamp and transparent cream cone; no helmet, dark background or neon glow', 'low', eyes=True)
    c.style('.rig-glasses','transform:translateY(-104px) rotate(-3deg) scale(.88);')
    c.style('.rig-right-arm','transform:rotate(95deg);')
    c.style('.rig-left-arm','transform:rotate(-159deg);')
    c.rig_extra += '<g class="prop-search-lamp"><path d="M516 368L688 253V467L523 394Z" fill="#E6D5AA" fill-opacity=".16"/><path d="M448 397L500 368L514 392L461 420Z" fill="#C4AFD2" stroke="#8C6AA7" stroke-width="5" stroke-linejoin="round"/><path d="M498 368l15 27 12-7-15-27Z" fill="#FFF9F1" stroke="#8C6AA7" stroke-width="4"/><g fill="#D5C4E0"><circle cx="595" cy="350" r="4"/><circle cx="649" cy="318" r="3"/><circle cx="629" cy="418" r="4"/></g></g>'
    c.style('.prop-search-lamp','transform-origin:454px 405px;')
    c.anim('.prop-search-lamp',3.6,{'0%,100%':'transform:rotate(-11deg);','50%':'transform:rotate(11deg);'})
    for sel in ['.pupil-left','.pupil-right']:
        c.anim(sel,3.6,{'0%,100%':'transform:translate(9px,7px);','50%':'transform:translate(9px,19px);'})
    c.anim('.rig-head',3.6,{'0%,100%':'transform:rotate(-1deg);','50%':'transform:rotate(2deg);'})

    graph = next(x for x in new if x.slug == 'branch-merge')
    for sel in ['.prop-branch-a','.prop-branch-b']:
        graph.style(sel,'stroke-dashoffset:0;opacity:.7;')
    for sel in ['.prop-branch-node-a','.prop-branch-node-b']:
        graph.style(sel,'opacity:1;')
    graph.style('.prop-merged-node','transform:scale(1);opacity:1;')
    cold = next(x for x in new if x.slug == 'snow-shiver')
    for i in range(4):cold.style(f'.fx-snow-{i}','opacity:.5;')

    assert len(new) == 16
    assert sum(c.loop for c in new) == 15
    assert sum(len(c.added_words) for c in new) == 45
    return new
