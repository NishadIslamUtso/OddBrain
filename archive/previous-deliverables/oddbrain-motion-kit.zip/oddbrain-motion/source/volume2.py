"""Volume 02 — 24 additional physical-comedy loops. No third-party modules.
Registered by build.py; all original V1 clip definitions and artwork stay untouched.
"""

def register(add, star, dot):
    INK, PURPLE, PINK, CREAM, YELLOW = '#393A35', '#8C6AA7', '#FF98A5', '#FFF9F1', '#EDC77E'
    new = []

    def reg(slug, name, category, seconds, description, words, suggested, energy='medium', **kw):
        c = add(slug, name, category, seconds, description, words.split('|')[0], energy, **kw)
        c.volume = 2
        c.added_words = words.split('|')
        c.suggested_words = suggested.split('|') if suggested else []
        new.append(c)
        return c

    def puff(c, x, y, cls, delay=0, duration=1.2):
        c.front += f'<g class="{cls}" stroke="#BDA8CC" stroke-width="5" stroke-linecap="round"><path d="M{x} {y}l-18-4m23-10-8-15m22 13 7-14"/></g>'
        c.anim('.'+cls,duration,{'0%,100%':'opacity:0;transform:translateY(0);','30%':'opacity:.8;','75%':'opacity:0;transform:translateY(-13px);'},delay=delay)

    # 37. One shoe is a deck; the other foot really pushes. Socks remain attached.
    c = reg('shoe-skateboard','Questionable transport','Travel',2.4,
        'Rides one oversized purple shoe like a skateboard, pushing with the other foot and wobbling its arms for balance',
        'Skateboarding|Coasting|Rolling','Moonwalking|Schlepping|Skedaddling|Gallivanting', 'high')
    c.detached_shoes = {'left'}
    c.anim('.rig-root',2.4,{'0%,100%':'transform:translateX(-16px) rotate(-3deg) scale(.94);','50%':'transform:translateX(16px) rotate(3deg) scale(.94);'})
    c.anim('.rig-left-leg',2.4,{'0%,100%':'transform:translateX(92px) scaleY(1.3);','50%':'transform:translateX(95px) scaleY(1.3) rotate(-3deg);'})
    c.anim('.rig-right-leg',1.2,{'0%,100%':'transform:translate(8px,19px) rotate(-12deg);','35%':'transform:translate(-20px,13px) rotate(30deg);','70%':'transform:translate(8px,-15px) rotate(-15deg);'})
    c.anim('.rig-shoe-left',2.4,{'0%,100%':'transform:translate(95px,35px) scale(1.8,.65) rotate(-2deg);','50%':'transform:translate(95px,35px) scale(1.8,.65) rotate(2deg);'})
    c.anim('.rig-left-arm',1.2,{'0%,100%':'transform:rotate(40deg);','50%':'transform:rotate(15deg);'})
    c.anim('.rig-right-arm',1.2,{'0%,100%':'transform:rotate(-15deg);','50%':'transform:rotate(-40deg);'})
    c.rig_extra += '<g class="prop-wheels"><path d="M301 671h114" stroke="#393A35" stroke-width="6"/><circle cx="306" cy="680" r="13" fill="#393A35"/><circle cx="409" cy="680" r="13" fill="#393A35"/><circle cx="306" cy="680" r="4" fill="#C6B0D5"/><circle cx="409" cy="680" r="4" fill="#C6B0D5"/></g>'
    c.style('.rig-ground','transform:translateY(36px);')
    c.back += '<g class="fx-road" stroke="#CAB9D5" stroke-width="5" stroke-linecap="round"><path d="M83 696h78m14-15h34m294 15h92"/></g>'
    c.anim('.fx-road',.6,{'0%':'transform:translateX(18px);opacity:0;','30%':'opacity:.6;','100%':'transform:translateX(-30px);opacity:0;'},'linear')

    # 38. The head itself flips, not the whole mascot. Legs wait underneath.
    c = reg('brain-kickflip','Hold my frontal lobe','Mischief',3.2,
        'Tosses its entire brain-head into a compact kickflip, then catches it above two very patient legs',
        'Kickflipping|Headspinning|Brainstorming','Catapulting|Topsy-turvying|Boondoggling|Improvising', 'high')
    c.style('.rig-head','transform-origin:356px 320px;')
    c.anim('.rig-head',3.2,{'0%,100%':'transform:translateY(0) rotate(0) scale(1);','15%':'transform:translateY(12px) rotate(-6deg) scale(1.02,.96);','35%':'transform:translateY(-68px) rotate(90deg) scale(.78);','50%':'transform:translateY(-85px) rotate(180deg) scale(.76);','65%':'transform:translateY(-68px) rotate(270deg) scale(.78);','82%':'transform:translateY(9px) rotate(360deg) scale(1.03,.96);','94%':'transform:translateY(-3px) rotate(360deg) scale(.99,1.01);','100%':'transform:translateY(0) rotate(360deg) scale(1);'})
    c.anim('.rig-left-arm',3.2,{'0%,100%':'transform:rotate(-26deg);','28%,74%':'transform:rotate(-126deg);','85%':'transform:rotate(-82deg);'})
    c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(26deg);','28%,74%':'transform:rotate(126deg);','85%':'transform:rotate(82deg);'})
    c.front += star(78,176,17,YELLOW,'fx-catch-a')+star(657,170,17,PURPLE,'fx-catch-b')
    for s in ['.fx-catch-a','.fx-catch-b']:
        c.anim(s,3.2,{'0%,72%,96%,100%':'opacity:0;','83%':'opacity:.9;'})

    # 39. Anticipation, sneeze, flying shades, embarrassed recovery.
    c = reg('sneeze','Achoo, there go the glasses','Mischief',3.6,
        'Inflates for a sneeze, snaps forward, sends its sunglasses flying, and quietly recovers them',
        'Sneezing|Achooing|Sniffling','Blanching|Discombobulating|Thundering|Hullaballooing', 'high', eyes=True)
    c.open_mouth = True
    c.anim('.rig-head',3.6,{'0%,100%':'transform:rotate(0) scale(1);','27%':'transform:translateY(-8px) rotate(-5deg) scale(1.025,1.04);','38%':'transform:translateY(17px) rotate(7deg) scale(1.035,.92);','49%':'transform:translateY(-3px) rotate(-2deg) scale(.99,1.01);','67%':'transform:rotate(0) scale(1);'})
    c.anim('.rig-glasses',3.6,{'0%,29%,100%':'transform:translate(0,0) rotate(0);','40%':'transform:translate(118px,-89px) rotate(28deg) scale(.86);','51%':'transform:translate(98px,-122px) rotate(50deg) scale(.82);','68%':'transform:translate(12px,10px) rotate(-6deg);','80%':'transform:translate(0,0) rotate(0);'})
    c.style('.rig-eyes','transform-box:view-box;transform-origin:382px 274px;')
    c.anim('.rig-eyes',3.6,{'0%,100%':'transform:scaleY(1);','25%,49%':'transform:scaleY(.12);','60%':'transform:scaleY(1);'})
    c.anim('.rig-mouth',3.6,{'0%,100%':'transform:scaleY(.15);','27%':'transform:scale(.7,1.2);','38%':'transform:scale(1.4,1);','60%':'transform:scaleY(.15);'})
    c.anim('.rig-left-arm',3.6,{'0%,100%':'transform:rotate(0);','29%,51%':'transform:rotate(-122deg);','69%':'transform:rotate(-30deg);'})
    c.anim('.rig-right-arm',3.6,{'0%,100%':'transform:rotate(0);','43%,68%':'transform:rotate(150deg);'})
    c.front += '<g class="fx-sneeze" stroke="#BDA8CC" stroke-width="7" stroke-linecap="round"><path d="M426 339l62 4m-57-23 52-16m-56 53 57 21"/></g>'
    c.anim('.fx-sneeze',3.6,{'0%,32%,58%,100%':'opacity:0;','37%':'opacity:.9;transform:translateX(0);','52%':'opacity:0;transform:translateX(45px);'})

    # 40. There is deliberately no outfit and therefore no pockets to find.
    c = reg('pocket-panic','Wait. I do not have pockets.','Mischief',2.8,
        'Pats both cheeks looking for pockets, checks its own head, and realizes it is not wearing an outfit',
        'Pocket-patting|Panicking|Double-checking','Befuddling|Flummoxing|Puzzling|Whatchamacalliting', 'high', eyes=True)
    c.anim('.rig-root',2.8,{'0%,100%':'transform:rotate(-1deg);','22%':'transform:rotate(2deg);','44%':'transform:rotate(-2deg);','65%':'transform:translateY(-7px) rotate(0);'})
    c.anim('.rig-left-arm',2.8,{'0%,100%':'transform:rotate(-35deg);','15%,29%':'transform:rotate(-82deg);','22%,36%':'transform:rotate(-68deg);','52%,66%':'transform:rotate(-168deg);','80%':'transform:rotate(-45deg);'})
    c.anim('.rig-right-arm',2.8,{'0%,100%':'transform:rotate(35deg);','15%,29%':'transform:rotate(68deg);','22%,36%':'transform:rotate(82deg);','52%,66%':'transform:rotate(168deg);','80%':'transform:rotate(45deg);'})
    c.anim('.rig-glasses',2.8,{'0%,39%,100%':'transform:translateY(0);','51%,73%':'transform:translateY(-103px) rotate(4deg) scale(.9);','87%':'transform:translateY(0);'})
    for cl in ['.pupil-left','.pupil-right']:
        c.anim(cl,2.8,{'0%,100%':'transform:translate(0,10px);','50%':'transform:translate(-10px,10px);','60%':'transform:translate(10px,10px);','70%':'transform:translate(-10px,10px);','80%':'transform:translate(10px,10px);'})
    c.front += '<g class="fx-panic" stroke="#B394C1" stroke-width="6" stroke-linecap="round"><path d="M111 99l-10-23m28 18 1-23m-42 47-21-6"/></g>'
    c.anim('.fx-panic',2.8,{'0%,42%,90%,100%':'opacity:0;','54%,76%':'opacity:.9;'})

    # 41. A literal shoe phone, with the sock left on the far leg.
    c = reg('shoe-phone','The sole support line','Mischief',3.2,
        'Holds its own purple shoe to its ear, nodding with the confidence of a very unhelpful telephone operator',
        'Dialing|Calling|Consulting','Channeling|Channelling|Bloviating|Pontificating|Honking', 'medium')
    c.detached_shoes = {'right'}
    c.open_mouth = True
    c.anim('.rig-shoe-right',3.2,{'0%,100%':'transform:translate(130px,-355px) rotate(-48deg) scale(.85);','50%':'transform:translate(122px,-362px) rotate(-53deg) scale(.85);'})
    c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(178deg);','50%':'transform:rotate(185deg);'})
    c.anim('.rig-head',3.2,{'0%,100%':'transform:rotate(1deg);','30%':'transform:rotate(-3deg);','65%':'transform:rotate(3deg);'})
    c.anim('.rig-left-arm',1.6,{'0%,100%':'transform:rotate(-18deg);','50%':'transform:rotate(-58deg);'})
    c.anim('.rig-mouth',.8,{'0%,100%':'transform:scaleY(.15);','40%':'transform:scale(.8,.8);','65%':'transform:scaleY(.35);'})
    c.back += '<g class="fx-signal" stroke="#B39BC2" stroke-width="6" stroke-linecap="round"><path d="M635 211q25 18 4 42m10-59q44 30 8 72"/></g>'
    c.anim('.fx-signal',1.6,{'0%,100%':'opacity:.1;','45%':'opacity:.8;'})

    # 42. The brain cheeks are the bongos. Each impact compresses its own lobe.
    c = reg('cheek-drums','Built-in bongos','Dancing',1.2,
        'Plays a syncopated drum solo on its own brain cheeks, each cheek squishing under the alternating palms',
        'Drumming|Beatboxing|Percussing',"Beboppin'|Boogieing|Harmonizing|Grooving|Orchestrating", 'high', split=True)
    c.anim('.rig-left-arm',.6,{'0%,100%':'transform:rotate(-57deg);','34%':'transform:rotate(-84deg);','49%':'transform:rotate(-68deg);'})
    c.anim('.rig-right-arm',.6,{'0%,100%':'transform:rotate(84deg);','34%':'transform:rotate(57deg);','49%':'transform:rotate(75deg);'},delay=-.3)
    c.anim('.lobe-left',.6,{'0%,100%':'transform:scale(1);','34%':'transform:scale(1.035,.965);'})
    c.anim('.lobe-right',.6,{'0%,100%':'transform:scale(1);','84%':'transform:scale(1.035,.965);'})
    c.anim('.rig-shoe-left',.6,{'0%,100%':'transform:rotate(0);','34%':'transform:rotate(-12deg);'})
    c.anim('.rig-shoe-right',.6,{'0%,100%':'transform:rotate(-12deg);','34%':'transform:rotate(0);'})
    puff(c,255,401,'fx-drum-left',0,.6)
    puff(c,481,401,'fx-drum-right',-.3,.6)
    c.music()

    # 43. The glasses come off; the cloth and eye tracking have separate rhythms.
    c = reg('glasses-clean','Polishing the perspective','Thinking',3.2,
        'Takes off its sunglasses, polishes a lens with a little cloth, and follows the wipe with its uncovered eyes',
        'Polishing|Clarifying|Refocusing','Elucidating|Deciphering|Perusing|Considering|Proofing', 'low', eyes=True)
    c.anim('.rig-glasses',3.2,{'0%,100%':'transform:translate(-14px,173px) rotate(-3deg) scale(.61);','50%':'transform:translate(-14px,169px) rotate(3deg) scale(.61);'})
    c.style('.rig-left-arm','transform:rotate(-79deg);')
    c.anim('.rig-right-arm',.8,{'0%,100%':'transform:rotate(78deg);','50%':'transform:rotate(92deg);'})
    c.rig_extra += '<g class="prop-cloth"><path d="M412 413 Q437 422 458 414 L465 453 Q442 445 419 461Z" fill="#FFF9F1" stroke="#C7B6D3" stroke-width="4"/><path d="M420 425l29 18m-28-7 20 12" stroke="#E0D4E8" stroke-width="3" stroke-linecap="round"/></g>'
    c.anim('.prop-cloth',.8,{'0%,100%':'transform:translate(-13px,0) rotate(-4deg);','50%':'transform:translate(12px,-5px) rotate(4deg);'})
    c.style('.prop-cloth','transform-origin:440px 440px;')
    for cl in ['.pupil-left','.pupil-right']:
        c.anim(cl,.8,{'0%,100%':'transform:translate(-6px,22px);','50%':'transform:translate(6px,20px);'})
    c.rig_extra += star(296,426,13,YELLOW,'fx-polish')
    c.anim('.fx-polish',3.2,{'0%,60%,100%':'opacity:0;','78%':'opacity:1;','90%':'opacity:0;'})

    # 44. The visible noodle is consumed from bowl to mouth, rather than a floating food icon.
    c = reg('noodle-slurp','One very long thought','Cooking',3.2,
        'Slurps one impossibly long noodle from a little bowl while trying to maintain its distinguished expression',
        'Slurping|Snacking|Recharging','Noodling|Cooking|Canoodling|Marinating', 'medium')
    c.mouth_markup = '<circle cx="379" cy="342" r="13" fill="#393A35"/>'
    c.style('.rig-left-arm','transform:rotate(-76deg);')
    c.anim('.rig-right-arm',3.2,{'0%,100%':'transform:rotate(86deg);','65%':'transform:rotate(103deg);'})
    c.anim('.rig-head',3.2,{'0%,100%':'transform:translateY(0);','65%':'transform:translateY(8px) rotate(2deg);'})
    c.rig_extra += '<g class="prop-noodle-bowl"><path d="M264 454 H466 Q454 526 365 526 Q279 526 264 454Z" fill="#D9C7E5" stroke="#8C6AA7" stroke-width="6"/><ellipse cx="365" cy="454" rx="101" ry="18" fill="#FFF1D7" stroke="#8C6AA7" stroke-width="5"/><path d="M299 453q25-22 44 1t49 0 42-1" stroke="#D2AC6E" stroke-width="5" stroke-linecap="round"/></g><path class="prop-noodle" d="M378 448 C350 427 402 411 376 392 S399 365 379 343" stroke="#D8B573" stroke-width="6" stroke-linecap="round" pathLength="100" stroke-dasharray="100"/><g class="prop-chopsticks" stroke="#AD8B68" stroke-width="6" stroke-linecap="round"><path d="M390 438l71-67m-65 72 72-61"/></g>'
    c.anim('.prop-noodle',3.2,{'0%,100%':'stroke-dashoffset:0;opacity:1;','75%':'stroke-dashoffset:95;opacity:1;','85%,95%':'stroke-dashoffset:100;opacity:0;','99%':'stroke-dashoffset:0;opacity:0;'},'linear')
    c.anim('.prop-chopsticks',3.2,{'0%,100%':'transform:translateY(0);','65%':'transform:translate(-5px,-17px);'})
    c.anim('.rig-mouth',.8,{'0%,100%':'transform:scale(.7,1);','50%':'transform:scale(1,.7);'})

    # 45. Breath, a nose bubble and vector Zs. No typeface dependency.
    c = reg('nap','Saving brain power','Thinking',4.8,
        'Nods off behind its sunglasses, breathing slowly while a tiny sleep bubble and hand-drawn Zs drift upward',
        'Snoozing|Napping|Dreaming','Lollygagging|Musing|Incubating|Dilly-dallying|Moseying', 'low')
    c.anim('.rig-root',4.8,{'0%,100%':'transform:translateY(10px) rotate(-5deg) scale(1.02,.97);','50%':'transform:translateY(6px) rotate(-6deg) scale(1.035,.98);'})
    c.style('.rig-left-arm','transform:rotate(13deg);')
    c.style('.rig-right-arm','transform:rotate(-8deg);')
    c.anim('.rig-head',4.8,{'0%,100%':'transform:rotate(-2deg);','50%':'transform:rotate(-5deg) translateY(4px);'})
    c.head_extra += '<g class="prop-sleep-bubble"><circle cx="407" cy="336" r="10" fill="#F7EFF9" fill-opacity=".6" stroke="#BDA5CC" stroke-width="3"/><path d="M403 331q4-4 8 0" stroke="#FFF9F1" stroke-width="3" stroke-linecap="round"/></g>'
    c.style('.prop-sleep-bubble','transform-origin:407px 336px;')
    c.anim('.prop-sleep-bubble',4.8,{'0%,100%':'transform:scale(.35);opacity:.3;','55%':'transform:scale(2.3);opacity:.7;','75%':'transform:translate(15px,-13px) scale(2.5);opacity:0;','85%':'transform:scale(.35);opacity:0;'})
    c.back += '<g class="fx-zzz" stroke="#A58AB6" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"><path d="M568 163h24l-24 26h24m18-62h28l-28 29h28m14-69h34l-34 35h34"/></g>'
    c.anim('.fx-zzz',4.8,{'0%,100%':'transform:translateY(10px);opacity:.15;','65%':'transform:translateY(-12px);opacity:.85;'})

    # 46. Long squash-and-stretch yawn, with rubber-hose arms extended above the forehead.
    c = reg('stretch','Booting the last brain cell','Mischief',4.2,
        'Lets out a huge yawn, stretches both rubbery arms above its head, then slowly deflates back to smug',
        'Yawning|Stretching|Waking','Leavening|Mustering|Unfurling|Actualizing', 'medium')
    c.open_mouth = True
    c.anim('.rig-root',4.2,{'0%,100%':'transform:scale(1);','43%,64%':'transform:scale(.97,1.045);','80%':'transform:scale(1.02,.97);'})
    c.anim('.rig-left-arm',4.2,{'0%,100%':'transform:rotate(-8deg) scale(1);','43%,64%':'transform:rotate(-185deg) scale(1.75);','80%':'transform:rotate(-25deg) scale(1.1);'})
    c.anim('.rig-right-arm',4.2,{'0%,100%':'transform:rotate(8deg) scale(1);','43%,64%':'transform:rotate(185deg) scale(1.75);','80%':'transform:rotate(25deg) scale(1.1);'})
    c.anim('.rig-mouth',4.2,{'0%,100%':'transform:scale(1,.15);','43%,64%':'transform:scale(1.4,1.8);','80%':'transform:scale(1,.2);'})
    c.anim('.rig-glasses',4.2,{'0%,100%':'transform:translateY(0);','43%,64%':'transform:translateY(-7px) rotate(2deg);'})

    # 47. Deliberately low crouch, short toe-first footwork and a hand raised near the face.
    c = reg('sneak','Definitely not up to anything','Travel',2.4,
        'Crouches into tiny toe-first steps, one hand raised in a conspiratorial almost-shush',
        'Sneaking|Tiptoeing|Slinking','Perambulating|Scurrying|Burrowing|Spelunking', 'medium')
    c.anim('.rig-root',2.4,{'0%,100%':'transform:translate(-11px,24px) rotate(-5deg) scale(.96,.92);','50%':'transform:translate(11px,21px) rotate(-3deg) scale(.96,.93);'})
    c.style('.rig-left-arm','transform:rotate(-118deg);')
    c.anim('.rig-right-arm',2.4,{'0%,100%':'transform:rotate(-27deg);','50%':'transform:rotate(-39deg);'})
    c.anim('.rig-left-leg',2.4,{'0%,100%':'transform:translateX(-15px) rotate(12deg);','50%':'transform:translate(16px,-12px) rotate(-12deg);'})
    c.anim('.rig-right-leg',2.4,{'0%,100%':'transform:translate(16px,-12px) rotate(-12deg);','50%':'transform:translateX(-15px) rotate(12deg);'})
    c.anim('.rig-shoe-left',2.4,{'0%,100%':'transform:rotate(-20deg);','50%':'transform:rotate(-3deg);'})
    c.anim('.rig-shoe-right',2.4,{'0%,100%':'transform:rotate(-3deg);','50%':'transform:rotate(-20deg);'})
    c.back += '<g class="fx-footprints" fill="#C4AFD2"><ellipse cx="165" cy="674" rx="11" ry="5"/><ellipse cx="124" cy="661" rx="10" ry="5"/><ellipse cx="82" cy="674" rx="9" ry="4"/></g>'
    c.anim('.fx-footprints',2.4,{'0%,100%':'opacity:.1;','50%':'opacity:.6;'})

    # 48. Fixed SVG clipping, not an opaque rectangle pretending to be a transparent wall.
    c = reg('peekaboo','Just checking if you are still there','Mischief',4,
        'Peeks around a thin door edge, retreats, then makes an unnecessarily dramatic full-body appearance',
        'Peeking|Peekabooing|Checking','Perusing|Considering|Pouncing|Doing', 'medium')
    c.extra_defs = '<clipPath id="peek-window"><rect x="0" y="0" width="650" height="740"/></clipPath>'
    c.rig_clip = 'peek-window'
    c.back += '<path d="M659 76V667m-17-591h31m-31 591h31" stroke="#CCB9D8" stroke-width="6" stroke-linecap="round"/>'
    c.anim('.rig-root',4,{'0%,100%':'transform:translateX(670px) rotate(0) scale(.86);','26%,39%':'transform:translateX(275px) rotate(-9deg) scale(.86);','47%':'transform:translateX(400px) rotate(0) scale(.86);','65%,78%':'transform:translateX(0) rotate(-2deg) scale(.9);','89%':'transform:translateX(275px) rotate(-9deg) scale(.86);'})
    c.style('.rig-root','transform:translateX(190px) rotate(-6deg) scale(.86);')
    c.anim('.rig-left-arm',4,{'0%,100%':'transform:rotate(0);','58%,78%':'transform:rotate(-147deg);'})
    c.anim('.rig-glasses',4,{'0%,100%':'transform:rotate(0);','30%':'transform:rotate(-5deg);','72%':'transform:rotate(4deg);'})
    c.style('.rig-ground','opacity:0;')

    # 49. The head floats away on a tether held by the remaining little body.
    c = reg('balloon-brain','A head full of helium','Magic',4,
        'Its brain-head becomes a helium balloon, gently tugging upward on a string held in its own little hand',
        'Inflating|Buoying|Ballooning','Billowing|Levitating|Bunning|Beaming', 'low')
    c.rig_back += '<path class="prop-string" d="M356 280 C378 364 332 451 271 428" stroke="#B39BC1" stroke-width="4" stroke-linecap="round"/>'
    c.anim('.rig-head',4,{'0%,100%':'transform:translate(-12px,-30px) rotate(-3deg) scale(.94,1);','50%':'transform:translate(12px,-74px) rotate(3deg) scale(.9,1.01);'})
    c.style('.rig-left-arm','transform:rotate(-78deg);')
    c.anim('.rig-right-arm',4,{'0%,100%':'transform:rotate(-5deg);','50%':'transform:rotate(-20deg);'})
    c.anim('.rig-left-leg',4,{'0%,100%':'transform:rotate(-5deg);','50%':'transform:rotate(5deg);'})
    c.anim('.prop-string',4,{'0%,100%':'transform:skewX(-3deg);','50%':'transform:skewX(3deg);'})
    c.style('.prop-string','transform-origin:271px 428px;')

    # 50. Back and front halves of the hoop give actual occlusion around the brain.
    c = reg('hula-hoop','Doctorate in hoopla','Dancing',1.6,
        'Hula-hoops around the two brain cheeks, with the hoop passing behind and in front of the body',
        'Hula-hooping|Waist-wiggling|Hoopla-ing','Shimmying|Vibing|Twisting|Undulating', 'high', split=True)
    c.rig_back += '<path class="prop-hoop-back" d="M62 454 C62 372 663 372 663 454" stroke="#AA8BBB" stroke-width="11" stroke-linecap="round"/>'
    c.rig_extra += '<path class="prop-hoop-front" d="M663 454 C663 536 62 536 62 454" stroke="#AA8BBB" stroke-width="11" stroke-linecap="round"/><path class="prop-hoop-stripe" d="M638 486 C558 528 219 528 101 485" stroke="#D7C4E3" stroke-width="4" stroke-linecap="round"/>'
    c.anim('.lobe-left',.8,{'0%,100%':'transform:translate(-7px,2px) skewX(-3deg);','50%':'transform:translate(7px,-2px) skewX(3deg);'})
    c.anim('.lobe-right',.8,{'0%,100%':'transform:translate(-7px,-2px) skewX(-3deg);','50%':'transform:translate(7px,2px) skewX(3deg);'})
    for s in ['.prop-hoop-back','.prop-hoop-front','.prop-hoop-stripe']:
        c.style(s,'transform-origin:362px 454px;')
        c.anim(s,.8,{'0%,100%':'transform:translateX(10px) rotate(-6deg) scaleY(.72);','50%':'transform:translateX(-10px) rotate(6deg) scaleY(1);'})
    c.anim('.rig-left-arm',.8,{'0%,100%':'transform:rotate(-135deg);','50%':'transform:rotate(-155deg);'})
    c.anim('.rig-right-arm',.8,{'0%,100%':'transform:rotate(155deg);','50%':'transform:rotate(135deg);'})
    c.anim('.rig-left-leg',1.6,{'0%,100%':'transform:rotate(-5deg);','50%':'transform:rotate(7deg);'})
    c.anim('.rig-right-leg',1.6,{'0%,100%':'transform:rotate(7deg);','50%':'transform:rotate(-5deg);'})
    c.music()

    # 51. A distinct heel/toe rhythmic pattern, not another moonwalk.
    c = reg('tap-dance','The clack department','Dancing',1.6,
        'Alternates heel-toe taps with a double heel-click, keeping its upper body almost absurdly formal',
        'Tap-dancing|Heel-clicking|Clacking','Sock-hopping|Jitterbugging|Boogieing|Choreographing', 'high')
    c.bounce(4,.8)
    c.anim('.rig-left-leg',1.6,{'0%,100%':'transform:rotate(-8deg);','20%':'transform:translateY(-12px) rotate(6deg);','40%':'transform:rotate(-4deg);','60%':'transform:rotate(10deg);','80%':'transform:rotate(1deg);'})
    c.anim('.rig-right-leg',1.6,{'0%,100%':'transform:rotate(8deg);','20%':'transform:rotate(-6deg);','40%':'transform:translateY(-12px) rotate(4deg);','60%':'transform:rotate(-10deg);','80%':'transform:rotate(-1deg);'})
    c.anim('.rig-shoe-left',.8,{'0%,100%':'transform:rotate(0);','22%':'transform:rotate(-22deg);','44%':'transform:rotate(9deg);','66%':'transform:rotate(-14deg);','82%':'transform:rotate(5deg);'})
    c.anim('.rig-shoe-right',.8,{'0%,100%':'transform:rotate(9deg);','22%':'transform:rotate(0);','44%':'transform:rotate(-22deg);','66%':'transform:rotate(6deg);','82%':'transform:rotate(-14deg);'})
    c.style('.rig-left-arm','transform:rotate(24deg);')
    c.style('.rig-right-arm','transform:rotate(-24deg);')
    puff(c,227,639,'fx-tap-left',0,.8)
    puff(c,464,639,'fx-tap-right',-.4,.8)
    c.music()

    # 52. Kicking legs are drawn in FRONT for this state, so the shoes don't vanish into the head.
    c = reg('cancan','No skirt. All can-can.','Dancing',1.6,
        'Throws high alternating can-can kicks with both arms in the air and no costume whatsoever',
        'High-kicking|Cancanning|Legging-it','Frolicking|Galloping|Gallivanting|Boogieing', 'high')
    c.style('.rig-left-leg','visibility:hidden;')
    c.style('.rig-right-leg','visibility:hidden;')
    c.rig_extra += '<g class="prop-kick-left"><path d="M259 481 C267 514 260 548 250 574" stroke="#393A35" stroke-width="23" stroke-linecap="round"/><path d="M232 570h38v22h-43Z" fill="#F2EFF8"/><use href="#shoe-left-art"/></g><g class="prop-kick-right"><path d="M418 480 C432 513 424 550 414 574" stroke="#393A35" stroke-width="23" stroke-linecap="round"/><path d="M396 570h38v22h-43Z" fill="#F2EFF8"/><use href="#shoe-right-art"/></g>'
    c.style('.prop-kick-left','transform-origin:259px 486px;')
    c.style('.prop-kick-right','transform-origin:418px 486px;')
    c.anim('.prop-kick-left',1.6,{'0%,100%':'transform:rotate(-4deg);','25%':'transform:rotate(-105deg);','50%,75%':'transform:rotate(-4deg);'})
    c.anim('.prop-kick-right',1.6,{'0%,25%,50%,100%':'transform:rotate(4deg);','75%':'transform:rotate(105deg);'})
    c.anim('.rig-root',.8,{'0%,100%':'transform:translateY(0) rotate(-2deg);','50%':'transform:translateY(-17px) rotate(2deg);'})
    c.anim('.rig-left-arm',1.6,{'0%,100%':'transform:rotate(-153deg);','50%':'transform:rotate(-171deg);'})
    c.anim('.rig-right-arm',1.6,{'0%,100%':'transform:rotate(171deg);','50%':'transform:rotate(153deg);'})
    c.music()

    # 53. Continuous ribbon stroke with a separate wand and balancing foot.
    c = reg('ribbon','Absolutely not Olympic regulation','Dancing',2.8,
        'Draws big looping ribbon flourishes around its own head while balancing on one purple shoe',
        'Ribboning|Twirling|Flourishing','Fluttering|Unfurling|Razzle-dazzling|Prestidigitating', 'high')
    c.style('.rig-right-arm','transform:rotate(95deg);')
    c.anim('.rig-left-arm',2.8,{'0%,100%':'transform:rotate(38deg);','50%':'transform:rotate(58deg);'})
    c.anim('.rig-right-leg',2.8,{'0%,100%':'transform:rotate(-25deg);','50%':'transform:rotate(-39deg);'})
    c.anim('.rig-head',2.8,{'0%,100%':'transform:rotate(-3deg);','50%':'transform:rotate(3deg);'})
    c.rig_extra += '<g class="prop-wand"><path d="M468 422l35-78" stroke="#AD8DBF" stroke-width="9" stroke-linecap="round"/></g><g class="fx-ribbon"><path d="M503 344 C716 388 706 109 570 126 S399 46 253 75 S32 165 74 252 S203 339 143 401" stroke="#C0A2D0" stroke-width="10" stroke-linecap="round" pathLength="100" stroke-dasharray="59 41"/><path d="M503 344 C716 388 706 109 570 126 S399 46 253 75 S32 165 74 252 S203 339 143 401" stroke="#EDB4C0" stroke-width="4" stroke-linecap="round" pathLength="100" stroke-dasharray="20 80"/></g>'
    c.anim('.fx-ribbon',2.8,{'0%':'stroke-dashoffset:0;','100%':'stroke-dashoffset:-100;'},'linear')
    c.style('.prop-wand','transform-origin:468px 422px;')
    c.anim('.prop-wand',1.4,{'0%,100%':'transform:rotate(-9deg);','50%':'transform:rotate(9deg);'})

    # 54. The magnet attracts the actual detachable accessories, not duplicate props.
    c = reg('magnet','Magnetic personality disorder','Magic',3.6,
        'Holds a little horseshoe magnet that pulls its own shoes and sunglasses upward before gently letting them go',
        'Magnetizing|Attracting|Polarizing','Coalescing|Mustering|Wrangling|Combobulating', 'medium', eyes=True)
    c.detached_shoes = {'left','right'}
    c.style('.rig-left-arm','transform:rotate(-76deg);')
    c.style('.rig-right-arm','transform:rotate(76deg);')
    c.rig_extra += '<g class="prop-magnet"><path d="M319 426 V467 A47 47 0 0 0 413 467V426" stroke="#AC8DBF" stroke-width="25" stroke-linejoin="round"/><path d="M319 426v22m94-22v22" stroke="#FFF9F1" stroke-width="25"/><path d="M319 425v11" stroke="#E2B4BF" stroke-width="25"/><path d="M413 425v11" stroke="#A6B8C7" stroke-width="25"/></g>'
    c.anim('.rig-shoe-left',3.6,{'0%,100%':'transform:translate(0,0) rotate(0);','38%,65%':'transform:translate(-115px,-286px) rotate(-67deg) scale(.87);','80%':'transform:translate(3px,5px) rotate(7deg);'})
    c.anim('.rig-shoe-right',3.6,{'0%,100%':'transform:translate(0,0) rotate(0);','38%,65%':'transform:translate(150px,-286px) rotate(67deg) scale(.87);','80%':'transform:translate(-3px,5px) rotate(-7deg);'})
    c.anim('.rig-glasses',3.6,{'0%,100%':'transform:translateY(0);','38%,65%':'transform:translateY(-104px) rotate(4deg) scale(.9);','80%':'transform:translateY(4px);'})
    c.front += '<g class="fx-magnetic" stroke="#B89ECB" stroke-width="5" stroke-linecap="round"><path d="M269 407q-24-25-15-49m202 49q24-25 15-49M280 395l-14-35m174 35 14-35"/></g>'
    c.anim('.fx-magnetic',3.6,{'0%,18%,82%,100%':'opacity:0;','38%,65%':'opacity:.7;'})
    for cl in ['.pupil-left','.pupil-right']:
        c.anim(cl,3.6,{'0%,100%':'transform:translateY(12px);','38%,65%':'transform:translateY(-2px);'})

    # 55. Outlined transparent bubbles, no blur/raster filters.
    c = reg('bubbles','Making the problem more bubbly','Magic',3.2,
        'Blows transparent soap bubbles from a little wand, cheeks puffing as the bubbles float off',
        'Bubbling|Bubble-blowing|Effervescing','Flowing|Misting|Nebulizing|Fermenting|Enchanting', 'low')
    c.mouth_markup = '<circle cx="379" cy="342" r="12" fill="#393A35"/>'
    c.style('.rig-right-arm','transform:rotate(86deg);')
    c.rig_extra += '<g class="prop-bubble-wand"><path d="M475 421l-29-59" stroke="#A58AB6" stroke-width="8" stroke-linecap="round"/><circle cx="436" cy="344" r="24" stroke="#A58AB6" stroke-width="7"/></g>'
    c.anim('.rig-head',3.2,{'0%,100%':'transform:scale(1);','32%,48%':'transform:scale(1.035,.985);'})
    c.anim('.rig-mouth',3.2,{'0%,100%':'transform:scale(.55);','32%,48%':'transform:scale(1);'})
    for i,(x,y,r,dx,dy) in enumerate([(469,331,18,106,-124),(511,290,26,97,-141),(568,219,14,67,-109)]):
        c.front += f'<g class="fx-soap-{i}"><circle cx="{x}" cy="{y}" r="{r}" fill="#EADFF2" fill-opacity=".12" stroke="#BCA1CD" stroke-width="3"/><path d="M{x-r*.45} {y-r*.5}q{r*.35} {-r*.3} {r*.7} 0" stroke="#FFF9F1" stroke-width="3" stroke-linecap="round"/></g>'
        c.style(f'.fx-soap-{i}',f'transform-origin:{x}px {y}px;')
        c.anim(f'.fx-soap-{i}',3.2,{'0%':'transform:translate(0,0) scale(.1);opacity:0;','28%':'opacity:.8;','78%':f'transform:translate({dx*.7:g}px,{dy*.7:g}px) scale(1);opacity:.6;','100%':f'transform:translate({dx}px,{dy}px) scale(1.1);opacity:0;'},delay=-i*.85)

    # 56. A wind-up key and deliberately clockwork footwork.
    c = reg('wind-up','Powered by a very small key','Making',2.4,
        'Winds a tiny key behind its brain, then marches in short clockwork steps before winding itself again',
        'Winding-up|Rewinding|Clockworking','Bootstrapping|Working|Whirring|Churning|Processing', 'medium')
    c.rig_back += '<g class="prop-clock-key"><path d="M617 343h57" stroke="#9F86AF" stroke-width="10" stroke-linecap="round"/><path d="M670 343 C651 320 665 299 681 315 C697 299 711 320 692 343 C711 367 697 389 681 373 C665 389 651 367 670 343Z" fill="#CBB9D8" stroke="#9F86AF" stroke-width="5"/></g>'
    c.style('.prop-clock-key','transform-origin:681px 344px;')
    c.anim('.prop-clock-key',1.2,{'0%,100%':'transform:scaleY(1);','25%':'transform:scaleY(.12);','50%':'transform:scaleY(-1);','75%':'transform:scaleY(-.12);'},'linear')
    c.anim('.rig-left-leg',1.2,{'0%,100%':'transform:rotate(-12deg);','25%':'transform:rotate(12deg);','50%':'transform:rotate(-12deg);','75%':'transform:rotate(12deg);'},'steps(2,end)')
    c.anim('.rig-right-leg',1.2,{'0%,100%':'transform:rotate(12deg);','25%':'transform:rotate(-12deg);','50%':'transform:rotate(12deg);','75%':'transform:rotate(-12deg);'},'steps(2,end)')
    c.anim('.rig-left-arm',1.2,{'0%,100%':'transform:rotate(-25deg);','50%':'transform:rotate(14deg);'},'steps(3,end)')
    c.anim('.rig-right-arm',1.2,{'0%,100%':'transform:rotate(14deg);','50%':'transform:rotate(-25deg);'},'steps(3,end)')
    c.anim('.rig-head',2.4,{'0%,100%':'transform:rotate(-2deg);','50%':'transform:rotate(2deg);'},'steps(4,end)')

    # 57. Visible bellows between independent cheek halves.
    c = reg('accordion','Concertina of questionable thoughts','Dancing',2.4,
        'Pulls its two brain cheeks apart like an accordion, revealing pastel bellows, then squeezes them back together',
        'Accordioning|Concertina-ing|Squeezing','Churning|Smooshing|Reticulating|Synthesizing|Harmonizing', 'medium', split=True)
    c.rig_back += '<g class="prop-bellows"><path d="M291 180H425V438H291Z" fill="#F0E4F5" stroke="#B49AC5" stroke-width="4"/>'+''.join(f'<path d="M{x} 181l9 33-9 33 9 33-9 33 9 33-9 33 9 33-9 24" stroke="#BAA2CA" stroke-width="4"/>' for x in range(299,425,18))+'</g>'
    c.style('.prop-bellows','transform-origin:357px 310px;')
    c.anim('.prop-bellows',2.4,{'0%,100%':'transform:scaleX(.28);','50%':'transform:scaleX(1);'})
    c.anim('.lobe-left',2.4,{'0%,100%':'transform:translate(0,0) scale(1);','50%':'transform:translate(-42px,0) scale(.9,1);'})
    c.anim('.lobe-right',2.4,{'0%,100%':'transform:translate(0,0) scale(1);','50%':'transform:translate(42px,0) scale(.9,1);'})
    c.anim('.rig-left-arm',2.4,{'0%,100%':'transform:rotate(-80deg);','50%':'transform:translateX(-35px) rotate(-70deg);'})
    c.anim('.rig-right-arm',2.4,{'0%,100%':'transform:rotate(80deg);','50%':'transform:translateX(35px) rotate(70deg);'})
    c.music()

    # 58. Extended rubbery forearms actually meet, then confetti expands from the clap.
    c = reg('confetti','A completely proportionate celebration','Mischief',2.8,
        'Brings two long rubbery hands together for a clap and launches a restrained but deeply self-satisfied confetti burst',
        'Celebrating|High-fiving|Confetti-ing','Accomplishing|Actualizing|Beaming|Manifesting|Razzmatazzing', 'high')
    c.left_arm_markup = '<path d="M151 358 Q179 439 325 409" stroke="#393A35" stroke-width="21" stroke-linecap="round"/><ellipse cx="338" cy="407" rx="26" ry="27" fill="#393A35"/><circle cx="327" cy="389" r="12" fill="#393A35"/>'
    c.right_arm_markup = '<path d="M580 358 Q544 439 410 409" stroke="#393A35" stroke-width="21" stroke-linecap="round"/><ellipse cx="397" cy="407" rx="26" ry="27" fill="#393A35"/><circle cx="408" cy="389" r="12" fill="#393A35"/>'
    c.anim('.rig-left-arm',2.8,{'0%,100%':'transform:translateX(-33px) rotate(-5deg);','28%,38%':'transform:translateX(23px) rotate(0);','54%':'transform:translateX(-18px) rotate(-3deg);'})
    c.anim('.rig-right-arm',2.8,{'0%,100%':'transform:translateX(33px) rotate(5deg);','28%,38%':'transform:translateX(-23px) rotate(0);','54%':'transform:translateX(18px) rotate(3deg);'})
    c.anim('.rig-root',2.8,{'0%,100%':'transform:scale(1);','28%':'transform:translateY(-8px) scale(.99,1.02);','50%':'transform:translateY(3px) scale(1.02,.98);'})
    for i,(dx,dy,angle,color) in enumerate([(-270,-239,-50,PURPLE),(-160,-287,25,PINK),(-49,-301,-40,YELLOW),(92,-304,35,PURPLE),(198,-256,-35,PINK),(277,-165,45,YELLOW),(-299,-83,28,YELLOW),(286,-49,-25,PURPLE)]):
        c.front += f'<g class="fx-confetti-{i}"><rect x="362" y="397" width="10" height="22" rx="3" fill="{color}"/></g>'
        c.style(f'.fx-confetti-{i}','transform-origin:367px 408px;')
        c.anim(f'.fx-confetti-{i}',2.8,{'0%,25%,100%':'transform:translate(0,0) rotate(0);opacity:0;','32%':'opacity:1;','75%':f'transform:translate({dx}px,{dy}px) rotate({angle}deg);opacity:.8;','94%':f'transform:translate({dx*1.08:g}px,{dy+38}px) rotate({angle+30}deg);opacity:0;'},'cubic-bezier(.15,.5,.4,1)')

    # 59. The fixed sling is transparent around its vector fabric, never a background patch.
    c = reg('hammock','A rigorous horizontal investigation','Thinking',4.8,
        'Reclines diagonally in a tiny hammock, swinging slowly while a purple shoe dangles without a care',
        'Lounging|Hammocking|Unwinding','Mulling|Contemplating|Ruminating|Moseying|Marinating', 'low')
    c.back += '<g class="prop-hammock"><path d="M110 390 C150 640 560 640 630 390 C524 540 215 540 110 390Z" fill="#E1D4E9" stroke="#BBA2CB" stroke-width="5"/><path d="M95 390V665m550-275v275" stroke="#BCA5CB" stroke-width="12" stroke-linecap="round"/><path d="M95 393l15-3m520 0 15 3" stroke="#A98BBD" stroke-width="5"/></g>'
    c.style('.rig-root','transform-origin:356px 380px;')
    c.anim('.rig-root',4.8,{'0%,100%':'transform:translate(-8px,53px) rotate(-68deg) scale(.67);','50%':'transform:translate(8px,45px) rotate(-74deg) scale(.67);'})
    c.style('.rig-left-arm','transform:rotate(15deg);')
    c.style('.rig-right-arm','transform:rotate(-18deg);')
    c.anim('.rig-right-leg',4.8,{'0%,100%':'transform:rotate(12deg);','50%':'transform:rotate(25deg);'})
    c.anim('.rig-shoe-right',2.4,{'0%,100%':'transform:rotate(-7deg);','50%':'transform:rotate(7deg);'})
    c.style('.rig-ground','opacity:0;')

    # 60. The front shoe stays in the world while the character spirals into it.
    c = reg('shoe-vortex','There is a universe in that shoe','Magic',3.6,
        'Gets gently corkscrewed into its own purple shoe, disappears for a beat, then pops out with its smirk intact',
        'Vacuuming|Imploding|Vanishing','Warping|Hyperspacing|Whirlpooling|Sublimating|Evaporating', 'high')
    c.style('.rig-shoe-right','opacity:0;')
    c.style('.rig-root','transform-origin:423px 610px;')
    c.anim('.rig-root',3.6,{'0%,100%':'transform:scale(1) rotate(0);opacity:1;','18%':'transform:translateY(0) scale(.97,1.02) rotate(-5deg);opacity:1;','28%':'transform:translateY(-40px) scale(.6,.62) rotate(-35deg);opacity:1;','40%':'transform:translateY(-22px) scale(.16,.23) rotate(-170deg);opacity:.8;','49%':'transform:scale(0) rotate(-240deg);opacity:0;','57%':'transform:translate(-55px,-120px) scale(.2) rotate(35deg);opacity:0;','73%':'transform:translate(-12px,-30px) scale(.95,1.03) rotate(4deg);opacity:1;','87%':'transform:scale(1.03,.98) rotate(-2deg);opacity:1;'})
    c.front += '<g class="prop-vortex-shoe"><use href="#shoe-right-art"/></g><g class="fx-shoe-spiral" stroke="#B19AC2" stroke-width="5" stroke-linecap="round"><path d="M368 581 C352 554 474 542 486 571 C494 593 389 604 386 581 C384 568 450 564 450 580"/></g>'
    c.style('.prop-vortex-shoe','transform-origin:423px 610px;')
    c.anim('.prop-vortex-shoe',3.6,{'0%,100%':'transform:rotate(0);','35%':'transform:rotate(-9deg) scale(1.12,.92);','50%':'transform:rotate(9deg) scale(1.05,.96);','73%':'transform:rotate(-4deg);'})
    c.anim('.fx-shoe-spiral',3.6,{'0%,13%,76%,100%':'opacity:0;','35%,55%':'opacity:.85;'})
    c.anim('.rig-left-arm',3.6,{'0%,100%':'transform:rotate(0);','30%,65%':'transform:rotate(-145deg);'})
    c.anim('.rig-right-arm',3.6,{'0%,100%':'transform:rotate(0);','30%,65%':'transform:rotate(145deg);'})

    assert len(new) == 24
    assert len({c.slug for c in new}) == 24
    return new
