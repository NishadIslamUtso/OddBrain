#!/usr/bin/env python3
"""Embed local assets into one offline gallery; refresh the generated motion index."""
from pathlib import Path
import json, re

ROOT=Path(__file__).resolve().parent.parent
D=json.loads((ROOT/'source/gallery-data.json').read_text())
readme=ROOT/'README.md'
text=readme.read_text()
table='| # | ID | Motion | Category | Main beat | Volume | Words |\n|---|---|---|---|---|---|---|\n'+'\n'.join(
    f'| {m["index"]:02} | `{m["id"]}` | {m["name"]} | {m["category"]} | {m["duration"]:g}s'
    + (' once' if not m['loop'] else '')
    + f' | {m["volume"]:02} | {len(m["words"])} |'
    for m in D['motions']
)
rendered='<!-- MOTION_TABLE_START -->\n'+table+'\n<!-- MOTION_TABLE_END -->'
if '<!-- MOTION_TABLE_START -->' in text:
    text=re.sub(r'<!-- MOTION_TABLE_START -->.*?<!-- MOTION_TABLE_END -->',lambda _:rendered,text,flags=re.S)
else:
    text=text.replace('__MOTION_TABLE__',table)
readme.write_text(text)
files={}
for file in [*sorted(ROOT.glob('*.md')),*sorted((ROOT/'react').glob('*')),*sorted((ROOT/'source').glob('*'))]:
    if file.is_file() and file.name != 'gallery-data.json':
        files[str(file.relative_to(ROOT))]=file.read_text()
D['downloadFiles']=files
payload=json.dumps(D,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
template=(ROOT/'source/gallery.template.html').read_text()
assert template.count('__DATA__')==1
(ROOT/'index.html').write_text(template.replace('__DATA__',payload))
print(f'Offline gallery: {len(D["motions"])} motions, {(ROOT/"index.html").stat().st_size:,} bytes; {len(files)} editable/integration files embedded.')
