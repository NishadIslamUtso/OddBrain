# Volume 02 — 24 new ways to misbehave

**24 new looping SVGs. Full kit: 60 character motions + 1 compact loader.**

All original artwork, motion keyframes, and 187 canonical mappings are preserved. The old SVGs receive only a playback-CSS specificity fix so every limb pauses correctly. These are additional physical-comedy scenes, not re-colored copies of the first pack.

## The new bits

| ID | Motion | What happens | Main beat |
|---|---|---|---|
| `shoe-skateboard` | Questionable transport | One shoe is the deck. The other foot pushes. Tiny wheels, terrible balance. | 2.4s |
| `brain-kickflip` | Hold my frontal lobe | Flips its own brain-head while the legs wait below. | 3.2s |
| `sneeze` | Achoo, there go the glasses | Winds up a sneeze, launches the shades, recovers. | 3.6s |
| `pocket-panic` | Wait. I do not have pockets. | Pats cheeks, checks its head, remembers the lack of outfit. | 2.8s |
| `shoe-phone` | The sole support line | Uses its own shoe as a telephone. Very professional nodding. | 3.2s |
| `cheek-drums` | Built-in bongos | Plays its own cheeks with alternating palms and squishing lobes. | 1.2s |
| `glasses-clean` | Polishing the perspective | Takes shades off, wipes a lens, eyes follow the cloth. | 3.2s |
| `noodle-slurp` | One very long thought | Slurps an impossibly long noodle from a tiny bowl. | 3.2s |
| `nap` | Saving brain power | Slow breathing, a sleep bubble, and little vector Zs. | 4.8s |
| `stretch` | Booting the last brain cell | Huge yawn, long rubber arms, slow deflation. | 4.2s |
| `sneak` | Definitely not up to anything | Crouched toe-first steps and a conspiratorial almost-shush. | 2.4s |
| `peekaboo` | Just checking if you are still there | Half-peeks around an edge before making a full entrance. | 4s |
| `balloon-brain` | A head full of helium | Its own head floats on a string held by its own hand. | 4s |
| `hula-hoop` | Doctorate in hoopla | Real front/back hoop occlusion around independent cheek wobbling. | 1.6s |
| `tap-dance` | The clack department | Heel-toe patterns and a little double heel-click. | 1.6s |
| `cancan` | No skirt. All can-can. | Alternating high kicks, shoes visible in front of the brain. | 1.6s |
| `ribbon` | Absolutely not Olympic regulation | Big looping ribbon flourishes while balancing on one foot. | 2.8s |
| `magnet` | Magnetic personality disorder | A magnet attracts its actual detachable shoes and sunglasses. | 3.6s |
| `bubbles` | Making the problem more bubbly | Puffing cheeks blow outlined soap bubbles from a wand. | 3.2s |
| `wind-up` | Powered by a very small key | A turning wind-up key and deliberately clockwork footwork. | 2.4s |
| `accordion` | Concertina of questionable thoughts | Pulls cheek halves apart to reveal pastel accordion bellows. | 2.4s |
| `confetti` | A completely proportionate celebration | Hands actually meet, then confetti expands from the clap. | 2.8s |
| `hammock` | A rigorous horizontal investigation | Slow hammock lounging with an unconcerned dangling shoe. | 4.8s |
| `shoe-vortex` | There is a universe in that shoe | Corkscrews into its own shoe and pops back out. | 3.6s |

## Use a new clip directly

```tsx
<Oddbrain motion="shoe-phone" size={160} />
<Oddbrain motion="hula-hoop" size={160} />
<Oddbrain motion="shoe-vortex" size={160} />
```

Or use an external image with zero animation JavaScript:

```html
<img src="/oddbrain/cheek-drums.svg" width="140" height="140" alt="" />
```

## Use a new take for an existing word

The stable default remains unchanged:

```tsx
<Oddbrain word="Befuddling" size={100} />
// Original: eye-roll

<Oddbrain word="Befuddling" variant={1} size={100} />
// New: pocket-panic
```

Use `motionVariants(word)` to inspect a word's available takes, or see `status-variants.json`. Index zero is always the canonical default; higher indices wrap. Each new clip also has three new words, adding **72** optional status labels to the original **187**.

The gallery starts on **New**. Enter a word and choose **Another take** to preview the alternatives without changing its label.

## Two archives

- **Complete kit:** gallery, all 61 SVGs, original source, both editable generators, React/TypeScript, all mappings and variants.
- **Volume 02-only archive:** just these 24 SVGs, expansion metadata, 72 new word mappings, and this guide. Use the complete kit for the updated React renderer and full gallery.

All files remain vector, transparent, CSS-animated, and reduced-motion aware. No PNGs, GIFs, or external animation libraries are required.
