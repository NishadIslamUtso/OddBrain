# Memory_OB Goose addon — package manifest

Built: 2026-10-23T09:30:30.401Z
Version: 0.9.5 (a6c7807, uncommitted changes in the build checkout)
Targets: Windows 11 + Node.js 24 (works on macOS/Linux too). No paid services. No telemetry.

## What this folder is

One folder you can copy anywhere. It makes plain Goose work with your one
memory (`Memory_OB`) without installing or maintaining any app:

- `install.mjs` — installs the read-only tools + the in-chat screens + the skill into Goose and
  switches Goose's stock memory off, in one reviewed change (type `ALLOW`).
- `import-goose-history.mjs` — the one-time import of your existing Goose
  sessions and memory, run BEFORE installing. Everything imported is labelled
  raw unconfirmed evidence.
- `fix-goose-extensions.mjs` — rebuilds extensions that Goose dropped from
  its config because their old shape stopped parsing (type `ALLOW`).
- `brain-window.mjs` — the local Brain Window: Projects, Vault (files, search,
  graph, link check, folder choose-and-decide) and Review (the only place
  memory is confirmed).
- `dist/` — pre-built engines. No build step needed on your machine.

## Sources and versions

| Part | Source | Version |
| --- | --- | --- |
| Adapter + tools (dist/memory-ob-mcp.cjs) | OddBrain apps/03_oddbrain main/memoryOb | 0.9.5 |
| Import engine (dist/goose-import-core.cjs) | OddBrain main/memoryOb/gooseImport | 0.9.5 |
| Brain Window host (dist/brain-window-server.cjs) | OddBrain main/brainWindow | 0.9.5 |
| Interface (ui/) | OddBrain renderer (dist-web build) | 0.9.5 |
| Goose storage formats | Goose v1.55.0 (sessions.db, .jsonl sessions, memory/*.txt) | v1.55.0 |
| Skill (goose-skill/SKILL.md) | packages/Memory_OB/goose-skill | 0.9.5 |

## Commands

| You run | What it does |
| --- | --- |
| `node import-goose-history.mjs` | Preview your Goose history (changes nothing) |
| `node import-goose-history.mjs --apply` | Import it (type ALLOW) |
| `node install.mjs --goose-config <config.yaml>` | Review the exact change, type ALLOW to install |
| `node brain-window.mjs` | Open Projects · Vault · Review in your browser |
| `node dist/memory-ob-mcp.cjs --catalogue <store> --chats <chats> owner list` | Owner commands (never-send / allow-send) |

## File checksums (SHA-256)

| File | Bytes | SHA-256 |
| --- | --- | --- |
| `brain-window.mjs` | 3525 | `e959b4f1a43b8683c4b5ac27e0b5c4b009257e2f66648aeb669f9fecd93bb0b4` |
| `dist/brain-window-server.cjs` | 576189 | `ee262d7b441ea7d240b3462a5c805d52ca5dcecb5b657d046a080c991ab22d57` |
| `dist/goose-import-core.cjs` | 116013 | `707ddb4e1682eadd6c73765b0e70128b2d16b9e6e4432f5d07949d2e4cd4fd05` |
| `dist/memory-ob-mcp.cjs` | 475495 | `8e76c545ab08fb7e013cf78ee76d5d9d5720eeb7181bb846ea16571b977a1b1b` |
| `dist/memory-ob-semantic.cjs` | 111536 | `945d03b733b4cfc835bc1747409aff4f5eebc0e12c91d0d82051a91d7ac720c7` |
| `fix-goose-extensions.mjs` | 15791 | `3ff898a86b7cd78a96e9a4541603c4f25364035ba887bc45d84cb5e7db59eb0a` |
| `goose-skill/SKILL.md` | 3755 | `5dc778f7343f09dfe55819fc36b0d866630130901023f0ce528b3faddc38a9ce` |
| `import-goose-history.mjs` | 6556 | `264cc81b4c0d48c90b5d82edb93de339fee3d4db7ecd90acb1e271f3f7947819` |
| `install.mjs` | 19570 | `2052d0ce8bb4fde25107a0d5d2884db574a1a8266d10f9c698eec9a1580fe9c6` |
| `LICENSE` | 11358 | `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30` |
| `README.md` | 9382 | `f51182017ffaa18778e683ec19a8674362b0690cd6b28c5a51817bc2994a3784` |
| `semantic-search.mjs` | 4736 | `ae49ffb23aa1e3423d0e2033984ca410826db796ab5c0c24f9bfd10215b141e9` |
| `ui/assets/ArtifactsView-Zp_6NN8x.js` | 17291 | `bae965275c4e318c6f071570eb6be64275ca834de7a0dad3b1491aa855f7516b` |
| `ui/assets/BrainView-CDbFyDhu.js` | 42563 | `21ad521a39352e1de8c1c08d825dfa98338aeb11c1cb95ec72ca75c0c8ba147e` |
| `ui/assets/ConnectionGraph-D9SATbEo.js` | 16486 | `0b2d3c028c88ac0a8559a2ee12993ae9f9c4c8e2c5fd9dfa1f53da8ac1e4f407` |
| `ui/assets/external-link-DJqWRj1k.js` | 419 | `49783873dc10d405a893d94f0711034b61aeec8d5a26b99e6c8b0a15d8a11a47` |
| `ui/assets/index-B_en5LOe.js` | 1919018 | `f30217ec4a72c731e700640fbaa705cde1b8dfe5f8e24aa5a1dd6c6a6e8f7165` |
| `ui/assets/index-Cco02AzG.css` | 93392 | `843c1ca8615fd04dbb9e78d6bbee8f2cca53fcc7bd98421d701b465f54f451c5` |
| `ui/assets/link-2-BrsotVLF.js` | 410 | `22445be364c9df09613109877bf1f3013afae3cc235b58a214d01c2845193d96` |
| `ui/assets/NativeRuleReview-kg6yvUZL.js` | 1258 | `b1e65438811cdf7e57984670f5877d4bbcbb62d890d1d9c158503666cafdc2e4` |
| `ui/assets/ProjectsView-RGll_GSp.js` | 32400 | `d5a236ee496f04448c44a93676edcacc9f1490744c29efdcff6fad0d40d61960` |
| `ui/assets/refresh-cw-CMvXRC0g.js` | 489 | `02718cc2fb80198a42e6cd36765dd205464a8acb1c8f7897a983618362e1aa4d` |
| `ui/assets/SettingsView-D36Z57Id.js` | 205690 | `08125b679668cff267abcae992f9641c5a182a2c5286ecf56e040f7d9da9b90f` |
| `ui/assets/trash-2-Ct96zWUW.js` | 526 | `212de6a53790c8695763aa5102208fa65394721f37453abd43dca25830939a33` |
| `ui/assets/upload-DV2DTvfY.js` | 808 | `dbedba74dca2690f0e843058e638b17e788b64a4cb16caeccd04820cd3535033` |
| `ui/assets/VaultView-6LIktZrc.js` | 20465 | `d81de0c85fbd15f457a3ec76e75b704d81523ebd162843921680867b4b819e4d` |
| `ui/assets/VideoStudioView-8UFps0bR.js` | 31126 | `77d2ec9594294f164a620c29f7830c85b2c9a60b015ed171d4747fd483c45a33` |
| `ui/favicon.svg` | 8536 | `bde15dc3db2beb27ad58c6257b0d0f94e023305509db1e667d14e97c1b6dea29` |
| `ui/index.html` | 1092 | `59df670e2ac0d1dafe55e3c39177bd75dddc8da9dffae71ea31a2f3df9e21d11` |
| `ui/oddbrain-preview.html` | 700650 | `43e8d1211cde1c482833f21a9e127e40ebcd822b4b3077b0f9fb30c3fc84a7b4` |

## States

- Verified in the repository suite before packaging: install smoke 34/34,
  import smoke 20/20, judge traps 33/33 (Never-Send, project scope, hazard
  excerpts, restart identity, trashed chats, empty catalogue), Brain Window
  smoke 10/10, `security:release` and `security:policy` passed on the build
  this package was cut from.
- The package itself is verified end-to-end by
  `packages/Memory_OB/goose-addon/test/package-smoke.sh` in the repository:
  it copies THIS folder to a clean place and runs import + install + Brain
  Window from it.

## Decisions this package keeps

- One memory authority: the brain folder. Nothing else is a second database.
- Goose never confirms its own memory; the Review screen is the only place
  confirmations happen.
- Imported history is raw unconfirmed evidence (`origin: import`), never
  silently trusted.
- Goose's own folders are read-only sources; the AI may move things to
  recoverable Trash but never permanently deletes.
- No telemetry, no credentials, no external services, no phone-home.
