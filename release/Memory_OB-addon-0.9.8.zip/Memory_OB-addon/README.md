# Memory_OB for Goose

This addon gives your **plain Goose** a real memory — the OddBrain brain — with
**no OddBrain app** to install, build, or maintain.

Once it is installed:

- Goose reads **your** memory only: confirmed facts first, raw chat evidence
  second, pending/rejected never as facts, and "not found" instead of guessing.
- The installer switches **off** Goose's stock `memory` extension in the
  reviewed config change, leaving its existing files alone. Verify that Goose
  accepted this change after restarting it.
- Your memory lives in **one brain folder** as plain files you can open and
  read; Goose config, installed skill and Apps-page snapshot live separately.
- Goose gets four read-only tools, a screens tool, and `memory_ob_propose`, a
  model-callable **pending-draft writer**. It cannot confirm memory: that needs
  your separate review in the local Brain Window. An approval card is not
  independent owner authentication. Set Goose permission to **Ask Before**
  (never Always Allow) and inspect any proposed draft yourself.

## Install (one command)

1. Make sure Goose has run once (so `config.yaml` exists) and Node.js 24 is installed.
2. Run:

```
node install.mjs --goose-config <path\to\goose\config.yaml>
```

On newer Windows installations the config is usually
`$env:APPDATA\Block\goose\config\config.yaml` (PowerShell); inspect the
actual file before passing its full path. The default brain folder is
`~/Memory_OB`; specify `--brain <folder>` to use your existing brain instead.
Never install into a second brain by accident.

3. Read the exact proposed changes it prints. Type `ALLOW` to write them,
   anything else cancels. Nothing is written before you allow.

**Before you install on a computer that has history you want to keep:** run the
history import first (see *Import your Goose history* below). The install
switches Goose's stock memory off in the same change, and Goose stops reading
its old memory store afterwards.

**Upgrading from 0.9.7 or earlier?** The earlier installer could prepend NUL
(zero) bytes to Goose's config; 0.9.8 fixes that write and refuses to modify
any config that already contains NULs. First make a copy of your config and
check it with the read-only PowerShell command below. If the count is nonzero,
STOP: compare `config.yaml.oddbrain-original*` backups to your current file
before manually repairing it. Do not blindly restore an older backup; it may
lose later changes. Never paste the config contents or provider credentials
into an issue or chat.

```powershell
$cfg = Join-Path $env:APPDATA 'Block\goose\config\config.yaml'
if (-not (Test-Path -LiteralPath $cfg)) { throw 'Find the actual Goose config path first.' }
$b = [IO.File]::ReadAllBytes($cfg)
$leading = 0; while ($leading -lt $b.Length -and $b[$leading] -eq 0) { $leading++ }
$zeros = 0; foreach ($byte in $b) { if ($byte -eq 0) { $zeros++ } }
"Zero bytes in config: $zeros (leading: $leading)"
Get-ChildItem -LiteralPath (Split-Path $cfg) -Filter 'config.yaml.oddbrain-original*' |
  Select-Object Name,Length,LastWriteTime
```

Also inspect records created through the old `memory_ob_propose` in the local
Brain Window Review: a Goose tool call could mark them owner-confirmed without
authenticating the owner. Keep a backup of your brain before correcting or
withdrawing any questionable records. We do not silently change old records.

The installer:

- adds one `memory_ob` extension entry (four read tools, screens, and the model-callable `memory_ob_propose` writer),
- switches **off** Goose's stock `memory` extension (`enabled: false`),
- creates the brain folder ready to use, including an empty memory catalogue,
- installs the `memory-ob-memory` rule sheet into Goose's skills folder,
- keeps your original `config.yaml` as a backup,
- writes a receipt with SHA-256 hashes of everything it installed,
- checks installed adapter, skill and Apps-page snapshot against their prior receipt before replacing them.

## What the tools do

| Tool | What it does |
|---|---|
| `memory_ob_status` | Is the brain alive? Which revision? |
| `memory_ob_search` | Find exact word matches in confirmed memory and raw chat evidence. Every answer carries its authority label. |
| `memory_ob_project` | Bounded counts for one Project. |
| `memory_ob_evidence` | Return exact wording, only while the stored bytes still match the SHA-256 you were given. Changed source → refused. Raw chat evidence needs its Project ID — same boundary as search. |
| `memory_ob_propose` | The one model-callable writer; creates one **unconfirmed draft** from a quotation in a stored chat. It never approves the draft. |

## Drafts from Goose, and your actual Review decision

`memory_ob_propose` can create a **pending draft** after finding its exact
quotation in a live chat *already stored in Memory_OB*. Goose's current chat
is not automatically imported; when the quoted message is missing, the call
refuses without confirming anything. Previously imported history can supply a
quote. A model can call this writer, so it is not an authenticated owner action.

Goose may show a tool approval card. If it does, inspect the proposed kind,
title, text and quote. **Allow means create a draft, not approve a fact.** The
separate local Brain Window's Review screen is where you must inspect and
approve, reject, correct or withdraw records. It is a local UI workflow, not a
cryptographically authenticated owner-only boundary. Disable unrelated Goose
shell/network tools if they could reach your files or the local Brain Window.

- Keep `memory_ob_propose` on **Ask Before**, never Always Allow. Goose's exact
  permission behavior still needs testing on your Windows setup.
- A quote must occur in a stored conversation and, for personal facts, in the
  user's message. This verifies a source exists; it does **not** prove consent.
- A Goose tool response saying `pending: true` is **not** remembered truth.
  Pending and rejected material is not returned as confirmed memory.

## Hiding a record from Goose (Never Send)

You decide what Goose can ever see. On your own machine, in a terminal:

```
node <brain>/adapter/memory-ob-mcp.cjs --catalogue <brain>/store --chats <brain>/chats --vault <brain> owner list
node <brain>/adapter/memory-ob-mcp.cjs --catalogue <brain>/store --chats <brain>/chats --vault <brain> owner never-send <recordId>
node <brain>/adapter/memory-ob-mcp.cjs --catalogue <brain>/store --chats <brain>/chats --vault <brain> owner allow-send <recordId>
```

`owner list` shows every record with its `recordId`, sensitivity and Never-Send
mark. `never-send` hides it from all four tools immediately and permanently —
OddBrain keeps your choice across every memory sync. `allow-send` clears the
mark again. The install receipt prints the full command with your real paths.

## The brain folder

```
Memory_OB/
  00 System/        privacy rules (your Never-Check list)
  02 Sources/       raw sources (conversations, documents)
  03 Memory/        confirmed memory
  06 Review/        the review queue (doubts, confirmations, interpretations)
  99 Trash/         recoverable trash — nothing is ever permanently deleted
  store/            the catalogue (identities, links, hashes)
  chats/            durable chat records
  adapter/          the adapter bundle + ownership receipt
```

## What works inside Goose, and what still needs the Brain Window

In Goose chat, the Projects, Vault and Review tabs show a read-only view of
current memory. Refresh reads the same MCP resource directly, without another
model request. The Apps-page window is a stamped installation-time snapshot,
not a live screen. Creating/editing Projects, full Vault search and graph, and
Review undo/revoke still require the separate local browser window below;
none of those controls have been moved into Goose. This is **not yet** a fully
functional three-screen Goose interface.

## The Brain Window (your screens on your brain)

```
node brain-window.mjs
```

One command opens the **same OddBrain screens** in your browser, on your brain
folder (default `~/Memory_OB`, change with `--brain <folder>`):

- **Projects screen** — create and edit Projects, their goals and attached
  reference files; shared Project memory is one catalogue for Goose and the app.
- **Vault screen** — your brain's files, vault search, and the memory graph with
  an honest link check (dead and ambiguous links are reported, never repaired
  behind your back).
- **Review screen** — doubts, confirmations, interpretations: the only place
  memory is ever confirmed. Decisions are saved immediately.
- **Brain screen** — memory checking at a glance: chats, trash, and what memory
  holds.
- **First run** — selecting a folder (your memory folder / data folder) and
  deciding what to do with it: prepare it as a brain, or leave it untouched.

It is local-only (127.0.0.1): nothing on your network can reach it. No desktop
app is installed or required. Anything that needs the real desktop app keeps
saying so out loud instead of pretending.

## Import your Goose history (one time, before installing)

On the computer that still has your Goose history:

```
node import-goose-history.mjs            # preview — changes nothing
node import-goose-history.mjs --apply    # type ALLOW to write it into the brain
```

It reads Goose's sessions (the SQLite store and old `.jsonl` files) and the
stock `memory/*.txt` categories — including `Chat Recall`, which is only a
search over those same sessions. Every message lands in the brain labelled
**raw unconfirmed evidence** (`origin: import`), to be reviewed in the Review
screen like any other evidence. Goose's folders are never changed; re-running
skips what is already imported. Tool calls and tool results are counted and
skipped — only the conversation itself is kept.

## Anything, no matter the module

Any module can hand memory its raw sources (video, documents, browser —
whatever you add next). Memory keeps an untouched copy, labels it raw
unconfirmed evidence (never a confirmed fact or instruction), finds it in
search, and quotes it only hash-verified and inside a Project scope — exactly
like chat evidence. The same Never Send and local-only rules apply.

## Meaning search (optional)

A separate optional module that finds candidates by *meaning*. It sits beside
the exact word search and never replaces it — word-match results stay exactly
as they are. Meaning candidates are labelled UNVERIFIED; confirm exact wording
with `memory_ob_evidence` before quoting anything.

Enable it from the standalone folder (or the addon):

```
node semantic-search.mjs --brain "C:\Users\you\Memory_OB" enable
node semantic-search.mjs --brain "C:\Users\you\Memory_OB" rebuild
node semantic-search.mjs --brain "C:\Users\you\Memory_OB" search "what did we decide about the trailer"
```

It uses any free embeddings endpoint you connect (for example your Ollama
Cloud allowance) via `ODDBRAIN_MODEL_BASE_URL` and `ODDBRAIN_EMBED_MODEL` —
no local model is ever downloaded. The vector index is a rebuildable
derivative; deleting it loses nothing.

## Still coming next (built on this)

- **Engine-notes proposals**: the organizer drafts memory proposals from
  conversations and shows them for review. You confirm each draft in the
  local Brain Window Review; Goose cannot confirm it with a tool call.
- **Real-machine acceptance** on your Windows machine with plain Goose.

## The ready-to-download folder

`npm run package:addon` (in `apps/03_oddbrain`) builds
`packages/Memory_OB/dist-addon/Memory_OB-addon/` plus a `.zip`: the whole
addon pre-built — installer, import CLI, Brain Window launcher with its server
and interface, the four-tool adapter core, and the skill — with a `MANIFEST.md`
recording sources, versions, commands, states and SHA-256 checksums for every
file. Copy the folder anywhere and run its commands; nothing needs building.

## Rules this addon lives by

- One memory authority: this brain. Not a second database anywhere.
- Goose never confirms its own memory.
- Raw, pending, rejected and confirmed stay separate and labelled.
- Excluded/Never-Check sources are never returned, even if they were reviewed before.
- Trash is recoverable; permanent deletion is yours alone, after impact review.
