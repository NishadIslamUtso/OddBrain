# Memory_OB Goose addon — package manifest

Built: 2026-10-23T12:55:37.877Z
Version: 1.0.0 (0d5f5ce, uncommitted changes in the build checkout)
Targets: Windows 11 + Node.js 24 (works on macOS/Linux too). No paid services. No telemetry.

## What this folder is

One folder you can copy anywhere. It makes plain Goose work with your one
memory (`Memory_OB`) inside Goose itself — no separate app, no browser:

- `install.mjs` — installs the eleven Memory_OB tools + the in-chat and
  Apps-page screens + the skill into Goose and switches Goose's stock memory
  off, in one reviewed change (type `ALLOW`). It also repairs duplicate
  `memory`/`apps`/`memory_ob` config blocks left by earlier broken installers,
  and never writes a config Goose cannot parse.
- `import-goose-history.mjs` — the one-time import of your existing Goose
  sessions and memory, run BEFORE installing. Everything imported is labelled
  raw unconfirmed evidence.
- `fix-goose-extensions.mjs` — rebuilds extensions that Goose dropped from
  its config because their old shape stopped parsing (type `ALLOW`).
- `dist/` — pre-built engines. No build step needed on your machine.

Your screens live INSIDE Goose: say "show my memory screens" in any chat, or
open the Apps page — Memory_OB sits beside your other apps. There is no
browser window to open.

## Sources and versions

| Part | Source | Version |
| --- | --- | --- |
| Adapter + tools (`dist/memory-ob-mcp.cjs`) | OddBrain apps/03_oddbrain main/memoryOb | 1.0.0 |
| Import engine (`dist/goose-import-core.cjs`) | OddBrain main/memoryOb/gooseImport | 1.0.0 |
| Goose storage formats | Goose v1.55.0 (sessions.db, .jsonl sessions, memory/*.txt) | v1.55.0 |
| Skill (`goose-skill/SKILL.md`) | packages/Memory_OB/goose-skill | 1.0.0 |

## Commands

| You run | What it does |
| --- | --- |
| `node import-goose-history.mjs` | Preview your Goose history (changes nothing) |
| `node import-goose-history.mjs --apply` | Import it (type ALLOW) |
| `node install.mjs --goose-config <config.yaml>` | Review the exact change, type ALLOW to install |
| `node dist/memory-ob-mcp.cjs --catalogue <store> --chats <chats> --vault <brain> owner list` | Owner commands (never-send / allow-send / trash / restore) |

## File checksums (SHA-256)

| File | Bytes | SHA-256 |
| --- | --- | --- |
| `dist/goose-import-core.cjs` | 118412 | `75819df6afb9613893fd7d8d56a6c1fef685258f10a07380ddd666c559ed9d14` |
| `dist/memory-ob-mcp.cjs` | 505843 | `c935739f596af3863cd65378f31f391e53398524543909288a1534316c5c30e9` |
| `dist/memory-ob-semantic.cjs` | 113935 | `6f6030361b96e59855c7794b14e4e9a51f75a93641bcb4debbd4263da122198c` |
| `fix-goose-extensions.mjs` | 15791 | `3ff898a86b7cd78a96e9a4541603c4f25364035ba887bc45d84cb5e7db59eb0a` |
| `goose-skill/SKILL.md` | 4682 | `a1af431883b9fb532eaa1d5629abc2d9ac830578d94281df525de05f2474a82a` |
| `import-goose-history.mjs` | 6556 | `264cc81b4c0d48c90b5d82edb93de339fee3d4db7ecd90acb1e271f3f7947819` |
| `install.mjs` | 24406 | `27e779de3e335814adfaf803ffacb31868c12fdae546b7400783e8f9bae7eb7c` |
| `LICENSE` | 11358 | `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30` |
| `README.md` | 10054 | `3d107cfaa968c5e17294b7ba4efbf8e141155c6018bc92c7d1f055f86b4adff5` |
| `semantic-search.mjs` | 4736 | `ae49ffb23aa1e3423d0e2033984ca410826db796ab5c0c24f9bfd10215b141e9` |

## States

- Verified in the repository suite before packaging: the judge trap suite
  (intake, review-undo, Working Notes, owner marks, links, the Never-Send
  redaction law, and the Goose app screens contract), the install smoke
  (including the no-NUL-bytes and duplicate-block repair regressions), the
  import smoke, the extension-repair smoke, `npm run typecheck`, and
  `security:release` — all green on the build this package was cut from.
- The package itself is verified end-to-end by
  `packages/Memory_OB/goose-addon/test/package-smoke.sh` in the repository:
  it copies THIS folder to a clean place and runs import + install from it.

## Decisions this package keeps

- One memory authority: the brain folder. Nothing else is a second database.
- The in-chat confirmation card is the only place memory is confirmed: Allow
  saves exactly what the card shows, Deny saves nothing. The screens are
  view-only.
- `memory_ob_review retract` withdraws a confirmed record and keeps its full
  history. Nothing is ever permanently deleted.
- Imported history is raw unconfirmed evidence (`origin: import`), never
  silently trusted.
- Never Send records are never handed to an agent — not their text, titles,
  ids, or a count — on any surface.
- Goose's own folders are read-only sources; the AI may move things to
  recoverable Trash but never permanently deletes.
- No telemetry, no credentials, no external services, no phone-home.
