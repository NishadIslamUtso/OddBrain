# Memory_OB Goose addon — package manifest

Built: 2026-10-23T07:49:26.839Z
Version: 0.9.1 (0e91412, uncommitted changes in the build checkout)
Targets: Windows 11 + Node.js 24 (works on macOS/Linux too). No paid services. No telemetry.

## What this folder is

One folder you can copy anywhere. It makes plain Goose work with your one
memory (`Memory_OB`) without installing or maintaining any app:

- `install.mjs` — installs the four read-only tools + the skill into Goose and
  switches Goose's stock memory off, in one reviewed change (type `ALLOW`).
- `import-goose-history.mjs` — the one-time import of your existing Goose
  sessions and memory, run BEFORE installing. Everything imported is labelled
  raw unconfirmed evidence.
- `brain-window.mjs` — the local Brain Window: Projects, Vault (files, search,
  graph, link check, folder choose-and-decide) and Review (the only place
  memory is confirmed).
- `dist/` — pre-built engines. No build step needed on your machine.

## Sources and versions

| Part | Source | Version |
| --- | --- | --- |
| Adapter + tools (dist/memory-ob-mcp.cjs) | OddBrain apps/03_oddbrain main/memoryOb | 0.9.1 |
| Import engine (dist/goose-import-core.cjs) | OddBrain main/memoryOb/gooseImport | 0.9.1 |
| Brain Window host (dist/brain-window-server.cjs) | OddBrain main/brainWindow | 0.9.1 |
| Interface (ui/) | OddBrain renderer (dist-web build) | 0.9.1 |
| Goose storage formats | Goose v1.55.0 (sessions.db, .jsonl sessions, memory/*.txt) | v1.55.0 |
| Skill (goose-skill/SKILL.md) | packages/Memory_OB/goose-skill | 0.9.1 |

## Commands

| You run | What it does |
| --- | --- |
| `node import-goose-history.mjs` | Preview your Goose history (changes nothing) |
| `node import-goose-history.mjs --apply` | Import it (type ALLOW) |
| `node install.mjs --goose-config <config.yaml>` | Review the exact change, type ALLOW to install |
| `node brain-window.mjs` | Open Projects · Vault · Review in your browser |
| `node dist/memory-ob-mcp.cjs --catalogue <store> --chats <chats> owner list` | Owner commands (never-send / allow-send) |

## File checksums (SHA-256)

| File | Bytes | SHA-256 |
| --- | --- | --- |
| `brain-window.mjs` | 3525 | `e959b4f1a43b8683c4b5ac27e0b5c4b009257e2f66648aeb669f9fecd93bb0b4` |
| `dist/brain-window-server.cjs` | 576189 | `ee262d7b441ea7d240b3462a5c805d52ca5dcecb5b657d046a080c991ab22d57` |
| `dist/goose-import-core.cjs` | 116013 | `707ddb4e1682eadd6c73765b0e70128b2d16b9e6e4432f5d07949d2e4cd4fd05` |
| `dist/memory-ob-mcp.cjs` | 460679 | `bf21a4a1ac4519595faa0ff042d6458b3c3716b5bafa5c59ecae2e81a783e241` |
| `dist/memory-ob-semantic.cjs` | 111536 | `945d03b733b4cfc835bc1747409aff4f5eebc0e12c91d0d82051a91d7ac720c7` |
| `goose-skill/SKILL.md` | 3755 | `5dc778f7343f09dfe55819fc36b0d866630130901023f0ce528b3faddc38a9ce` |
| `import-goose-history.mjs` | 6556 | `264cc81b4c0d48c90b5d82edb93de339fee3d4db7ecd90acb1e271f3f7947819` |
| `install.mjs` | 17998 | `4f337485b18c8df0d6a791f5eaddb8211c829988cd3dbc8fc835e32160b5c6a4` |
| `LICENSE` | 11358 | `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30` |
| `README.md` | 9362 | `03102dae7cfb763fb9d6fcd1ab75a1ddbb0694bb05e351e4e42798756ef206e4` |
| `semantic-search.mjs` | 4736 | `ae49ffb23aa1e3423d0e2033984ca410826db796ab5c0c24f9bfd10215b141e9` |
| `ui/assets/ArtifactsView-CGJQkfba.js` | 17291 | `9a6801f73de7aa974a14577763b15d8d2ebf5cca8eaabd0d94b88919abb45afd` |
| `ui/assets/BrainView-B7pzhg1r.js` | 42564 | `bc9229bf8e0f30a35bbadbeb8259f534b2ceaa7806084e4d46e2ce416729a915` |
| `ui/assets/ConnectionGraph-CHHkHAwZ.js` | 16486 | `6406da809d492d22c13b7ae6cefb51c1ad94a18ffe5da3cae7cb37f574f3f2f1` |
| `ui/assets/external-link-JcgwSyL1.js` | 419 | `758147e7b0ad3257ba63cdefe0baa9c37cdce19d9cd75b8d237b9593854ef134` |
| `ui/assets/index-Cco02AzG.css` | 93392 | `843c1ca8615fd04dbb9e78d6bbee8f2cca53fcc7bd98421d701b465f54f451c5` |
| `ui/assets/index-CWIArIO7.js` | 1916895 | `1d8f651cf95231b34fba378a00b02f6459c64269f4441540729164e4c25aa1f0` |
| `ui/assets/link-2-QckhxFd3.js` | 410 | `df845608d5745abd15b191710c30b5301a1bcfa093d0b143a22ab65aa189e6d1` |
| `ui/assets/NativeRuleReview-RpoyYhoV.js` | 1258 | `664100149af24a8829550fa57f3137cc03ac9a9a3fee1fc72c27d218cf98540b` |
| `ui/assets/ProjectsView-1qu2jsil.js` | 32403 | `88724be7619b7717b00420b29f35c960e24f08020032547609b515fe743272e0` |
| `ui/assets/refresh-cw-DjLTf8At.js` | 489 | `f981bcaee01f040d2a094a1a8807446adf109e26481a259be06db358414b8e90` |
| `ui/assets/SettingsView-Bw3oNuI4.js` | 205699 | `d1c5eb1c999398559dea949d024db22edce5f8d8c56c34e69b7844555e9cc312` |
| `ui/assets/trash-2-MiAPb-AK.js` | 526 | `e0cfe2d45c4df1dee8147c441ac370239d2be31f358a01f5a5474bc30494854a` |
| `ui/assets/upload-NiGxko3L.js` | 808 | `a23d5306705c421f5dfa56db5313e638a9789ca1d5dc43f6cc880a02ddf754af` |
| `ui/assets/VaultView-Bqaqg7F7.js` | 20465 | `636dc52f915d94eba4f9406fee1f36dfc316965a9677ef77113cb54a83bc52bd` |
| `ui/assets/VideoStudioView-DNJ5Nbcq.js` | 31126 | `016914be4d493ad8dae895474521c66201801fc513ed57f066f1d26398a39d86` |
| `ui/favicon.svg` | 8536 | `bde15dc3db2beb27ad58c6257b0d0f94e023305509db1e667d14e97c1b6dea29` |
| `ui/index.html` | 1092 | `d3382f31ba655e1603ad94bef0a89ddf0a175199ac817ec39d1875e0ad709500` |
| `ui/oddbrain-preview.html` | 699946 | `09703df242a98c83d08d07c8a3e7da992dc6e0d705a52e03d20e5ec6334510d2` |

## States

- Verified in the repository suite before packaging: install smoke 34/34,
  import smoke 20/20, judge traps 33/33 (Never-Send, project scope, hazard
  excerpts, restart identity, trashed chats, empty catalogue), Brain Window
  smoke 10/10, `security:release` and `security:policy` passed on the build
  this package was cut from.
- The package itself is verified end-to-end by
  `packages/Memory_OB/goose-addon/test/package-smoke.sh` in the repository:
  it copies THIS folder to a clean place and runs import + install + Brain
  Window from it.

## Decisions this package keeps

- One memory authority: the brain folder. Nothing else is a second database.
- Goose never confirms its own memory; the Review screen is the only place
  confirmations happen.
- Imported history is raw unconfirmed evidence (`origin: import`), never
  silently trusted.
- Goose's own folders are read-only sources; the AI may move things to
  recoverable Trash but never permanently deletes.
- No telemetry, no credentials, no external services, no phone-home.
